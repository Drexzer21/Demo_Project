package com.infominez.audit.serviceTests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.infominez.audit.entity.AuditType;
import com.infominez.audit.repo.AuditTypeRepository;
import com.infominez.audit.service.AuditTypeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AuditTypeServiceTests {
    @InjectMocks
    AuditTypeService auditTypeService;

    @Mock
    AuditTypeRepository auditTypeRepository;



    @Test
    public void testFindById()
    {
        // given
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date createdDate = null;
        Date updatedDate = null;
        try{
            createdDate = df.parse("2020-02-19 17:08:08");
            updatedDate = df.parse("2020-03-17 12:45:13");
        }catch (Exception e){
            e.printStackTrace();
        }
        List<AuditType> list = new ArrayList<>();
        AuditType assumedAuditType = new AuditType(1, "ATM AUDIT", 1,1,createdDate,updatedDate);

        list.add(assumedAuditType);
        when(auditTypeRepository.findAll()).thenReturn(list);

        // when
       List<AuditType> auditTypeFromTest = auditTypeService.findAllForTest();


        // then
        assertThat(auditTypeFromTest.get(0).getAuditTypeId())
                .isEqualTo(assumedAuditType.getAuditTypeId());   // this should pass

        assertThat(auditTypeFromTest.get(0).getAuditType())
                .isEqualTo(assumedAuditType.getAuditType());   // this should pass
    }
   /* @Test
    public void createtest(){
          AuditType auditType = null;
        Date date = new Date();
        AuditType assumedAuditType = new AuditType(8, "SITE", 1,1,date,date,"testSource14");

        try {
            auditType.setObjectSource("testsource14");
            auditType.setAuditType("SITE");
            auditType.setCreatedBy(1);
            auditType.setUpdatedBy(1);
            auditType.setCreatedDate(date);
            auditType.setLastUpdatedDate(date);
           AuditType auditTyperesult= auditTypeRepository.save(auditType);
            assertThat(assumedAuditType.getAuditTypeId())
                    .isEqualTo(auditTyperesult.getAuditTypeId());

            assertThat(assumedAuditType.getAuditType())
                    .isEqualTo(auditTyperesult.getAuditType());

            assertThat(assumedAuditType.getObjectSource())
                    .isEqualTo(auditTyperesult.getObjectSource());


        }catch (Exception e){
            e.printStackTrace();
        }







    }*/
}
