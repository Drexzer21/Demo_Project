
package com.infominez.audit.serviceTests;


import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.repo.QuestionTypeRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace= AutoConfigureTestDatabase.Replace.NONE)
public class QuestionTypeRepositoryTest {

    @Autowired
    QuestionTypeRepository questionTypeRepository;

    @Test
    public void saveTest(){
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date createdDate = null;
        Date updatedDate = null;
        try{
            createdDate = df.parse("2020-02-19 17:08:08");
            updatedDate = df.parse("2020-03-17 12:45:13");
        }catch (Exception e){
            e.printStackTrace();
        }
        QuestionType questionType=new QuestionType(1,"test",1,1,createdDate,updatedDate,true);
        questionTypeRepository.save(questionType);
        QuestionType questionType2=questionTypeRepository.findById(1).get();
        Assert.assertNotNull(questionType);
        Assert.assertEquals(questionType.getQuestionTypeId(),questionType2.getQuestionTypeId());


    }
}
