package com.infominez.audit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AuditApplicationTests {

    @Test
    public void testSampleTest() {
        assertTrue(true, "Should be true");
        System.out.println("Hey Tests work");
    }

}
