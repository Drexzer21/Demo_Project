package com.infominez.audit.service;

import com.infominez.audit.repo.ScheduleSiteRepository;
import com.infominez.audit.repo.UserAuditScheduleRepository;
import com.infominez.audit.utils.ExcelUtils;
import com.infominez.audit.utils.Utils;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class ScheduleSiteService {
    private final ScheduleSiteRepository scheduleSiteRepository;
    private final UserAuditScheduleRepository userAuditScheduleRepository;
    
	public JSONObject FindScheduleSiteByUserAuditSchedule(Integer userAuditScheduleId) {
		log.info(this.getClass().getName() + " :- FindScheduleSiteByUserAuditSchedule() , {}",userAuditScheduleId);
		JSONObject response = new JSONObject();
		JSONArray array=new JSONArray();
		try {
			List<Object[]> getScheduleSite = scheduleSiteRepository.FindScheduleSiteByUserAuditSchedule(userAuditScheduleId);
			if (getScheduleSite != null) {
				for (Object[] obj : getScheduleSite) {
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("scheduleSiteId", obj[0]);
					jsonObject.put("siteId", obj[1]);
					jsonObject.put("siteName", obj[2]);
					jsonObject.put("siteCode", obj[3]);
					jsonObject.put("state", obj[4]);
					jsonObject.put("city", obj[5]);
					jsonObject.put("address", obj[6]);
					jsonObject.put("pincode", obj[7]);
					array.add(jsonObject);
				}
				response.put("status", 200);
				response.put("message","SUCCESS");
				response.put("response",array);

			} else {
				response.put("status", 302);
				response.put("message","ScheduleSite not find");
				response.put("response","ScheduleSite not find");
			}

		    } catch (Exception e) {
            log.error("Exception in FindScheduleSiteByUserAuditSchedule() userAuditScheduleId : {}, Exception : {}",userAuditScheduleId, e.getMessage());
			response.put("status", 500);
			response.put("message","Internal Server Error");
			response.put("response","Internal Server Error");
		}
		return response;
	}

    public JSONObject getListOfSiteScheduledByUser(Integer userId) {
		log.info(this.getClass().getName() + " :- getListOfSiteScheduledByUser()");
		JSONObject response = new JSONObject();
		try{
			JSONArray jsonArray = new JSONArray();
			List<Object[]> userList = scheduleSiteRepository.getListOfScheduledSiteByUser(userId);
			if (userList != null && userList.size() > 0) {
				for (Object[] obj : userList) {
					JSONObject object = new JSONObject();
					object.put("siteId", obj[0]);
					object.put("siteName", obj[1]);
					object.put("siteCode", obj[2]);
					object.put("state", obj[3]);
					object.put("city", obj[4]);
					object.put("pincode", obj[5]);
					object.put("address", obj[6]);
					jsonArray.add(object);
				}
				response.put("status",200);
				response.put("message","SUCCESS");
				response.put("response",jsonArray);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			log.error("Exception in getListOfUserScheduled() , exception : {} ", e.getMessage());
			response.put("status", 500);
			response.put("response", "Internal Server Error");
		}
		return response;

	}

	public JSONObject getAuditSchedulingList(String fromDate, String toDate, String assignedDate, Integer userId,
			String sitecode) {
		log.info(this.getClass().getName() + " :-getAuditSchedulingList() fromDate : {} toDate : {} assignedDate : {} userId : {} siteCode : {}", fromDate, toDate, assignedDate, userId, sitecode);
		JSONObject response = new JSONObject();
		try {
			JSONArray array = new JSONArray();
			Date startDate = null;
			Date endDate = null;
			String AssignedDate = null;
			if(fromDate != null && !fromDate.isEmpty() && 
			   toDate != null && !toDate.isEmpty()) {
			 String FromDate = Utils.getStringFromString(fromDate);
			 String ToDate = Utils.getStringFromString(toDate);
			 SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
			  startDate = formatDate.parse(FromDate);
	          endDate = formatDate.parse(ToDate);
	         Integer dateCompare = startDate.compareTo(endDate);
	         if(dateCompare > 0) {
	        	 response.put("status",302);
	 			 response.put("message","INVALID_DATE");
	 			 return response;
	         }
			}
			if(assignedDate != null && !assignedDate.isEmpty()) {
			 AssignedDate = Utils.getStringFromString(assignedDate);
			}
			List<Object[]> getAuditSchedulingData = scheduleSiteRepository.getAduitSchedulingDate(
					startDate != null ? startDate : null,
					endDate != null  ? endDate : null,
					AssignedDate != null && !AssignedDate.isEmpty() ? AssignedDate : null,
					userId != null ? userId : null,	
					sitecode != null && !sitecode.isEmpty() ? sitecode : null);
			for (Object[] obj : getAuditSchedulingData) {
				JSONObject object = new JSONObject();
				object.put("userId", obj[0]);
				object.put("emailId", obj[1]);
				object.put("templateName", obj[2]);
				object.put("siteCode", obj[3]);
				object.put("startDate", obj[4]);
				object.put("endDate", obj[5]);
				object.put("noOfVisit", obj[6]);
				object.put("visitType", obj[7]);
				object.put("uploadDate", obj[8]);
				array.add(object);
			}
			response.put("status",200);
			response.put("message","SUCCESS");
			response.put("response",array);
			 return response;
		} catch(Exception e){
			e.printStackTrace();
			log.error("Exception in getAuditSchedulingList() , exception : {} ", e.getMessage());
			response.put("status", 500);
			response.put("response", "Internal Server Error");
		}
		return response;
	}

	public ByteArrayInputStream getAuditSchedulingReport(String fromDate, String toDate, String assignedDate,
			Integer userId, String sitecode) {
		log.info(this.getClass().getName() + " :-getAuditSchedulingReport() fromDate : {} toDate : {} assignedDate : {} userId : {} siteCode : {}", fromDate, toDate, assignedDate, userId, sitecode);
		try (SXSSFWorkbook workbook = new SXSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("CAMPAIGN_WISE_REPORT");
			ArrayList<String> headerList = new ArrayList<>(
					Arrays.asList("Email", "Template Name", "Site Code", "Start Date", "End Date",
							"No Of Visit", "Visit Type", "Upload Date"));
			CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 2);
			ExcelUtils.createAndWriteRowWithColorV2(sheet, headerList, 0, cellStyle, true, workbook,
					IndexedColors.BLACK.getIndex(), IndexedColors.LIGHT_ORANGE.getIndex());
			String AssignedDate = null;
			Date startDate = null;
			Date endDate = null;
			String FromDate = null;
			 String ToDate = null;
			if(assignedDate != null && !assignedDate.isEmpty()) {
				 AssignedDate = Utils.getStringFromString(assignedDate);
			}
			 SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
			if (fromDate != null && !fromDate.isEmpty() && toDate != null && !toDate.isEmpty()) {
				 FromDate = Utils.getStringFromString(fromDate);
				 ToDate = Utils.getStringFromString(toDate);
				 startDate = formatDate.parse(FromDate);
				 endDate = formatDate.parse(ToDate);
			 }
	          if(startDate != null && endDate != null) {
	        	  Integer dateCompare = startDate.compareTo(endDate);
					if (dateCompare > 0) {  
//						return null;
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						workbook.write(outputStream);
						return new ByteArrayInputStream(outputStream.toByteArray());
					}
	          }
					List<Object[]> getData = scheduleSiteRepository.getAduitSchedulingDate(
							startDate != null ? startDate : null, endDate != null ? endDate : null,
							AssignedDate != null && !AssignedDate.isEmpty() ? AssignedDate : null,
							userId != null ? userId : null, sitecode != null && !sitecode.isEmpty() ? sitecode : null);
					int rowCount = 1;
					try {
						cellStyle = ExcelUtils.createCellStyle(sheet, rowCount);
						CellStyle numericCellStyle = workbook.createCellStyle();

						for (Object[] object : getData) {
							ArrayList<String> rowData = new ArrayList<>();
							// Email 1
							if (object[1] != null) {
								rowData.add(object[1] + "");
							} else {
								rowData.add("NA" + "");
							}
							// Template Name 2
							if (object[2] != null) {
								rowData.add(object[2] + "");
							} else {
								rowData.add("NA" + "");
							}
							// Site Code 3
							if (object[3] != null) {
								rowData.add(object[3] + "");
							} else {
								rowData.add("NA" + "");
							}
							SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							// Start Date 4
							if (object[4] != null) {
								String dateStart = df.format(object[4]);
								rowData.add(dateStart + "");
							} else {
								rowData.add("NA" + "");
							}
							// End Date 5
							if (object[5] != null) {
								String dateEnd = df.format(object[5]);
								rowData.add(dateEnd + "");
							} else {
								rowData.add("NA" + "");
							}
							// No Of Visit 6
							if (object[6] != null) {
								rowData.add(object[6] + "");
							} else {
								rowData.add("NA" + "");
							}
							// Visit Type 7
							if (object[7] != null) {
								rowData.add(object[7] + "");
							} else {
								rowData.add("NA" + "");
							}
							// Upload Date 8
							if (object[8] != null) {
								String dateEnd = df.format(object[8]);
								rowData.add(dateEnd + "");
							} else {
								rowData.add("NA" + "");
							}
							Integer[] countIntegerIndexes = {};
							Integer[] countFloatIndexes = {};

							ExcelUtils.createAndWriteRowIndex(sheet, rowData, rowCount++, cellStyle, false, workbook,
									countIntegerIndexes, countFloatIndexes, numericCellStyle);
						}
					} catch (Exception e) {
						log.error("Exception in writing sheet ", e);
						return null;
					}
					ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
					workbook.write(outputStream);
					return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (Exception e) {
			log.error(e.getMessage());
			log.error("Exception in :-getAuditSchedulingReport() fromDate : {} toDate : {} assignedDate : {} userId : {} siteCode : {}",
					fromDate, toDate, assignedDate, userId, sitecode, e.getMessage());
			return null;
		}
	}

	public ByteArrayInputStream getSchedulerReportByDate(String fromDate, String toDate) {
		log.info("getSchedulerReportByDate fromDate : {} toDate : {}", fromDate, toDate);
		try (SXSSFWorkbook workbook = new SXSSFWorkbook()){
			 Sheet weekly = workbook.createSheet("Weekly");
			 Sheet fortnightly = workbook.createSheet("Fortnightly");
			 Sheet monthly = workbook.createSheet("Monthly");
			    DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			    String FromDate = Utils.getStringFromString(fromDate);
	            String ToDate = Utils.getStringFromString(toDate);
		        LocalDate FromDateForHeader = LocalDate.parse(fromDate, inputFormatter);
		        LocalDate ToDateForHeader = LocalDate.parse(toDate, inputFormatter);
		        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		        String formattedFromDate = FromDateForHeader.format(outputFormatter);
		        String formattedToDate = ToDateForHeader.format(outputFormatter);
			 String heading = "["+formattedFromDate+"]-["+formattedToDate+"]";
			  ExcelUtils.mergeCellWithoutColor(weekly, heading, 0, 0, 2, 3, 0);
		        ArrayList<String> headerListForWeekly = new ArrayList<>(Arrays.asList("Site Code", "Auditor", "Assigned Audit", "Completed", "Pending"));
		        CellStyle cellStyle1 = ExcelUtils.createCellStyle(weekly, 1);
		        ExcelUtils.createAndWriteRow(weekly, headerListForWeekly, 1, cellStyle1, true, workbook);
		        int rowCounts = 2;
		        try {
		        List<Object[]> getData = userAuditScheduleRepository.callGetWeeklyScheduleReportByDate(FromDate, ToDate);
				for(Object[] object : getData) {
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(object[0] + "");
					rowData.add(object[1] + "");
					rowData.add(object[2] + "");
					rowData.add(object[3] + "");
					
					Integer pending = (Integer.valueOf(String.valueOf(object[2])) - Integer.valueOf(String.valueOf(object[3])));
					rowData.add(pending + "");
	                ExcelUtils.createAndWriteRow(weekly, rowData, rowCounts++, cellStyle1, false, workbook);
				}
				} catch (Exception e) {
					log.error("Exception in writing sheet ", e);
					return null;
				}
		     // Create Fortnightly sheet code
		        ExcelUtils.mergeCellWithoutColor(fortnightly, heading, 0, 0, 2, 3, 0);
		        ArrayList<String> headerListForFortnightly = new ArrayList<>(Arrays.asList("Site Code", "Auditor", "Assigned Audit", "Completed", "Pending"));
		        CellStyle cellStyle2 = ExcelUtils.createCellStyle(fortnightly, 1);
		        ExcelUtils.createAndWriteRow(fortnightly, headerListForFortnightly, 1, cellStyle2, true, workbook);
		        int rowCounts1 = 2;
		        try {
		        List<Object[]> getData = userAuditScheduleRepository.callGetFortnightlyScheduleReportByDate(FromDate, ToDate);
				for(Object[] object : getData) {
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(object[0] + "");
					rowData.add(object[1] + "");
					rowData.add(object[2] + "");
					rowData.add(object[3] + "");
					Integer pending = (Integer.valueOf(String.valueOf(object[2])) - Integer.valueOf(String.valueOf(object[3])));
					rowData.add(pending + "");
	                ExcelUtils.createAndWriteRow(fortnightly, rowData, rowCounts1++, cellStyle2, false, workbook);
				}
				} catch (Exception e) {
					log.error("Exception in writing sheet ", e);
					return null;
				}
		     // Create Monthly sheet code
		        ExcelUtils.mergeCellWithoutColor(monthly, heading, 0, 0, 2, 3, 0);
		        ArrayList<String> headerListForMonthly = new ArrayList<>(Arrays.asList("Site Code", "Auditor", "Assigned Audit", "Completed", "Pending"));
		        CellStyle cellStyle3 = ExcelUtils.createCellStyle(monthly, 1);
		        ExcelUtils.createAndWriteRow(monthly, headerListForMonthly, 1, cellStyle3, true, workbook);
		        int rowCounts2 = 2;
		        try {
		        List<Object[]> getData = userAuditScheduleRepository.callGetMonthlyScheduleReportByDate(FromDate, ToDate);
				for(Object[] object : getData) {
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(object[0] + "");
					rowData.add(object[1] + "");
					rowData.add(object[2] + "");
					rowData.add(object[3] + "");
					Integer pending = (Integer.valueOf(String.valueOf(object[2])) - Integer.valueOf(String.valueOf(object[3])));
					rowData.add(pending + "");
	                ExcelUtils.createAndWriteRow(monthly, rowData, rowCounts2++, cellStyle3, false, workbook);
				}
				} catch (Exception e) {
					log.error("Exception in writing sheet ", e);
					return null;
				}
		        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		        workbook.write(outputStream);
		        return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			log.error("Exception in writing Get Scheduler ReportByDate excel V2 ", e);
			return null;
		}
	}
}
