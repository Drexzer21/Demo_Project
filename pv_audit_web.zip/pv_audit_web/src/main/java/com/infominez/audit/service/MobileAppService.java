package com.infominez.audit.service;

import com.infominez.audit.AuditApplication;
import com.infominez.audit.entity.*;
import com.infominez.audit.repo.*;
import com.infominez.audit.utils.Constants;
import com.infominez.audit.utils.FileUtils;
import com.infominez.audit.wrapper.CashMasterDTO;
import com.infominez.audit.wrapper.TicketResponseWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class MobileAppService {

    private TicketRepository ticketRepository;
    private PageRepository pageRepository;
    private QuestionRepository questionRepository;
    private TemplateRepository templateRepository;
    private QuestionTypeOptionRepository questionTypeOptionRepository;
    private QuestionTypeRepository questionTypeRepository;
    private TicketResponseRepository ticketResponseRepository;
    private AuditRepository auditRepository;
    private ConfigPropertiesRepository configPropertiesRepository;



    public JSONObject getDashboardData(JSONObject request, Users user) {
        log.info("get DashboardData()");
        JSONObject result = new JSONObject();
        try {
            List<Object[]> list = ticketRepository.getDashboardData(user.getUserId());  // bypass
//            List<Object[]> list = ticketRepository.getDashboardData(9);
            JSONArray dataList = new JSONArray();
            for (Object[] obj : list) {
                JSONObject data = new JSONObject();
                data.put("auditName", obj[0]);
                data.put("startDate", obj[1]);
                data.put("endDate", obj[2]);
                data.put("doneCount", obj[3]);
                data.put("pendingCount", obj[4]);
                data.put("total", obj[5]);
                data.put("auditId", obj[6]);
                data.put("adhocTicketCount", obj[7]);
                dataList.add(data);
            }
            result.put("status", 200);
            result.put("response", dataList);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("exception in getDashboardData() for user : {}, and exception : {}", user.toString(), e.getMessage());
            log.error("Trace exception in getDashboardData() for user : {}, and exception : {}", user.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getAtmForAudit(JSONObject request, Users user) {
        log.info("get Atm for audit ");
        JSONObject result = new JSONObject();
        try {
            Integer auditId = Integer.parseInt(String.valueOf(request.get("auditId")));
           String status = String.valueOf(request.get("status"));
//            String status = "COMPLETED"; // temporary reverse
           log.info("auditId ", auditId.toString());
           log.info("status ", status.toString());
            List<Ticket> ticketList = new ArrayList<>();
            List<Ticket> ticketListV2 = new ArrayList<>();
            if (status.equalsIgnoreCase("COMPLETED")){
              ticketList = ticketRepository.findByAuditAndStatus(auditId, "COMPLETED", user.getUserId());
            }else{
             ticketList = ticketRepository.findByAuditAndStatusReverse(auditId, "COMPLETED", user.getUserId());
            }
            for(Ticket obj : ticketList) {
            	Boolean isAdhocAllowedOrNot = ticketRepository.checkIsAdhocAllowed(obj.getTicketId());
            	obj.setIsShowAdhocButton(isAdhocAllowedOrNot);	
            	ticketListV2.add(obj);
            }
            
            result.put("status", 200);
            result.put("response", ticketListV2);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getAuditQuestion(JSONObject request) {

        return null;
    }
    /*public JSONObject getByTicketId(JSONObject request,Integer ticketId){
        log.info("get by Ticketid ");
        JSONObject result = new JSONObject();
        try{
            Ticket ticket=ticketRepository.findById(ticketId).get();
            Template template= templateRepository.findById(ticket.getAudit().getTemplate().getTemplateId()).get();
            List<Page> page=pageRepository.findByTemplate(template);
            result.put("ticketID",ticket);
            JSONArray newList = new JSONArray();
            for(Page pagelist:page){
                result.put("ticket",ticket);
                result.put("pages", page);
                List<Question> questions = questionRepository.findByPage(pagelist);
                result.put("Questions", questions);

                Question question=null;
               if(question.getQuestionType().getIsOption()==true){

                   QuestionType questionType=questionTypeRepository.findById(question.getQuestionType().getQuestionTypeId()).get();

                   List<QuestionTypeOption> questionTypeOption=questionTypeOptionRepository.findByQuestionType(questionType);

                   result.put("questionTypeOptions",questionTypeOption);

               }

                newList.add(result);
            }
            if (newList != null && !newList.isEmpty()) {
                result.put("status", 200);
                result.put("response", newList);
            } else {
                result.put("status", 302);
                result.put("response", "No ticket found");
            }


        }catch (Exception e){
            log.error("Exception in getByTicketId  exception : {} ", e.getMessage());
            log.trace("Exception in getByTicketId  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");

        }


        return result;

    }*/

    public JSONObject getByTicketId(JSONObject request, Integer ticketId) {
        log.info("get by Ticketid ");
        JSONObject result = new JSONObject();
        try {
            Ticket ticket = ticketRepository.findById(ticketId).get();
            Template template = templateRepository.findById(ticket.getAudit().getTemplate().getTemplateId()).get();
            List<Page> pageList = pageRepository.findByTemplate(template);

            JSONObject mainObject = new JSONObject();
            mainObject.put("ticketId", ticket.getTicketId());
            mainObject.put("siteId", ticket.getSite().getSiteId());
            mainObject.put("status", ticket.getStatus());
            mainObject.put("auditId", ticket.getAudit().getAuditId());
            JSONArray pagesListArray = new JSONArray();
            for (Page page : pageList) {
                List<Question> questionList = questionRepository.findByPage(page);
                JSONObject pageObject = new JSONObject();
                pageObject.put("pageId", page.getPageId());
                pageObject.put("pageName", page.getPageName());
                pageObject.put("sequence", page.getSequence());
                pageObject.put("pageDesc", page.getPageDesc());
                JSONArray questionListArray = new JSONArray();
                for (Question question : questionList) {
                    JSONObject questionObject = new JSONObject();
                    JSONArray questionOptionArray = new JSONArray();
                    if (question.getQuestionType().getIsOption() == true) {
                        List<QuestionTypeOption> questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
                        if (questionTypeOptions != null && questionTypeOptions.size() > 0) {
                            for (QuestionTypeOption qto : questionTypeOptions) {
                                JSONObject questionTypeOptionJSON = new JSONObject();
                                questionTypeOptionJSON.put("questionTypeOptionId", qto.getQuestionTypeOptionId());
                                questionTypeOptionJSON.put("option", qto.getOption());
                                questionOptionArray.add(questionTypeOptionJSON);
                            }
                        }
                    }
                    JSONObject questionTypeJSON = new JSONObject();
                    questionTypeJSON.put("questionTypeId", question.getQuestionType().getQuestionTypeId());
                    questionTypeJSON.put("questionType", question.getQuestionType().getQuestionType());
                    questionTypeJSON.put("isOption", question.getQuestionType().getIsOption());

                    questionObject.put("questionId", question.getQuestionId());
                    questionObject.put("question", question.getQuestion());
                    questionObject.put("sequence", question.getSequence());
                    questionObject.put("questionType", questionTypeJSON);
                    questionObject.put("dataType", question.getDataType());
                    questionObject.put("captureImgStatus", question.getCaptureImgStatus());
                    questionObject.put("questionTypeOptions", questionOptionArray);
                    questionListArray.add(questionObject);
                }
                pageObject.put("questions", questionListArray);
                pagesListArray.add(pageObject);
            }
            mainObject.put("pages", pagesListArray);
            result.put("status", 200);
            result.put("response", mainObject);
        } catch (Exception e) {
            log.error("Exception in getByTicketId  exception : {} ", e.getMessage());
            log.trace("Exception in getByTicketId  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");

        }
        return result;

    }
    public static Predicate<TicketResponseWrapper> distinctByKeys(Function<TicketResponseWrapper, ?>...keyExtractors) {
        final Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(Arrays.stream(keyExtractors)
                .map(keyExtractor -> keyExtractor.apply(t))
                .collect(Collectors.toList()), Boolean.TRUE) == null;
    }

    public JSONObject createMultipleTicketResponse(List<TicketResponseWrapper> trwListDuplicated) {
        JSONObject result = new JSONObject();
        try {
            Date date = new Date();

            if (trwListDuplicated != null && trwListDuplicated.size() > 0) {
                List<TicketResponseWrapper> trwList = trwListDuplicated.stream()
                        .filter(distinctByKeys(TicketResponseWrapper::getTicket, TicketResponseWrapper::getQuestion, TicketResponseWrapper::getResponse, TicketResponseWrapper::getSequence)
                        ).collect(Collectors.toList());
                Map<String, TicketResponseWrapper> trwMap = trwList.stream().collect(
                        Collectors.toMap(TicketResponseWrapper::key, TicketResponseWrapper::getClassObject));
                List<TicketResponse> tobeInsert = new ArrayList<>();
                List<TicketResponse> dbTicketResponse = ticketResponseRepository.findByTicketIds(getTicketIds(trwList));
                for (TicketResponseWrapper trw : trwList) {
                    if (trw.getResponse() == null || trw.getResponse().trim().isEmpty()) {
                        result.put("status", 302);
                        result.put("response", "Response can't be Blank");
                        return result;
                    }
                    log.info("processing  ticketResponse : {}", trw);

                    List<TicketResponse> trCheckList = ticketResponseRepository.findByQuestionAndTicket(trw.getQuestion(), trw.getTicket());
                    if (trCheckList == null || trCheckList.size() < 1) {
                        Ticket ticket = ticketRepository.findById(trw.getTicket().getTicketId()).orElse(null);
                        if (ticket == null){
                            result.put("status", 302);
                            result.put("response", "Ticket Id not found");
                            return result;
                        }
                        Question question = questionRepository.findById(trw.getQuestion().getQuestionId()).orElse(null);
                       /* if (!question.getPage().getTemplate().getTemplateId().equals(ticket.getAudit().getTemplate().getTemplateId())){
                            result.put("status", 302);
                            result.put("response", "Question not mapped in Ticket");
                            return result;
                        }*/
                        TicketResponse ticketResponse = new TicketResponse();
                        if (question != null) {
                            ticketResponse.setTicket(trw.getTicket());
                            ticketResponse.setQuestion(trw.getQuestion());
                            ticketResponse.setResponse(trw.getResponse());
                            ticketResponse.setCreatedBy(1); // todo change when login is implemented
                            ticketResponse.setUpdatedBy(1); // todo change when login is implemented
                            ticketResponse.setCreatedDate(date);
                            ticketResponse.setSequence(trw.getSequence());
                            ticketResponse.setLastUpdatedDate(date);
                            ticketResponse.setLatitude(trw.getLatitude());
                            ticketResponse.setLongitude(trw.getLongitude());
                            if (question.getQuestionType().getQuestionType().equals("QR")) {
                                ticketResponse.setQrString(trw.getQrString());
                                if (question.getIsYesNo() != null && question.getIsYesNo()) {
                                    if (question.getParentId() != null){
                                        TicketResponseWrapper isCorrect = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "001" + trw.getSequence() + "" + trw.getSequence());
                                        TicketResponseWrapper isAvailable = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "003" + trw.getSequence() + "" + trw.getSequence());
                                       if (isCorrect != null){
                                        ticketResponse.setIsCorrect(isCorrect.getResponse().equalsIgnoreCase("YES"));
                                        if (!isCorrect.getResponse().equalsIgnoreCase("YES")) {
                                            TicketResponseWrapper remark = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "002" + trw.getSequence() + "" + trw.getSequence());
                                            if (remark == null) {
                                                result.put("status", 302);
                                                result.put("response", "Remark can't be Empty");
                                                return result;
                                            }
                                            ticketResponse.setRemark(remark.getResponse());
                                        }
                                       }
                                        if (isAvailable != null){
                                            ticketResponse.setIsQrAvailable(isAvailable.getResponse().equalsIgnoreCase("YES"));
                                            if (!isAvailable.getResponse().equalsIgnoreCase("YES")) {
                                                TicketResponseWrapper reason = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "004" + trw.getSequence() + "" + trw.getSequence());
                                                if (reason == null) {
                                                    result.put("status", 302);
                                                    result.put("response" ,  "Reason  can't be Empty");
                                                    return result;
                                                }
                                                ticketResponse.setReason(reason.getResponse());
                                            }
                                        }
                                    }else {
                                        TicketResponseWrapper isCorrect = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "001"+ "" + trw.getSequence());
                                        TicketResponseWrapper isAvailable = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "003"+ "" + trw.getSequence());
                                        if (isCorrect != null){
                                        ticketResponse.setIsCorrect(isCorrect.getResponse().equalsIgnoreCase("YES"));
                                        if (!isCorrect.getResponse().equalsIgnoreCase("YES")) {
                                            TicketResponseWrapper remark = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "002"+ "" + trw.getSequence());
                                            if (remark == null) {
                                                result.put("status", 302);
                                                result.put("response", "Remark can't be Empty");
                                                return result;
                                            }
                                            ticketResponse.setRemark(remark.getResponse());
                                        }
                                        }
                                        if (isAvailable != null){
                                            ticketResponse.setIsQrAvailable(isAvailable.getResponse().equalsIgnoreCase("YES"));
                                            if (!isAvailable.getResponse().equalsIgnoreCase("YES")) {
                                                TicketResponseWrapper reason = trwMap.get(trw.getTicket().getTicketId() + "" + question.getQuestionId() + "004"+ "" + trw.getSequence());
                                                if (reason == null) {
                                                    result.put("status", 302);
                                                    result.put("response", "Reason can't be Empty");
                                                    return result;
                                                }
                                                ticketResponse.setReason(reason.getResponse());
                                            }
                                        }
                                    }
                                }
                            }
                            if (trw.getBase64Image() != null && !trw.getBase64Image().trim().isEmpty()) {
                                String path = taskImageStore(trw);
                                ticketResponse.setImagePath(path);
                            }
                            ticketResponse.setIsEdited(false);
                            if (!checkIsExist(tobeInsert, ticketResponse)) {
                                tobeInsert.add(ticketResponse);
                            }
                        }
                    }
                }
                Set<TicketResponse> s = new HashSet<>();
                s.addAll(tobeInsert);
                tobeInsert = new ArrayList<TicketResponse>();
                tobeInsert.addAll(s);
                List<TicketResponse> filtered = getFilteredTicketResponse(tobeInsert, dbTicketResponse);
                List<TicketResponse> inserted = ticketResponseRepository.saveAll(tobeInsert);
                /*if (inserted != null && inserted.size() > 0) {
                    Ticket ticket = ticketRepository.findById(inserted.get(0).getTicket().getTicketId()).get();
                    ticket.setStatus("IN-PROGRESS");
                    ticket.setLastUpdatedDate(new Date());
                    ticketRepository.save(ticket);
                }*/
                List<Integer> ticketIds = getTicketIdsFromList(tobeInsert);
                ticketIds.forEach(id -> {
                    ticketRepository.callUpdateTicketStatus(id);
                });

                result.put("status", 200);
                result.put("response", "Response Saved");
            } else {
                result.put("status", 302);
                result.put("response", "No Question response sent");
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception : {}", e);
            ticketRepository.callUpdateTicketStatus(trwListDuplicated.get(0).getTicket().getTicketId());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private List<Integer> getTicketIds(List<TicketResponseWrapper> trwList) {
        List<Integer> ticketIds = new ArrayList<>();
        for (TicketResponseWrapper ticketResponse : trwList) {
            ticketIds.add(ticketResponse.getTicket().getTicketId());
        }
        Set<Integer> s = new HashSet<>();
        s.addAll(ticketIds);
        ticketIds = new ArrayList<Integer>();
        ticketIds.addAll(s);
        return ticketIds;
    }

    private List<TicketResponse> getFilteredTicketResponse(List<TicketResponse> tobeInsert, List<TicketResponse> dbTicketResponse) {
        if (dbTicketResponse == null || dbTicketResponse.isEmpty()) {
            return tobeInsert;
        } else if (tobeInsert != null) {
            List<TicketResponse> newList = new ArrayList<>();
            for (TicketResponse tobeInsertItem : tobeInsert) {
                boolean isExist = false;
                for (TicketResponse ticketResponse : dbTicketResponse) {
                    if (ticketResponse.getTicket().getTicketId().equals(tobeInsertItem.getTicket().getTicketId())
                            && ticketResponse.getQuestion().getQuestionId().equals(tobeInsertItem.getQuestion().getQuestionId()) &&
                            ticketResponse.getSequence().equals(tobeInsertItem.getSequence())) {
                        isExist = true;
                    }
                }
                if (!isExist) {
                    newList.add(tobeInsertItem);
                }
            }
            return newList;
        } else {
            return new ArrayList<>();
        }
    }

    private List<Integer> getTicketIdsFromList(List<TicketResponse> tobeInsert) {
        List<Integer> ticketIds = new ArrayList<>();
        for (TicketResponse ticketResponse : tobeInsert) {
            ticketIds.add(ticketResponse.getTicket().getTicketId());
        }
        Set<Integer> s = new HashSet<>();
        s.addAll(ticketIds);
        ticketIds = new ArrayList<Integer>();
        ticketIds.addAll(s);
        return ticketIds;
    }

    private boolean checkIsExist(List<TicketResponse> tobeInsert, TicketResponse ticketResponse) {
        boolean isExist = false;
        if (!tobeInsert.isEmpty())
            for (TicketResponse obj : tobeInsert) {
                if (obj.getQuestion().getQuestionId().equals(ticketResponse.getQuestion().getQuestionId()) && obj.getTicket().getTicketId().equals(ticketResponse.getTicket().getTicketId()) && obj.getSequence().equals(ticketResponse.getSequence())) {
                    isExist = true;
                    break;
                }
            }
        return isExist;
    }

    private String taskImageStore(TicketResponseWrapper trw) {
        try {
            String imagesDir = Constants.imagesDir;
            String filePathStatic = "ticketResponse/" + trw.getTicket().getTicketId() + "/" + trw.getQuestion().getQuestionId() + "/";
            imagesDir = imagesDir + filePathStatic;
            String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss-"));
            String fileName = trw.getTicket().getTicketId() + "_" + trw.getQuestion().getQuestionId() + "_" + trw.getSequence() + "_" + date + ".png";
            log.info("Storing image for ticketResponse : {}, base64Image: {}", trw.toString(), trw.getBase64Image());
            String path = FileUtils.storeBase64Image(trw.getBase64Image(), imagesDir, fileName);
            return filePathStatic + fileName;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in store Image Exception : {}", e.getMessage());
            return null;
        }
    }

    public JSONObject getByTicketIdV2(Object o, Integer ticketId) {
        log.info("get by Ticketid ");
        JSONObject result = new JSONObject();
        try {
            Ticket ticket = ticketRepository.findById(ticketId).get();
            Template template = templateRepository.findById(ticket.getAudit().getTemplate().getTemplateId()).get();
            List<Page> pageList = pageRepository.findByTemplate(template);

            JSONObject mainObject = new JSONObject();
            mainObject.put("ticketId", ticket.getTicketId());
            mainObject.put("siteId", ticket.getSite().getSiteId());
            mainObject.put("status", ticket.getStatus());
            mainObject.put("auditId", ticket.getAudit().getAuditId());
            JSONArray pagesListArray = new JSONArray();
            for (Page page : pageList) {
                List<Question> questionList = questionRepository.findByPageAndParentIdNull(page.getPageId());
                JSONObject pageObject = new JSONObject();
                Boolean hasChildren = false;
                pageObject.put("pageId", page.getPageId());
                pageObject.put("pageName", page.getPageName());
                pageObject.put("sequence", page.getSequence());
                pageObject.put("pageDesc", page.getPageDesc());
                JSONArray questionListArray = new JSONArray();
                for (Question question : questionList) {
                    JSONObject questionObject = new JSONObject();
                    JSONArray questionOptionArray = new JSONArray();
                    if (question.getQuestionType().getIsOption() == true) {
                        List<QuestionTypeOption> questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
                        if (questionTypeOptions != null && questionTypeOptions.size() > 0) {
                            for (QuestionTypeOption qto : questionTypeOptions) {
                                JSONObject questionTypeOptionJSON = new JSONObject();
                                questionTypeOptionJSON.put("questionTypeOptionId", qto.getQuestionTypeOptionId());
                                questionTypeOptionJSON.put("option", qto.getOption());
                                questionOptionArray.add(questionTypeOptionJSON);
                            }
                        }
                    }
                    JSONObject questionTypeJSON = new JSONObject();
                    questionTypeJSON.put("questionTypeId", question.getQuestionType().getQuestionTypeId());
                    questionTypeJSON.put("questionType", question.getQuestionType().getQuestionType());
                    questionTypeJSON.put("isOption", question.getQuestionType().getIsOption());

                    questionObject.put("questionId", question.getQuestionId());
                    questionObject.put("question", question.getQuestion());
                    questionObject.put("sequence", question.getSequence());
                    questionObject.put("questionType", questionTypeJSON);
                    questionObject.put("parentId", question.getParentId());
                    questionObject.put("captureImgStatus", question.getCaptureImgStatus());
                    questionObject.put("questionTypeOptions", questionOptionArray);

                    // Add Child Code here
                    List<Question> childQuestions = questionRepository.findByParentId(question.getQuestionId());
                    if (childQuestions.size() > 0) {
                        hasChildren = true;
                    }
                    JSONArray child = new JSONArray();
                    if (childQuestions != null && childQuestions.size() > 0) {
                        for (Question chq : childQuestions) {
                            JSONObject childObj = new JSONObject();
                            childObj.put("questionId", chq.getQuestionId());
                            childObj.put("question", chq.getQuestion());
                            childObj.put("questionType", chq.getQuestionType());
                            childObj.put("defaultValue", chq.getDefaultValue());
                            childObj.put("isMadatory", chq.getIsMadatory());
                            childObj.put("dataType", chq.getDataType());
                            childObj.put("parentId", chq.getParentId());
                            childObj.put("QuestionSequence", chq.getSequence());
                            JSONArray questionOptionArrayCHD = new JSONArray();
                            if (chq.getQuestionType().getIsOption() == true) {
                                List<QuestionTypeOption> questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
                                if (questionTypeOptions != null && questionTypeOptions.size() > 0) {
                                    for (QuestionTypeOption qto : questionTypeOptions) {
                                        JSONObject questionTypeOptionJSON = new JSONObject();
                                        questionTypeOptionJSON.put("questionTypeOptionId", qto.getQuestionTypeOptionId());
                                        questionTypeOptionJSON.put("option", qto.getOption());
                                        questionOptionArrayCHD.add(questionTypeOptionJSON);
                                    }
                                }
                            }
                            childObj.put("questionTypeOptions", questionOptionArrayCHD);

                            child.add(childObj);
                        }
                    }
                    questionObject.put("children", child);

                    questionListArray.add(questionObject);
                }
                pageObject.put("questions", questionListArray);
                pageObject.put("hasChildren", hasChildren);
                pagesListArray.add(pageObject);
            }
            mainObject.put("pages", pagesListArray);
            result.put("status", 200);
            result.put("response", mainObject);
        } catch (Exception e) {
            log.error("Exception in getByTicketId  exception : {} ", e.getMessage());
            log.trace("Exception in getByTicketId  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");

        }
        return result;

    }

    public JSONObject getByTicketIdV3(Integer ticketId) {
        log.info("get by getByTicketIdV3 ");
        JSONObject result = new JSONObject();
        try {
            Ticket ticket = ticketRepository.findById(ticketId).get();
            Template template = templateRepository.findById(ticket.getAudit().getTemplate().getTemplateId()).get();
            List<Page> pageList = pageRepository.findByTemplate(template);

            JSONObject mainObject = new JSONObject();
            mainObject.put("ticketId", ticket.getTicketId());
            mainObject.put("siteId", ticket.getSite().getSiteId());
            mainObject.put("status", ticket.getStatus());
            mainObject.put("auditId", ticket.getAudit().getAuditId());
            mainObject.put("templateId", template.getTemplateId());
            JSONObject shortageOverage = getShortageOverage(ticketId);
            if (shortageOverage != null){
                mainObject.put("shortage", shortageOverage.get("shortage"));
                mainObject.put("overage", shortageOverage.get("overage"));
            }else{
                mainObject.put("shortage", 0);
                mainObject.put("overage", 0);
            }
            JSONArray pagesListArray = new JSONArray();
            pageList.sort((m1, m2) -> m1.getSequence().equals(m2.getSequence()) ? 0 : m1.getSequence() > m2.getSequence() ? 1 : -1);
            for (Page page : pageList) {
                List<Question> questionList = questionRepository.findByPageAndParentIdNull(page.getPageId());
                String drivedParticipentStr = questionRepository.findDrivedParticipantList(page.getPageId());
                List<String> drivedParticipentList = new ArrayList<>();
                if (drivedParticipentStr != null && !drivedParticipentStr.isEmpty()){
                    drivedParticipentList = new ArrayList<String>(Arrays.asList(drivedParticipentStr.split(",")));
                }
                JSONObject pageObject = new JSONObject();
                Boolean hasChildren = false;
                Boolean isInfluencer = false;
                Boolean isPreFilled = false;
                String caption = "";

                pageObject.put("pageId", page.getPageId());
                pageObject.put("pageName", page.getPageName());
                pageObject.put("sequence", page.getSequence());
                pageObject.put("pageDesc", page.getPageDesc());
                pageObject.put("isQR", false);

                JSONArray questionListArray = new JSONArray();
                questionList.sort((m1, m2) -> m1.getSequence().equals(m2.getSequence()) ? 0 : m1.getSequence() > m2.getSequence() ? 1 : -1);

                for (Question questionParent : questionList) {
                    List<Question> childQuestions = questionRepository.findByParentId(questionParent.getQuestionId());
                    List<Question> influencerQuestions =
                            questionRepository.findByInfluenceBy(questionParent.getQuestionId());
                    setQuestionTypeOption(questionParent, pageObject);
                    if (childQuestions != null && childQuestions.size() > 0) {
                        hasChildren = true;
                        pageObject.put("question", questionParent.getQuestion());
                        pageObject.put("questionId", questionParent.getQuestionId());
                        childQuestions.sort((m1, m2) -> m1.getSequence().equals(m2.getSequence()) ? 0 : m1.getSequence() > m2.getSequence() ? 1 : -1);
                        for (int i = 0; i < childQuestions.size(); i++) {
                            Question question = childQuestions.get(i);
                            if (question.getQuestionType().getQuestionType().equalsIgnoreCase("QR") && i == 0) {
                                questionListArray.add(getQuestionObjectIsQRAvailable(question, true, i));
                                questionListArray.add(getQuestionObjectIsQRAvailable(question, false, i));
                            }
                            questionListArray.add(getQuestionObject(question, ticket, drivedParticipentList));
                            if (question.getQuestionType().getQuestionType().equalsIgnoreCase("QR")) {
                                if (question.getIsYesNo() != null && question.getIsYesNo()) {
                                    questionListArray.add(getQuestionObjectQRSub(question, true, null));
                                    questionListArray.add(getQuestionObjectQRSub(question, false, null));
                                }
                                pageObject.put("isQR", true);
                            }
                        }
                    } else if (influencerQuestions != null && influencerQuestions.size() > 0) {
                        isInfluencer = true;
                        pageObject.put("question", questionParent.getQuestion());
                        pageObject.put("questionId", questionParent.getQuestionId());
                        influencerQuestions.sort((m1, m2) -> m1.getSequence().equals(m2.getSequence()) ? 0 : m1.getSequence() > m2.getSequence() ? 1 : -1);
                        for (int i = 0; i < influencerQuestions.size(); i++) {
                            Question question = influencerQuestions.get(i);
                            if (question.getIsPrefilled()) {
                                isPreFilled = true;
                                caption = "ADDRESS: " + ticket.getSite().getSiteAddress() +
                                        " CITY: " + ticket.getSite().getCity() +
                                        " STATE: " + ticket.getSite().getState() +
                                        " PINCODE: " + ticket.getSite().getPincode();
                            }
                            if (question.getQuestionType().getQuestionType().equalsIgnoreCase("QR") && i == 0) {
                                questionListArray.add(getQuestionObjectIsQRAvailable(question, true, i));
                                questionListArray.add(getQuestionObjectIsQRAvailable(question, false, i));
                            }
                            questionListArray.add(getQuestionObject(question, ticket, drivedParticipentList));
                            if (question.getQuestionType().getQuestionType().equalsIgnoreCase("QR")) {
                                if (question.getIsYesNo() != null && question.getIsYesNo()) {
                                    questionListArray.add(getQuestionObjectQRSub(question, true, null));
                                    questionListArray.add(getQuestionObjectQRSub(question, false, null));
                                }
                                pageObject.put("isQR", true);
                            }
                        }
                    } else {
                        pageObject.put("question", null);
                        pageObject.put("questionId", null);
                        questionListArray.add(getQuestionObject(questionParent, ticket, drivedParticipentList));
                    }
                    if (questionParent.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                        if (questionParent.getIsYesNo() != null && questionParent.getIsYesNo()) {
                            questionListArray.add(getQuestionObjectQRSub(questionParent, true,null));
                            questionListArray.add(getQuestionObjectQRSub(questionParent, false,null));
                        }
                        pageObject.put("isQR", true);
                    }
                }
                pageObject.put("questions", questionListArray);
                pageObject.put("hasChildren", hasChildren);
                pageObject.put("isInfluencer", isInfluencer);
                pageObject.put("isPreFilled", isPreFilled);
                pageObject.put("caption", caption);
                Object ticketResponseList =
                        ticketResponseRepository.IsPageAnswered(ticketId, page.getPageId());
                if (ticketResponseList != null && Integer.parseInt(String.valueOf(ticketResponseList)) > 0) {
                    pageObject.put("isFilled", false);
                } else {
                    pageObject.put("isFilled", true);
                }

                pagesListArray.add(pageObject);
            }
            mainObject.put("pages", pagesListArray);
            result.put("status", 200);
            result.put("response", mainObject);
        } catch (Exception e) {
            log.error("Exception in getByTicketId  exception : {} ", e.getMessage());
            log.trace("Exception in getByTicketId  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");

        }
        return result;

    }

    JSONObject getQuestionObject(Question question, Ticket ticket, List<String> drivedParticipentList) {
        JSONObject questionObject = new JSONObject();
        JSONArray questionOptionArray = new JSONArray();
        if (question.getQuestionType().getIsOption() == true) {
            List<QuestionTypeOption> questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
            if (questionTypeOptions != null && questionTypeOptions.size() > 0) {
                for (QuestionTypeOption qto : questionTypeOptions) {
                    JSONObject questionTypeOptionJSON = new JSONObject();
                    questionTypeOptionJSON.put("questionTypeOptionId", qto.getQuestionTypeOptionId());
                    questionTypeOptionJSON.put("option", qto.getOption());
                    questionOptionArray.add(questionTypeOptionJSON);
                }
            }
        }
        questionObject.put("questionTypeId", question.getQuestionType().getQuestionTypeId());
        questionObject.put("questionType", question.getQuestionType().getQuestionType());
        questionObject.put("isOption", question.getQuestionType().getIsOption());
        questionObject.put("questionId", question.getQuestionId());
        questionObject.put("question", question.getQuestion());
        questionObject.put("sequence", question.getSequence());
        questionObject.put("parentId", question.getParentId());
        questionObject.put("influenceBy", question.getInfluenceBy());
        questionObject.put("influencerResponseValue", question.getInfluencerResponseValue());
        questionObject.put("captureImgStatus", question.getCaptureImgStatus());
        questionObject.put("questionTypeOptions", questionOptionArray);
        questionObject.put("isPrefilled", question.getIsPrefilled());
        questionObject.put("prefilledBy", question.getPrefilledBy());
        questionObject.put("isMandatory", question.getIsMadatory());
        questionObject.put("isDerived", question.getIsDerived());
        questionObject.put("operands", question.getOperand());
        questionObject.put("operator", question.getOperator());
        questionObject.put("dataType", question.getDataType());
        if (drivedParticipentList != null && !drivedParticipentList.isEmpty() && drivedParticipentList.contains(String.valueOf(question.getQuestionId()))){
            questionObject.put("isOperand", true);
        }else{
            questionObject.put("isOperand", false);
        }

        String prefilledValue = "";
        if (question.getIsPrefilled()) {
            switch (question.getPrefilledBy()) {
                case "ADDRESS": {
                    prefilledValue = ticket.getSite().getSiteAddress();
                    break;
                }
                case "CITY": {
                    prefilledValue = ticket.getSite().getCity();
                    break;
                }
                case "STATE": {
                    prefilledValue = ticket.getSite().getState();
                    break;
                }
                case "PINCODE": {
                    prefilledValue = ticket.getSite().getPincode();
                    break;
                }
            }
        }
        questionObject.put("prefilledValue", prefilledValue);


        return questionObject;
    }

    void setQuestionTypeOption(Question question, JSONObject pageObject) {
        JSONArray questionOptionArray = new JSONArray();

        if (question.getQuestionType().getIsOption() == true) {
            List<QuestionTypeOption> questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
            if (questionTypeOptions != null && questionTypeOptions.size() > 0) {

                for (QuestionTypeOption qto : questionTypeOptions) {
                    JSONObject questionTypeOptionJSON = new JSONObject();
                    questionTypeOptionJSON.put("questionTypeOptionId", qto.getQuestionTypeOptionId());
                    questionTypeOptionJSON.put("option", qto.getOption());
                    questionOptionArray.add(questionTypeOptionJSON);
                }
            }
        }
        pageObject.put("questionTypeOptions", questionOptionArray);
    }

    public JSONObject getHomeData(Users user) {
        JSONObject result = new JSONObject();
        try {
            List<Object[]> currentObj = ticketRepository.getCurrentAuditByUser(user.getUserId());
           List<Object[]> scheduledObj = ticketRepository.getScheduledAuditByUser(user.getUserId());
            JSONObject response = new JSONObject();
            JSONObject currentAudit = new JSONObject();
            currentAudit.put("totalCount", currentObj.get(0)[0]);
            currentAudit.put("pendingCount", currentObj.get(0)[1] != null ? currentObj.get(0)[1] : 0);
            currentAudit.put("completeCount", currentObj.get(0)[2] != null ? currentObj.get(0)[2] : 0);
            response.put("currentAudit", currentAudit);

            ConfigProperties configProperties = configPropertiesRepository.findByType("LIMIT");
            JSONObject upcomingAudit = new JSONObject();
            upcomingAudit.put("totalCount", 0);
            upcomingAudit.put("upcomingDate", "NA");
            response.put("upcomingAudit", upcomingAudit);
            response.put("maxLimitForOffline", Integer.valueOf(configProperties.getValue()));
            result.put("status", 200);
            result.put("response", response);

            JSONObject scheduledAudit = new JSONObject();
            scheduledAudit.put("totalCount", scheduledObj.get(0)[0]);
            scheduledAudit.put("pendingCount", scheduledObj.get(0)[1] != null ? scheduledObj.get(0)[1] : 0);
            scheduledAudit.put("completeCount", scheduledObj.get(0)[2] != null ? scheduledObj.get(0)[2] : 0);
            response.put("scheduledAudit", scheduledAudit);

        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getOfflineData(Users user) {
        JSONObject result = new JSONObject();
        try {
            // 1 take HomeData
            // 2 take DashboardData of Pending tickets
            // 3 getAtmData
            // 4 get ticketData
            //===========================HOME DATA======================
            List<Object[]> homeDataObj = ticketRepository.getCurrentAuditByUser(user.getUserId());
//            List<Object[]> currentObj = ticketRepository.getCurrentAuditByUser(9);
            JSONObject homeData = new JSONObject();
            JSONObject currentAudit = new JSONObject();
            currentAudit.put("totalCount", homeDataObj.get(0)[0]);
            currentAudit.put("pendingCount", homeDataObj.get(0)[1] != null ? homeDataObj.get(0)[1] : 0);
            currentAudit.put("completeCount", homeDataObj.get(0)[2] != null ? homeDataObj.get(0)[2] : 0);
            currentAudit.put("PENDING_DATA", getDashboardDataOffline(user,false));
            homeData.put("currentAudit", currentAudit);

            JSONObject upcomingAudit = new JSONObject();
            upcomingAudit.put("totalCount", 0);
            upcomingAudit.put("upcomingDate", "NA");
            homeData.put("upcomingAudit", upcomingAudit);


            List<Object[]> scheduledAuditObj = ticketRepository.getCurrentAuditByUserScheduled(user.getUserId());

            JSONObject scheduledAudit = new JSONObject();
            scheduledAudit.put("totalCount", scheduledAuditObj.get(0)[0]);
            scheduledAudit.put("pendingCount", scheduledAuditObj.get(0)[1] != null ? scheduledAuditObj.get(0)[1] : 0);
            scheduledAudit.put("completeCount", scheduledAuditObj.get(0)[2] != null ? scheduledAuditObj.get(0)[2] : 0);
            scheduledAudit.put("PENDING_DATA", getDashboardDataOffline(user, true));

            homeData.put("scheduledAudit", scheduledAudit);

            result.put("status", 200);
            result.put("response", homeData);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private JSONArray getDashboardDataOffline(Users user, boolean isScheduled) {
        List<Object[]> dashboardDatalist  = new ArrayList<>();
        if (isScheduled){
          dashboardDatalist = ticketRepository.getDashboardDataOffline(user.getUserId());
        }else{
            dashboardDatalist = ticketRepository.getDashboardData(user.getUserId());
        }
        JSONArray dashboardData = new JSONArray();
        if (dashboardDatalist != null) {
            for (Object[] obj : dashboardDatalist) {
                JSONObject data = new JSONObject();
                data.put("auditName", obj[0]);
                data.put("startDate", obj[1]);
                data.put("endDate", obj[2]);
                data.put("doneCount", obj[3]);
                data.put("pendingCount", obj[4]);
                data.put("total", obj[5]);
                data.put("auditId", obj[6]);
                data.put("auditData", getAtmForAuditOffline(Integer.parseInt(String.valueOf(obj[6])), user));
                dashboardData.add(data);
            }
        }
        return dashboardData;
    }

    private List<Ticket> getAtmForAuditOffline(Integer auditId, Users user) {
        List<Ticket> ticketList = ticketRepository.findPendingOfflineDataByAuditAndStatus(auditId, "COMPLETED", user.getUserId());
        ticketList.forEach(ticket -> {
            ticket.setTicketData(getTicketDetailOffline(ticket));
        });
        return ticketList;
    }

    private JSONObject getTicketDetailOffline(Ticket ticket) {
        Template template = templateRepository.findById(ticket.getAudit().getTemplate().getTemplateId()).get();
        List<Page> pageList = pageRepository.findByTemplate(template);

        JSONObject mainObject = new JSONObject();
        mainObject.put("ticketId", ticket.getTicketId());
        mainObject.put("siteId", ticket.getSite().getSiteId());
        mainObject.put("status", ticket.getStatus());
        mainObject.put("auditId", ticket.getAudit().getAuditId());
        JSONArray pagesListArray = new JSONArray();
        for (Page page : pageList) {
            List<Question> questionList = questionRepository.findByPageAndParentIdNull(page.getPageId());
            String drivedParticipentStr = questionRepository.findDrivedParticipantList(page.getPageId());
            List<String> drivedParticipentList = new ArrayList<>();
            if (drivedParticipentStr != null && !drivedParticipentStr.isEmpty()){
                drivedParticipentList = new ArrayList<String>(Arrays.asList(drivedParticipentStr.split(",")));
            }
            JSONObject pageObject = new JSONObject();
            Boolean hasChildren = false;
            Boolean isInfluencer = false;
            Boolean isPreFilled = false;
            String caption = "";

            pageObject.put("pageId", page.getPageId());
            pageObject.put("pageName", page.getPageName());
            pageObject.put("sequence", page.getSequence());
            pageObject.put("pageDesc", page.getPageDesc());
            pageObject.put("isQR", false);
            JSONArray questionListArray = new JSONArray();
            for (Question questionParent : questionList) {
                List<Question> childQuestions = questionRepository.findByParentId(questionParent.getQuestionId());
                List<Question> influencerQuestions =
                        questionRepository.findByInfluenceBy(questionParent.getQuestionId());
                setQuestionTypeOption(questionParent, pageObject);
                if (childQuestions != null && childQuestions.size() > 0) {
                    hasChildren = true;
                    pageObject.put("question", questionParent.getQuestion());
                    pageObject.put("questionId", questionParent.getQuestionId());
                    for (Question question : childQuestions) {
                        questionListArray.add(getQuestionObject(question, ticket,drivedParticipentList));
                    }
                } else if (influencerQuestions != null && influencerQuestions.size() > 0) {
                    isInfluencer = true;
                    pageObject.put("question", questionParent.getQuestion());
                    pageObject.put("questionId", questionParent.getQuestionId());

                    for (Question question : influencerQuestions) {
                        if (question.getIsPrefilled()) {
                            isPreFilled = true;
                            caption = "ADDRESS: " + ticket.getSite().getSiteAddress() +
                                    " CITY: " + ticket.getSite().getCity() +
                                    " STATE: " + ticket.getSite().getState() +
                                    " PINCODE: " + ticket.getSite().getPincode();
                        }
                        questionListArray.add(getQuestionObject(question, ticket,drivedParticipentList));
                    }
                } else {
                    pageObject.put("question", null);
                    pageObject.put("questionId", null);
                    questionListArray.add(getQuestionObject(questionParent, ticket,drivedParticipentList));
                }
                if (questionParent.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                    pageObject.put("isQR", true);
                }
            }
            pageObject.put("questions", questionListArray);
            pageObject.put("hasChildren", hasChildren);
            pageObject.put("isInfluencer", isInfluencer);
            pageObject.put("isPreFilled", isPreFilled);
            pageObject.put("caption", caption);
            Object ticketResponseList =
                    ticketResponseRepository.IsPageAnswered(ticket.getTicketId(), page.getPageId());
            if (ticketResponseList != null && Integer.parseInt(String.valueOf(ticketResponseList)) > 0) {
                pageObject.put("isFilled", false);
            } else {
                pageObject.put("isFilled", true);
            }
            pagesListArray.add(pageObject);
        }
        mainObject.put("pages", pagesListArray);
        return mainObject;
    }

    public JSONObject getPreviewData(Integer ticketId) {
        log.info("get by getPreviewData ");
        JSONObject result = new JSONObject();
        try {
            Ticket ticket = ticketRepository.findById(ticketId).get();
            Template template = templateRepository.findById(ticket.getAudit().getTemplate().getTemplateId()).get();
            List<Page> pageList = pageRepository.findByTemplate(template);

            JSONObject mainObject = new JSONObject();
            mainObject.put("ticketId", ticket.getTicketId());
            mainObject.put("siteId", ticket.getSite().getSiteId());
            mainObject.put("status", ticket.getStatus());
            mainObject.put("auditId", ticket.getAudit().getAuditId());
            JSONArray pagesListArray = new JSONArray();
            for (Page page : pageList) {
                List<Question> questionList = questionRepository.findByPageAndParentIdNull(page.getPageId());
                JSONObject pageObject = new JSONObject();
                Boolean hasChildren = false;
                Boolean isInfluencer = false;
                Boolean isPreFilled = false;
                String caption = "";

                pageObject.put("pageId", page.getPageId());
                pageObject.put("pageName", page.getPageName());
                pageObject.put("sequence", page.getSequence());
                pageObject.put("pageDesc", page.getPageDesc());
                JSONArray questionListArray = new JSONArray();
                for (Question questionParent : questionList) {
                    List<Question> childQuestions = questionRepository.findByParentId(questionParent.getQuestionId());
                    List<Question> influencerQuestions =
                            questionRepository.findByInfluenceBy(questionParent.getQuestionId());
                    setQuestionTypeOption(questionParent, pageObject);
                    if (childQuestions != null && childQuestions.size() > 0) {
                        hasChildren = true;
                        pageObject.put("question", questionParent.getQuestion());
                        pageObject.put("questionId", questionParent.getQuestionId());
                        for (Question question : childQuestions) {
                            questionListArray.add(getQuestionObjectNew(question, ticket));
                        }
                    } else if (influencerQuestions != null && influencerQuestions.size() > 0) {
                        isInfluencer = true;
                        pageObject.put("question", questionParent.getQuestion());
                        pageObject.put("questionId", questionParent.getQuestionId());

                        for (Question question : influencerQuestions) {
                            if (question.getIsPrefilled()) {
                                isPreFilled = true;
                                caption = "ADDRESS: " + ticket.getSite().getSiteAddress() +
                                        " CITY: " + ticket.getSite().getCity() +
                                        " STATE: " + ticket.getSite().getState() +
                                        " PINCODE: " + ticket.getSite().getPincode();
                            }
                            questionListArray.add(getQuestionObjectNew(question, ticket));
                        }
                    } else {
                        pageObject.put("question", null);
                        pageObject.put("questionId", null);
                        questionListArray.add(getQuestionObjectNew(questionParent, ticket));
                    }
                }
                pageObject.put("questions", questionListArray);
                pageObject.put("hasChildren", hasChildren);
                pageObject.put("isInfluencer", isInfluencer);
                pageObject.put("isPreFilled", isPreFilled);
                pageObject.put("caption", caption);
                Object ticketResponseList =
                        ticketResponseRepository.IsPageAnswered(ticketId, page.getPageId());
                if (ticketResponseList != null && Integer.parseInt(String.valueOf(ticketResponseList)) > 0) {
                    pageObject.put("isFilled", false);
                } else {
                    pageObject.put("isFilled", true);
                }

                pagesListArray.add(pageObject);
            }
            mainObject.put("pages", pagesListArray);
            result.put("status", 200);
            result.put("response", mainObject);
        } catch (Exception e) {
        	e.printStackTrace();
            log.error("Exception in getPreviewData  exception : {} ", e.getMessage());
            log.trace("Exception in getPreviewData  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");

        }
        return result;

    }

    JSONObject getQuestionObjectNew(Question question, Ticket ticket) {
        JSONObject questionObject = new JSONObject();
        JSONArray questionOptionArray = new JSONArray();
        if (question.getQuestionType().getIsOption() == true) {
            List<QuestionTypeOption> questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
            if (questionTypeOptions != null && questionTypeOptions.size() > 0) {
                for (QuestionTypeOption qto : questionTypeOptions) {
                    JSONObject questionTypeOptionJSON = new JSONObject();
                    questionTypeOptionJSON.put("questionTypeOptionId", qto.getQuestionTypeOptionId());
                    questionTypeOptionJSON.put("option", qto.getOption());
                    questionOptionArray.add(questionTypeOptionJSON);
                }
            }
        }
        questionObject.put("questionTypeId", question.getQuestionType().getQuestionTypeId());
        questionObject.put("questionType", question.getQuestionType().getQuestionType());
        questionObject.put("isOption", question.getQuestionType().getIsOption());
        questionObject.put("questionId", question.getQuestionId());
        questionObject.put("question", question.getQuestion());
        questionObject.put("sequence", question.getSequence());
        questionObject.put("parentId", question.getParentId());
        questionObject.put("influenceBy", question.getInfluenceBy());
        questionObject.put("influencerResponseValue", question.getInfluencerResponseValue());
        questionObject.put("captureImgStatus", question.getCaptureImgStatus());
        questionObject.put("questionTypeOptions", questionOptionArray);
        questionObject.put("isPrefilled", question.getIsPrefilled());
        questionObject.put("prefilledBy", question.getPrefilledBy());
        questionObject.put("isMandatory", question.getIsMadatory());
        questionObject.put("isDerived", question.getIsDerived());
        questionObject.put("operands", question.getOperand());
        questionObject.put("operator", question.getOperator());
        questionObject.put("dataType", question.getDataType());

        String prefilledValue = "";
        if (question.getIsPrefilled()) {
            switch (question.getPrefilledBy()) {
                case "ADDRESS": {
                    prefilledValue = ticket.getSite().getSiteAddress();
                    break;
                }
                case "CITY": {
                    prefilledValue = ticket.getSite().getCity();
                    break;
                }
                case "STATE": {
                    prefilledValue = ticket.getSite().getState();
                    break;
                }
                case "PINCODE": {
                    prefilledValue = ticket.getSite().getPincode();
                    break;
                }
            }
        }
        questionObject.put("prefilledValue", prefilledValue);
        List<TicketResponse> getTicketResponse = ticketResponseRepository.findByQuestionAndTicket(question, ticket);
        JSONArray ticketResponseArray=new JSONArray();
        if(getTicketResponse !=null && !getTicketResponse.isEmpty()) {
        	for(TicketResponse ticketResponse:getTicketResponse) {
        	JSONObject ticketResponseObject=new JSONObject();
        	ticketResponseObject.put("ticketResponseId", ticketResponse.getTicketResponseId());
        	ticketResponseObject.put("response", ticketResponse.getResponse());
        	ticketResponseArray.add(ticketResponseObject);
        	}

        }
        if(ticketResponseArray !=null && !ticketResponseArray.isEmpty()) {
        	 questionObject.put("ticketResponse", ticketResponseArray);
        	 questionObject.put("isAnswer", true);
        }else {
        	 questionObject.put("isAnswer", false);
        }


        return questionObject;
    }

    public JSONObject updatePreviewResponse(List<TicketResponseWrapper> trwList) {
        JSONObject result = new JSONObject();
        try {
            Date date = new Date();
            if (trwList != null && trwList.size() > 0) {
                List<TicketResponse> tobeInsert = new ArrayList<>();
                List<TicketResponse> dbTicketResponse = ticketResponseRepository.findByTicketIds(getTicketIds(trwList));
                for (TicketResponseWrapper trw : trwList) {
                	if(trw.getTicketResponseId()==null) {
                    if (trw.getResponse() == null || trw.getResponse().trim().isEmpty()) {
                        result.put("status", 302);
                        result.put("response", "Response can't be Blank");
                        return result;
                    }
                    List<TicketResponse> trCheckList = ticketResponseRepository.findByQuestionAndTicket(trw.getQuestion(), trw.getTicket());
                    if (trCheckList == null || trCheckList.size() < 1) {
                        TicketResponse ticketResponse = new TicketResponse();
                        ticketResponse.setTicket(trw.getTicket());
                        ticketResponse.setQuestion(trw.getQuestion());
                        ticketResponse.setResponse(trw.getResponse());
                        ticketResponse.setCreatedBy(1); // todo change when login is implemented
                        ticketResponse.setUpdatedBy(1); // todo change when login is implemented
                        ticketResponse.setCreatedDate(date);
                        ticketResponse.setSequence(trw.getSequence());
                        ticketResponse.setLastUpdatedDate(date);
                        ticketResponse.setLatitude(trw.getLatitude());
                        ticketResponse.setLongitude(trw.getLongitude());
                        ticketResponse.setIsEdited(false);
                        if (trw.getBase64Image() != null && !trw.getBase64Image().trim().isEmpty()) {
                            String path = taskImageStore(trw);
                            ticketResponse.setImagePath(path);
                        }
                        if (!checkIsExist(tobeInsert, ticketResponse)) {
                            tobeInsert.add(ticketResponse);
                        }
                    }
                	}else {
                		TicketResponse ticketResponse=ticketResponseRepository.findById(trw.getTicketResponseId()).get();
                		if(ticketResponse!=null) {
                			if(trw.getTicket()!=null) {
                             ticketResponse.setTicket(trw.getTicket());
                			}
                			if(trw.getQuestion()!=null) {
                             ticketResponse.setQuestion(trw.getQuestion());
                			}
                			if(trw.getResponse()!=null && !trw.getResponse().isEmpty()) {
                             ticketResponse.setResponse(trw.getResponse());
                			}

                             ticketResponse.setUpdatedBy(1); // todo change when login is implemented
                             if(trw.getSequence()!=null ) {
                             ticketResponse.setSequence(trw.getSequence());
                             }

                             ticketResponse.setLastUpdatedDate(date);
                             if(trw.getLatitude()!=null) {
                             ticketResponse.setLatitude(trw.getLatitude());
                             }
                             if(trw.getLongitude()!=null) {
                             ticketResponse.setLongitude(trw.getLongitude());
                             }
                             if (trw.getBase64Image() != null && !trw.getBase64Image().trim().isEmpty()) {
                                 String path = taskImageStore(trw);
                                 ticketResponse.setImagePath(path);
                             }
                             ticketResponse.setIsEdited(true);
                             if (!checkIsExist(tobeInsert, ticketResponse)) {
                                 tobeInsert.add(ticketResponse);
                             }
                		}
                	}
                }
                Set<TicketResponse> s = new HashSet<>();
                s.addAll(tobeInsert);
                tobeInsert = new ArrayList<TicketResponse>();
                tobeInsert.addAll(s);
                List<TicketResponse> inserted = ticketResponseRepository.saveAll(tobeInsert);

                List<Integer> ticketIds = getTicketIdsFromList(tobeInsert);
                ticketIds.forEach(id -> {
                    ticketRepository.callUpdateTicketStatus(id);
                });

                result.put("status", 200);
                result.put("response", "Response Saved");
            } else {
                result.put("status", 302);
                result.put("response", "No Question response sent");
            }

        } catch (Exception e) {
            e.printStackTrace();
            ticketRepository.callUpdateTicketStatus(trwList.get(0).getTicket().getTicketId());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getShortageOverage(Integer ticketId) {
        JSONObject response = new JSONObject();
        try {
            List<Object[]> objects = auditRepository.getShortageOverage(ticketId);
            Map<Integer, List<CashMasterDTO>> map = new HashMap<>();

            List<CashMasterDTO> tempList = new ArrayList<>();

            if (objects != null) {
                objects.forEach(object -> {
                    CashMasterDTO cashMasterDTO = new CashMasterDTO();
                    cashMasterDTO.setTicketId(Integer.parseInt(String.valueOf(object[0])));
                    cashMasterDTO.setDate(String.valueOf(object[1]));
                    cashMasterDTO.setQuestionId(Integer.parseInt(String.valueOf(object[2])));
                    cashMasterDTO.setSiteId(Integer.parseInt(String.valueOf(object[3])));
                    cashMasterDTO.setResponse(String.valueOf(object[4]));
                    cashMasterDTO.setSequence(Integer.parseInt(String.valueOf(object[5])));
                    tempList.add(cashMasterDTO);
                });

            }

            Map<Integer, Site> siteMap = AuditApplication.siteMap.values().stream()
                    .collect(Collectors.toList()).stream().collect(
                            Collectors.toMap(Site::getSiteId, Site::getClassObject));

              response =   getCashRowDataWithCalculationV2(ticketId, tempList, siteMap);

            return response;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in getShortageOverage {} " ,e.getMessage());
            response.put("shortage", "0");
            response.put("overage", "0");
            return response;
        }
    }


    private JSONObject getCashRowDataWithCalculationV2(Integer ticketId, List<CashMasterDTO> cashMasterDTO, Map<Integer, Site> siteMap) {
        Map<Integer, CashMasterDTO> responseMap = cashMasterDTO.stream().collect(
                Collectors.toMap(CashMasterDTO::getQuestionId, CashMasterDTO::getClassObject));

        Integer physicalTotal = (getIntegerValue(getStringValue(responseMap.get(449))) * 100) +
                (getIntegerValue(getStringValue(responseMap.get(455))) * 200) +
                (getIntegerValue(getStringValue(responseMap.get(464))) * 500) +
                (getIntegerValue(getStringValue(responseMap.get(470))) * 2000);

        Integer atmTotal = (getIntegerValue(getStringValue(responseMap.get(477))) * 100) +
                (getIntegerValue(getStringValue(responseMap.get(484))) * 200) +
                (getIntegerValue(getStringValue(responseMap.get(491))) * 500) +
                (getIntegerValue(getStringValue(responseMap.get(498))) * 2000);

        Integer switchTotal = (getIntegerValue(getStringValue(responseMap.get(505)))) +
                (getIntegerValue(getStringValue(responseMap.get(512)))) +
                (getIntegerValue(getStringValue(responseMap.get(519)))) +
                (getIntegerValue(getStringValue(responseMap.get(526))));

        Integer shortage = 0;
        if (atmTotal.equals(switchTotal)) {
            shortage = (switchTotal - physicalTotal);
        }
        JSONObject response = new JSONObject();
        response.put("shortage", (shortage > 0 ? shortage : 0) + "");
        response.put("overage", (shortage < 0 ? (physicalTotal - switchTotal) : 0) + "");


        return response;
    }

    public String getStringValue(CashMasterDTO cashMasterDTO) {
        if (cashMasterDTO != null) {
            return cashMasterDTO.getResponse();
        } else {
            return "";
        }
    }

    public Integer getIntegerValue(String sValue) {
        if (sValue == null || sValue.trim().isEmpty()) {
            return 0;
        } else {
            try {
                Float floatValue = Float.parseFloat(sValue);

                return floatValue.intValue();
            } catch (Exception e) {
                log.error("Exception in parsing Integer : {}", e.getMessage());
                return 0;
            }
        }
    }

    public JSONObject getPreviewDataByTicketId(Integer ticketId ) {
        log.info(this.getClass().getName() + " :- getPreviewDataByTicketId(),ticketId:{}",ticketId);
        JSONObject result = new JSONObject();
        try {
            List<JSONObject> ticketResponse = getTicketResponseJSON(ticketId);
            if (ticketResponse != null) {
                List<JSONObject> list = new ArrayList<>();
                Map<String, List<JSONObject>> ticketResponseMap =
                        ticketResponse.stream().collect(Collectors.groupingBy(object -> String.valueOf(object.get("pageName")))).entrySet()
                                .stream().filter(entry -> entry.getValue().size() > 0)
                                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                ticketResponseMap.forEach((s, objects) -> {
                            JSONObject tempObj = new JSONObject();
                            objects.sort((m1, m2) -> {
                                if(Integer.parseInt(String.valueOf(m1.get("questionSequence"))) == Integer.parseInt(String.valueOf(m2.get("questionSequence")))){
                                    return 0;
                                }
                                if(Integer.parseInt(String.valueOf(m1.get("questionSequence"))) > Integer.parseInt(String.valueOf(m2.get("questionSequence")))){
                                    return 1;
                                }else{
                                    return -1;
                                }
                            });
                            tempObj.put("page",s);
                            tempObj.put("pageSequence",objects.get(0).get("pageSequence"));
                            tempObj.put("questionResponses", objects);
                            list.add(tempObj);
                        }
                );
                list.sort((m1, m2) -> {
                    if(Integer.parseInt(String.valueOf(m1.get("pageSequence"))) == Integer.parseInt(String.valueOf(m2.get("pageSequence")))){
                        return 0;
                    }
                    if(Integer.parseInt(String.valueOf(m1.get("pageSequence"))) > Integer.parseInt(String.valueOf(m2.get("pageSequence")))){
                        return 1;
                    }else{
                        return -1;
                    }
                });
                result.put("status", 200);
                result.put("response", list);
                result.put("message", "Ticket Response is found.");

            } else {
                result.put("status", 302);
                result.put("response", "TicketResponse Not found");
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in getPreviewDataByTicketId for ticketid : {} and exception : {} ", ticketId, e.getMessage());
            log.trace("Exception in getPreviewDataByTicketId for ticketid : {} and trace : {} ", ticketId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private List<JSONObject> getTicketResponseJSON(Integer ticketId) {
        try{
            List<JSONObject> result = new ArrayList<>();
            List<Object[]> list = ticketResponseRepository.getPreviewDataByTicketId(ticketId);
            if (list != null){
                list.forEach(object -> {
                    JSONObject response = new JSONObject();
                    response.put("ticketResponseId", object[0]);
                    response.put("question", object[1]);
                    response.put("pageName", object[2]);
                    response.put("response", object[3]);
                    response.put("imagePath", object[4]);
                    response.put("questionSequence", object[5]);
                    response.put("questionId", object[6]);
                    response.put("pageSequence", object[7]);
                    response.put("isEditable", true);

                    result.add(response);
                });
                return result;
            }else{
                return null;
            }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public JSONObject updatePreviewDataResponse(JSONObject request) {
        log.info("updatePreviewDataResponse()");
        JSONObject result = new JSONObject();
        try {
            Integer ticketResponseId = Integer.parseInt(String.valueOf(request.get("ticketResponseId")));
            String response = String.valueOf(request.get("response"));
            if(ticketResponseId == null){
                result.put("status", 302);
                result.put("response", "Ticket response id not found");
            }
            if(response == null || response.isEmpty()){
                result.put("status", 302);
                result.put("response", "Response not found");
            }
            TicketResponse ticketResponse = ticketResponseRepository.findById(ticketResponseId).get();
            if(ticketResponse == null){
                result.put("status", 302);
                result.put("response", "Ticket Response not found");
            }
            ticketResponse.setResponse(response);
            ticketResponse.setLastUpdatedDate(new Date());
            ticketResponse.setUpdatedBy(1);
            ticketResponseRepository.save(ticketResponse);

            result.put("status", 200);
            result.put("response", "Response updated successfully.");

        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getDashboardDataScheduled(JSONObject request, Users user) {
        log.info("get getDashboardDataScheduled()");
        JSONObject result = new JSONObject();
        try {
            List<Object[]> list = ticketRepository.getDashboardDataScheduled(user.getUserId());  // bypass
            JSONArray dataList = new JSONArray();
            for (Object[] obj : list) {
                JSONObject data = new JSONObject();
                data.put("auditName", obj[0]);
                data.put("startDate", obj[1]);
                data.put("endDate", obj[2]);
                data.put("doneCount", obj[3]);
                data.put("pendingCount", obj[4]);
                data.put("total", obj[5]);
                data.put("auditId", obj[6]);
                data.put("adhocTicketCount", obj[7]);
                dataList.add(data);
            }
            result.put("status", 200);
            result.put("response", dataList);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("exception in getDashboardDataScheduled() for user : {}, and exception : {}", user.toString(), e.getMessage());
            log.error("Trace exception in getDashboardDataScheduled() for user : {}, and exception : {}", user.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    JSONObject getQuestionObjectQRSub(Question questionParent, boolean isOption, Integer sequence) {
        JSONObject questionObject = new JSONObject();
        JSONArray questionOptionArray = new JSONArray();
        if (isOption) {
            JSONObject yes = new JSONObject();
            yes.put("questionTypeOptionId", 261);
            yes.put("option", "YES");

            JSONObject no = new JSONObject();
            no.put("questionTypeOptionId", 262);
            no.put("option", "NO");
            questionOptionArray.add(yes);
            questionOptionArray.add(no);
        }
        questionObject.put("questionTypeId", isOption ? 3 : 1);
        questionObject.put("questionType", isOption ? "radio_button" : "simple_text");
        questionObject.put("isOption", isOption);
        if (sequence != null){
            questionObject.put("questionId", Integer.parseInt(questionParent.getQuestionId() + "" + (isOption ? "001" : "002") + "" + sequence));
            questionObject.put("influenceBy", isOption ? Integer.parseInt(questionParent.getQuestionId()+ "002" + "" + sequence):null) ;

        }else {
            questionObject.put("questionId", Integer.parseInt(questionParent.getQuestionId() + "" + (isOption ? "001" : "002")));
            questionObject.put("influenceBy", isOption ? Integer.parseInt(questionParent.getQuestionId()+ "002"):null) ;

        }
        questionObject.put("question", isOption ? "Is Correct" : "Remark");
        questionObject.put("sequence", questionParent.getSequence());
        questionObject.put("parentId", null);
        questionObject.put("influencerResponseValue",isOption ? questionParent.getInfluencerResponseValue() : "NO");
        questionObject.put("captureImgStatus", 0);
        questionObject.put("questionTypeOptions", questionOptionArray);
        questionObject.put("isPrefilled", false);
        questionObject.put("prefilledBy", null);
        questionObject.put("isMandatory", isOption);
        questionObject.put("isDerived", false);
        questionObject.put("operands", "");
        questionObject.put("operator", "");
        questionObject.put("dataType", "Alphanumeric");
        questionObject.put("isOperand", false);
        questionObject.put("prefilledValue", "");
        return questionObject;
    }

    JSONObject getQuestionObjectIsQRAvailable(Question questionParent, boolean isAvailable, Integer sequence) {
        JSONObject questionObject = new JSONObject();
        JSONArray questionOptionArray = new JSONArray();
        if (isAvailable) {
            JSONObject yes = new JSONObject();
            yes.put("questionTypeOptionId", 261);
            yes.put("option", "YES");

            JSONObject no = new JSONObject();
            no.put("questionTypeOptionId", 262);
            no.put("option", "NO");
            questionOptionArray.add(yes);
            questionOptionArray.add(no);
        }else{
            JSONObject option1 = new JSONObject();
            option1.put("questionTypeOptionId", 2611);
            option1.put("option", "QR code not available due to tempering");

            JSONObject option2 = new JSONObject();
            option2.put("questionTypeOptionId", 2621);
            option2.put("option", "QR code cannot be scanned");

            JSONObject option3 = new JSONObject();
            option3.put("questionTypeOptionId", 2631);
            option3.put("option", "QR code is not received from Head Office");
            questionOptionArray.add(option1);
            questionOptionArray.add(option2);
            questionOptionArray.add(option3);
        }
        questionObject.put("questionTypeId", isAvailable ? 3 : 4);
        questionObject.put("questionType", isAvailable ? "radio_button" : "dropdown");
        questionObject.put("isOption", true);
        if (sequence != null){
            questionObject.put("questionId", Integer.parseInt(questionParent.getQuestionId() + "" + (isAvailable ? "003" : "004") + "" + sequence));
            questionObject.put("influenceBy", isAvailable ? Integer.parseInt(questionParent.getQuestionId()+ "004" + "" + sequence):null) ;

        }else {
            questionObject.put("questionId", Integer.parseInt(questionParent.getQuestionId() + "" + (isAvailable ? "003" : "004")));
            questionObject.put("influenceBy", isAvailable ? Integer.parseInt(questionParent.getQuestionId()+ "004"):null) ;

        }
        questionObject.put("question", isAvailable ? "Is QR Available" : "Reason");
        questionObject.put("sequence", questionParent.getSequence());
        questionObject.put("parentId", null);
        questionObject.put("influencerResponseValue",isAvailable ? questionParent.getInfluencerResponseValue() : "NO");
        questionObject.put("captureImgStatus", 0);
        questionObject.put("questionTypeOptions", questionOptionArray);
        questionObject.put("isPrefilled", false);
        questionObject.put("prefilledBy", null);
        questionObject.put("isMandatory", isAvailable);
        questionObject.put("isDerived", false);
        questionObject.put("operands", "");
        questionObject.put("operator", "");
        questionObject.put("dataType", "Alphanumeric");
        questionObject.put("isOperand", false);
        questionObject.put("prefilledValue", "");
        return questionObject;
    }

    public JSONObject submitParentQuestionResponse(TicketResponseWrapper ticketResponseWrapper) {
        log.info("submitParentQuestionResponse  :{}", ticketResponseWrapper);
        JSONObject result = new JSONObject();
        try {
            if (ticketResponseWrapper.getResponse().trim().isEmpty()) {
                result.put("status", 302);
                result.put("message", "Response can't be Blank");
                result.put("response", "Response can't be Blank");
                return result;
            }
            Ticket ticket = ticketRepository.findById(ticketResponseWrapper.getTicket().getTicketId()).orElse(null);
            if (ticket == null) {
                result.put("status", 302);
                result.put("message", "Ticket Id not found");
                result.put("response", "Ticket Id not found");
                return result;
            }
            Question questionParent = questionRepository.findById(ticketResponseWrapper.getQuestion().getQuestionId()).orElse(null);
            if (questionParent == null) {
                result.put("status", 302);
                result.put("message", "Question Id not found");
                result.put("response", "Question Id not found");
                return result;
            }
            List<TicketResponse> trCheckList = ticketResponseRepository.findByQuestionAndTicket(ticketResponseWrapper.getQuestion(), ticketResponseWrapper.getTicket());
            if (trCheckList != null && !trCheckList.isEmpty()) {
                result.put("status", 302);
                result.put("message", "Response Already submitted");
                result.put("response", "Response Already submitted");
                return result;
            }

            List<Question> childQuestions = questionRepository.findByParentId(questionParent.getQuestionId());

            if (childQuestions == null || childQuestions.isEmpty()) {
                result.put("status", 302);
                result.put("message", "Child Questions not found");
                result.put("response", "Child Questions not found");
                return result;
            }

            childQuestions.sort((m1, m2) -> m1.getSequence().equals(m2.getSequence()) ? 0 : m1.getSequence() > m2.getSequence() ? 1 : -1);

            JSONArray pageList = new JSONArray();

            for (int i = 1; i<= Integer.parseInt(ticketResponseWrapper.getResponse()); i++){
                JSONArray questionListArray = new JSONArray();
                JSONObject page = new JSONObject();

                for (int j = 0; j < childQuestions.size(); j++) {
                    Question question = childQuestions.get(j);
                    if (question.getQuestionType().getQuestionType().equalsIgnoreCase("QR") && j == 0) {
                        questionListArray.add(getQuestionObjectIsQRAvailable(question, true, i));
                        questionListArray.add(getQuestionObjectIsQRAvailable(question, false, i));
                    }
                    questionListArray.add(getQuestionObject(question, ticket, new ArrayList<>()));
                    if (question.getQuestionType().getQuestionType().equalsIgnoreCase("QR")) {
                        if (question.getIsYesNo() != null && question.getIsYesNo()) {
                            questionListArray.add(getQuestionObjectQRSub(question, true, i));
                            questionListArray.add(getQuestionObjectQRSub(question, false, i));
                        }
                        page.put("isQR", true);

                    }
                }

                page.put("pageNumber", i);
                page.put("pageId", i);
                page.put("pageName", i);
                page.put("sequence", i);
                page.put("pageDesc", i);
                page.put("question", questionParent.getQuestion());
                page.put("questionId", questionParent.getQuestionId());
                page.put("questions", questionListArray);
                page.put("hasChildren", false);
                page.put("isInfluencer", false);
                page.put("isPreFilled", false);
                page.put("isFilled", false);
                page.put("caption", "");
                pageList.add(page);
            }
            JSONObject response = new JSONObject();
            response.put("auditId", ticket.getAudit().getAuditId());
            response.put("pages", pageList);
            response.put("shortage", "0");
            response.put("siteId", ticket.getSite().getSiteId());
            response.put("templateId", ticket.getAudit().getTemplate().getTemplateId());
            response.put("ticketId", ticket.getTicketId());
            response.put("status", ticket.getStatus());
            response.put("overage", "0");
            result.put("status", 200);
            result.put("message", "Success");
            result.put("response", response);

        } catch (Exception e) {
            log.error("Exception in submitParentQuestionResponse: {}", e);
            result.put("status", 500);
            result.put("message", "Internal Server Error");
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject markUnmarkSiteForOffline(Integer ticketId, Users user) {
        JSONObject result = new JSONObject();
        try {
            Ticket ticket = ticketRepository.findById(ticketId).orElse(null);
            ConfigProperties configProperties = configPropertiesRepository.findByType("LIMIT");
            if (ticket == null) {
                result.put("status", 302);
                result.put("response", "Ticket not found.");
                return result;
            }

            if (!ticket.getUsers().getUserId().equals(user.getUserId())){
                result.put("status", 302);
                result.put("response", "Ticket not assigned to you.");
                return result;
            }
            if (ticket.getIsSelectForOffline() != null && ticket.getIsSelectForOffline()) {
                ticket.setIsSelectForOffline(false);
                ticketRepository.save(ticket);
                result.put("status", 200);
                result.put("response", "Unmarked for Offline ");
                return result;
            } else {
                Integer maxLimitForOffline =  Integer.valueOf(configProperties.getValue()); // todo get it from config_properties
                Integer ticketCount = ticketRepository.getCountOfOfflineMarkedTicketOfUser(user.getUserId());
                if (ticketCount >= maxLimitForOffline){
                    result.put("status", 302);
                    result.put("response", "You have reached maximum limit for mark offline audits.");
                    return result;
                }
                ticket.setIsSelectForOffline(true);
                ticketRepository.save(ticket);
                result.put("status", 200);
                result.put("response", "Marked for Offline");
                return result;
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
}
