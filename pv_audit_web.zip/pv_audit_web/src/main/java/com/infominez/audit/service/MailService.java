package com.infominez.audit.service;

import java.util.Date;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.json.simple.JSONObject;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.infominez.audit.entity.EmailAuthenticator;
import com.infominez.audit.wrapper.BaseResponse;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class MailService {
	 private final JavaMailSender mailSender;

	    public JSONObject sendingAttachmentMailWithRediff(String[] recepients ,String subject, String messages, Boolean isHtml, String filePath, String fileName) throws MessagingException {
	        log.info("sendingMailWithRediff()");
	        JSONObject result = new JSONObject();
	        try {
	        	
	        	final String fromEmail = "epstar_notifications@epsho.electronicpay.in"; //requires valid gmail id
	            final String password = "Asdf@1100"; // correct password for gmail id
//	            final String toEmail = "sanjay@infominez.com"; // can be any email id

	            System.out.println("SSLEmail Start");
	            Properties props = new Properties();
	            props.put("mail.smtp.host", "smtp.outlook.office365.com"); //SMTP Host
	            props.put("mail.smtp.socketFactory.port", "587"); //SSL Port
	            props.put("mail.smtp.socketFactory.class",
	                    "javax.net.ssl.SSLSocketFactory"); //SSL Factory Class
	            props.put("mail.smtp.auth", "true"); //Enabling SMTP Authentication
	            props.put("mail.smtp.port", "587"); //SMTP Port
	            props.put("mail.smtp.starttls.enable", true);

	 	        // Get the Session object.
	 	        Session session = Session.getInstance(props,
	 	                new javax.mail.Authenticator() {
	 	                    protected PasswordAuthentication getPasswordAuthentication() {
	 	                        return new PasswordAuthentication(fromEmail, password);
	 	                    }
	 	                });

	            MimeMessage message = new MimeMessage(session);
	            message.setSubject(subject);
	            message.setText(messages);

	            InternetAddress[] addressTo = new InternetAddress[recepients.length];

	            for (int i = 0; i < recepients.length; i++) {
	                addressTo[i] = new InternetAddress(recepients[i]);

	            }
	            message.setFrom(new InternetAddress(fromEmail));
	            
	            message.setRecipients(Message.RecipientType.TO, addressTo);
	            MimeBodyPart messageBodyPart = new MimeBodyPart();

	            Multipart multipart = new MimeMultipart();
	            messageBodyPart = new MimeBodyPart();

	            DataSource source = new FileDataSource(filePath);
	            messageBodyPart.setDataHandler(new DataHandler(source));
	            messageBodyPart.setFileName(fileName);
	            multipart.addBodyPart(messageBodyPart);

	            message.setContent(multipart);

	            Transport.send(message);

	            result.put("status", 200);
	            result.put("message", "Mail sent successfully");
	        }
	        catch(Exception e){
	        	e.printStackTrace();
	            log.error("sendingMailWithRediff exception : {}",e.getMessage());
	            result.put("status", 500);
	            result.put("response", "Internal Server Error");
	        }
	        return result;
	    }
	    
		public  JSONObject sendingAttachmentMailWithRediffV2(String[] recepients ,String subject, String messages, Boolean isHtml, String filePath, String fileName) throws MessagingException {
		    log.info("sendingMailWithRediff()");
		    JSONObject result = new JSONObject();
		    try {
		        Authenticator auth = new EmailAuthenticator();
		        Properties props = new Properties();

		        System.out.println("SSLEmail Start");
		        props.put("mail.smtp.host", "smtp.outlook.office365.com"); //SMTP Host
		        props.put("mail.smtp.socketFactory.port", "587"); //SSL Port
		        props.put("mail.smtp.socketFactory.class",
		                "javax.net.ssl.SSLSocketFactory"); //SSL Factory Class
		        props.put("mail.smtp.auth", "true"); //Enabling SMTP Authentication
		        props.put("mail.smtp.port", "587"); //SMTP Port
		        props.put("mail.smtp.starttls.enable", true);

		        Session session = Session.getDefaultInstance(props, auth);

		        MimeMessage message = new MimeMessage(session);
		        message.setSubject(subject);
//		        message.setContent(messages, "text/plain");
		        message.setText(messages);
//		        message.setHeader("MIME-Version:", "1.0");
//		        message.setHeader("Content-Type:", "text/html;charset=UTF-8");
		        message.setHeader("From", "epstar_notifications@epsho.electronicpay.in");
		        message.setSentDate(new Date());

		        InternetAddress[] addressTo = new InternetAddress[recepients.length];

		        for (int i = 0; i < recepients.length; i++) {
		            addressTo[i] = new InternetAddress(recepients[i]);

		        }
		        message.setRecipients(Message.RecipientType.TO, addressTo);
		        MimeBodyPart messageBodyPart = new MimeBodyPart();

		        Multipart multipart = new MimeMultipart();
		        messageBodyPart = new MimeBodyPart();

		        DataSource source = new FileDataSource(filePath);
		        messageBodyPart.setDataHandler(new DataHandler(source));
		        messageBodyPart.setFileName(fileName);
		        multipart.addBodyPart(messageBodyPart);

		        message.setContent(multipart);

		        Transport.send(message);

		        result.put("status", 200);
	            result.put("message", "Mail sent successfully");
		    }
		    catch(Exception e){
		        log.error("sendingMailWithRediff exception : {}",e.getMessage());
		        e.printStackTrace();
	            result.put("status", 500);
	            result.put("response", "Internal Server Error");
		    }
		    return result;
		}
}
