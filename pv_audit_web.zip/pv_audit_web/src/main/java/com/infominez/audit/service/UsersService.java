package com.infominez.audit.service;



import com.infominez.audit.entity.Site;
import com.infominez.audit.entity.UserAuditSchedule;
import com.infominez.audit.entity.Users;
import com.infominez.audit.repo.UserAuditScheduleRepository;
import com.infominez.audit.repo.UsersRepository;
import com.infominez.audit.utils.ExcelUtils;
import com.infominez.audit.wrapper.BaseResponse;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
@AllArgsConstructor
public class UsersService {

    private final UsersRepository usersRepository;
    private final UserAuditScheduleRepository userAuditScheduleRepository;

    private final Map<String, Users> db = new ConcurrentHashMap<>();

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Users lookup(String username) {
        return usersRepository.findByUserName(username);
//		    return this.db.get(username);
    }

    public void save(Users user) {
        JSONObject response = createUser(user);
        /* Users newUser = usersRepository.findUserById(response.); */
        this.db.put(user.getUserName(), user);
    }

    public boolean usernameExists(String username) {
        Users user = usersRepository.findByUserName(username);
        if (user != null) {
            return true;
        } else {
            return false;
        }
//		    return this.db.containsKey(username);
    }


    public JSONObject createUser(Users user) {
        log.info(this.getClass().getName() + " :- createUser()");
        JSONObject baseResponse = new JSONObject();
        try {
            Users tempUser = findUserByName(user.getUserName());
            if (tempUser != null) {
                baseResponse.put("status",302);
                baseResponse.put("response","Please enter another user Name. " + user.getUserName() + " already exist.");
                return baseResponse;
            }

            Users emailUser = usersRepository.findByEmailId(user.getEmailId());
            if (emailUser != null) {
                baseResponse.put("status",302);
                baseResponse.put("response","Please enter another Email. " + user.getEmailId() + " already exist.");
                return baseResponse;
            }
            Date date = new Date();
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            user.setIsActive(true);
            user.setCreatedDate(date);
            user.setLastUpdatedDate(date);
            user.setMailingEmail(user.getMailingEmail());
            baseResponse.put("status",200);
            baseResponse.put("response",usersRepository.save(user));
        } catch (Exception e) {
            log.error("Error  occurred  @class" + this.getClass().getName(), e);
            baseResponse.put("status",500);
            baseResponse.put("response","Something went wrong : " + e.getMessage());

        }
        return baseResponse;
    }


    public JSONObject updateUser(Users user) {
        log.info(this.getClass().getName() + " :- updateUser()");
        JSONObject baseResponse = new JSONObject();
        try {
            Users tempUser = findUserByName(user.getUserName());
            if (tempUser != null && !tempUser.getUserId().equals(user.getUserId())) {
                baseResponse.put("status",302);
                baseResponse.put("response","Please enter another user Name. " + user.getUserName() + " already exist.");
                return baseResponse;
            }
            Users emailUser = usersRepository.findByEmailId(user.getEmailId());
            if (emailUser != null && !emailUser.getUserId().equals(user.getUserId())) {
                baseResponse.put("status",302);
                baseResponse.put("response","Please enter another Email. " + user.getEmailId() + " already exist.");
                return baseResponse;
            }
            Date date = new Date();
            Users getUser=usersRepository.findById(user.getUserId()).get();
            if (user.getUserName() != null && !user.getUserName().isEmpty()) {
                getUser.setUserName(user.getUserName());
            }
            if (user.getFirstName() != null && !user.getFirstName().isEmpty()) {
                getUser.setFirstName(user.getFirstName());
            }
            if (user.getLastName() != null && !user.getLastName().isEmpty()) {
                getUser.setLastName(user.getLastName());
            }
            if (user.getEmailId() != null && !user.getEmailId().isEmpty()) {
                getUser.setEmailId(user.getEmailId());
            }
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                user.setPassword(passwordEncoder.encode(user.getPassword()));
                getUser.setPassword(user.getPassword());
            }
            if (user.getPhoneNumber() != null && !user.getPhoneNumber().isEmpty()) {
                getUser.setPhoneNumber(user.getPhoneNumber());
            }
            if (user.getSsoUsername() != null && !user.getSsoUsername().isEmpty()) {
                getUser.setSsoUsername(user.getSsoUsername());
            }
            if (user.getUserType() != null && !user.getUserType().isEmpty()) {
                getUser.setUserType(user.getUserType());
            }
            if (user.getMailingEmail() != null && !user.getMailingEmail().isEmpty()) {
            	getUser.setMailingEmail(user.getMailingEmail());
            }
            user.setIsActive(true);
            getUser.setLastUpdatedDate(date);
            baseResponse.put("status",200);
            baseResponse.put("response",usersRepository.save(getUser));

        } catch (Exception e) {
            log.error("Error  occurred  @class" + this.getClass().getName(), e);
            baseResponse.put("status",500);
            baseResponse.put("response","Something went wrong : " + e.getMessage());
        }
        return baseResponse;
    }

    public JSONObject findAllUser() {
        JSONObject result=new JSONObject();
        JSONArray array=new JSONArray();
        try {
            List<Users> list=usersRepository.findAll();

            if (list != null && !list.isEmpty()){
            	for(Users users:list) {
            		if(users.getIsActive() != null) {
            			array.add(users);
            		}
            	}
                result.put("status", 200);
                result.put("response", array);
            }else{
                result.put("status", 302);
                result.put("response", "No User Found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }



    public JSONObject findUserById(Integer userId) {
        log.info(this.getClass().getName() + " :- findUserById()");
        JSONObject jsonObject=new JSONObject();
        try{
            Users users=usersRepository.findById(userId).get();
            if(users !=null&& !jsonObject.isEmpty()){
                jsonObject.put("status", 200);
                jsonObject.put("response", users);
            }
            else{
                jsonObject.put("status", 302);
                jsonObject.put("response", "No Question Found");
            }
        }catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }


        return jsonObject;
    }


    public Users findUserByName(String userName) {
        return usersRepository.findByUserName(userName);
    }

    public Users findUserBySsoUsername(String ssoUsername) {
        return usersRepository.findBySsoUsername(ssoUsername);
    }
    
    public ByteArrayInputStream  downloadAuditUsersList() {
        log.info(" writing user excel");

         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try(SXSSFWorkbook workbook = new SXSSFWorkbook()){
        Sheet sheet = workbook.createSheet("Audit Users");
        ExcelUtils.createHeader(workbook, sheet, "EPS", 0, 1, 0, 9, 0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String summaryDate = sdf.format(new Date());
        ExcelUtils.historyTypeInfoRow(workbook, sheet, "Audit Users" + summaryDate, 2, 2,
                0, 9, 2);
        ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Id", "First Name", "Last Name", "User Name", "Phone Number", "Email Id",
                 "SSO Username", "User Type","Created On" , "Updated On"));
        CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 3);
        ExcelUtils.createAndWriteRow(sheet, headerList, 3, cellStyle, true, workbook);

        int rowCount = 2;
        try {
            List<Users> usersList = usersRepository.findAll();
            cellStyle = ExcelUtils.createCellStyle(sheet, ++rowCount);
            for (Users user : usersList) {
                    ArrayList<String> rowData = new ArrayList<>();
                    rowData.add(user.getUserId() + "");
                    rowData.add(user.getFirstName());
                    rowData.add(user.getLastName());
                    rowData.add(user.getUserName());
                    rowData.add(user.getPhoneNumber());
                    rowData.add(user.getEmailId());
                    rowData.add(user.getSsoUsername());
                    rowData.add(user.getUserType());
                    rowData.add(dateFormat.format(user.getCreatedDate()));
                    rowData.add(dateFormat.format(user.getLastUpdatedDate()));
                    ExcelUtils.createAndWriteRow(sheet, rowData, ++rowCount, cellStyle, false, null);
            }
        } catch (Exception e) {
            log.error("Exception in writing sheet ", e);
            return null;
        }
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing  Audit Users excel ", e);
            
            return null;
        }
    }
    
    
    public JSONObject inActiveUser(Integer userId) {
        log.info(this.getClass().getName() + " :- InActiveUser()");
        JSONObject jsonObject=new JSONObject();
        try{
            Users users=usersRepository.findById(userId).get();
            if(users !=null){
            	users.setIsActive(false);
            	Users id=usersRepository.save(users);
            	if(id !=null) {
                jsonObject.put("status", 200);
                jsonObject.put("response", "user InActive successfully");
            	}else {
            		 jsonObject.put("status", 401);
                     jsonObject.put("response", " unable to  update  this user");
            	}
            }
            else{
                jsonObject.put("status", 302);
                jsonObject.put("response", "No user Found");
            }
        }catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }
        return jsonObject;
    }

	private String getCellValue(Cell cell) {
		return new DataFormatter().formatCellValue(cell);
	}

	private boolean checkIfExistInList(Users users, List<Users> dbUsers) {
		Boolean result = true;
		if (dbUsers != null && dbUsers.size() > 0) {
			for (Users object : dbUsers) {
				if ((object.getUserName().equalsIgnoreCase(users.getUserName()))
						|| (object.getEmailId().equalsIgnoreCase(users.getEmailId()))
						|| (object.getSsoUsername().equalsIgnoreCase(users.getSsoUsername()))) {
					result = true;
					break;
				} else
					result = false;

			}

		} else {
			result = false;
		}
		return result;
	}

	public JSONObject bulkUploadUsers(InputStream inputStream) {
		log.info("Bulk Upload Users");
		JSONObject result = new JSONObject();
		try {
			List<Users> dbUsers = usersRepository.getAllUsers();
			List<Users> tobeInsertUsers = new ArrayList<>();
			Workbook wb = WorkbookFactory.create(inputStream);
			Sheet sheet = wb.getSheetAt(0);
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = (Row) rowIterator.next();
				if (row.getRowNum() > 0) {
					Users users = new Users();
					users.setFirstName(getCellValue(row.getCell(0)));
					users.setLastName(getCellValue(row.getCell(1)));
					users.setUserName(getCellValue(row.getCell(2)));
					users.setPassword(getCellValue(row.getCell(3)));
					users.setPhoneNumber(getCellValue(row.getCell(4)));
					users.setEmailId(getCellValue(row.getCell(5)));
					users.setSsoUsername(getCellValue(row.getCell(6)));
					users.setUserType(getCellValue(row.getCell(7)));
					
					Date date=new Date();
					users.setCreatedDate(date);
					users.setLastUpdatedDate(date);
					if (!checkIfExistInList(users, dbUsers)) {
						if (!checkIfExistInList(users, tobeInsertUsers)) {
							tobeInsertUsers.add(users);
						}
					}
				}
			}
			List<Users> inserted = usersRepository.saveAll(tobeInsertUsers);
			if (inserted != null && inserted.size() > 0) {
				result.put("status", 200);
				result.put("response", "Bulk Upload Users Successfull");
			} else {
				result.put("status", 302);
				result.put("response", "Bulk Upload Users FAILED");
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occur in Users bulk Upload : {} ", e.getStackTrace());
			result.put("status", 500);
			result.put("response", "Internal Server Error");
		}

		return result;
	}

    public JSONObject setActiveInActiveUser(Integer userId) {
        log.info(this.getClass().getName() + " :- setActiveInActiveUser() userId:{}",userId);
        JSONObject jsonObject=new JSONObject();
        try{
            Users users=usersRepository.findById(userId).get();
            if(users !=null){
                if(users.getIsActive()) {
                    users.setIsActive(false);
                }
                else{
                    users.setIsActive(true);
                }
                Users id=usersRepository.save(users);
                if(id !=null) {
                    jsonObject.put("status", 200);
                    jsonObject.put("response", "User updated successfully");
                }else {
                    jsonObject.put("status", 401);
                    jsonObject.put("response", " unable to  update  this user");
                }
            }
            else{
                jsonObject.put("status", 302);
                jsonObject.put("response", "No user Found");
            }
        }catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }
        return jsonObject;
    }
}
