package com.infominez.audit.controller;

import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.PageImageResponse;
import com.infominez.audit.service.PageImageResponseService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.ws.rs.QueryParam;

@RestController
@RequestMapping("/PageImageResponse")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class PageImageResponseController {
    private final PageImageResponseService pageImageResponseService;

    @PostMapping("/create")
    public JSONObject create(@RequestBody PageImageResponse pageImageResponse) {
        log.info(this.getClass().getName() + " :- create() ");
        return pageImageResponseService.createPageImageResponse(pageImageResponse);
    }


    @PostMapping("/update")
    public JSONObject update(@RequestBody PageImageResponse pageImageResponse) {
        log.info(this.getClass().getName() + " :- update() ");
        return pageImageResponseService.updatePageImageResponse(pageImageResponse);
    }


    @GetMapping("/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return pageImageResponseService.findPageImageResponseeById(id);
    }


    @GetMapping("/findAll")
    public JSONObject findAll() {
        log.info(this.getClass().getName() + " :- findAll() ");
        return pageImageResponseService.findAllPageImageResponse();
    }

    @GetMapping("/findPageImageResponseByTicket")
    public JSONObject findPageImageResponseByTicket(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :-  findPageImageResponseByTicket() ");
        return pageImageResponseService.findPageImageResponseByTicket(ticketId);
    }

    @GetMapping("/findPageImageResponseByPage")
    public JSONObject findPageImageResponseByPage(@QueryParam("pageId") Integer pageId) {
        log.info(this.getClass().getName() + " :-  findPageImageResponseByPage() ");
        return pageImageResponseService.findPageImageResponseByPage(pageId);
    }
    @PostMapping("/savePageImage")
    public JSONObject savePageImage(@RequestPart("file") MultipartFile file, @RequestParam("pageId") Integer pageId,
                                    @RequestParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :-  findPageImageResponseByPage() ");
        return pageImageResponseService.savePageImage(file, pageId,ticketId);
    }
/*
    public BaseResponse createFranchiseDocument(@RequestPart("file") MultipartFile file, @RequestParam("franchiseId") Integer franchiseId,
                                                @RequestParam("documentTypeId") Integer documentTypeId,
                                                @RequestParam("documentNumber") String documentNumber,
                                                HttpServletRequest request, HttpServletResponse response) throws RequestException, ParseException {
        logger.info(this.getClass().getName() + " :- createFranchiseDocument()");
        BaseResponse baseResponse = new BaseResponse();
        try {
            Franchise tempFranchise = franchiseService.findFranchiseById(franchiseId);
            DocumentType tempDocumentType = documentTypeService.findDocumentTypeById(documentTypeId);
            FranchiseDocument franchiseDocument = new FranchiseDocument();

            if (franchiseId != null) {
                franchiseDocument.setFranchise(tempFranchise);
            }
            if (documentTypeId != null) {
                franchiseDocument.setDocumentType(tempDocumentType);
            }
            if (documentNumber != null) {
                franchiseDocument.setDocumentNumber(documentNumber);
            }
            franchiseDocument.setIsVerified(false);
            String name = CustomerInfo.getUserNameByToken(request);   // get username by access token
            Users user = userService.findUserByEmail(name);
            franchiseDocument.setCreatedBy(user.getUserId());
            franchiseDocument.setUpdatedBy(user.getUserId());

            String filePath = imagePathProperties.getUserProfileHome();
            String filePathStatic = "franchiseDocument/" + tempFranchise.getFranchiseId() + "/";
            filePath = filePath + filePathStatic;
            String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss-"));
            String fileName = tempFranchise.getFranchiseId() + "_" + tempDocumentType.getTypeName() + "_" + date + ".png";
            String path = FileUtils.writeFile(file, filePath, fileName);
            franchiseDocument.setDocumentPath(filePathStatic +fileName );
            Integer id = franchiseDocumentService.createFranchiseDocument(franchiseDocument);
            if (id != null) {
                baseResponse.setStatus("201");
                baseResponse.setResponse(franchiseDocumentService.findFranchiseDocumentById(id));
            }
        } catch (Exception e) {
            logger.error("Error  occurred  @class" + this.getClass().getName(), e);
            baseResponse.setStatus("401");
            baseResponse.setResponse("Something went wrong : " + e.getMessage());
            e.printStackTrace();
        }
        return baseResponse;
    }*/
}
