package com.infominez.audit.service;


import com.infominez.audit.entity.*;
import com.infominez.audit.repo.*;
import com.infominez.audit.utils.Constants;
import com.infominez.audit.utils.ExcelUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class TemplateService {

    private final TemplateRepository templateRepository;
    private final AuditTypeRepository auditTypeRepository;
    private final PageRepository pageRepository;
    private final QuestionRepository questionRepository;
    private final QuestionTypeOptionRepository questionTypeOptionRepository;

    public JSONObject createTemplate(Template template) {
        log.info(this.getClass().getName() + " :- createTemplate()");
        JSONObject result = new JSONObject();
        try {
            List<Template> list = templateRepository.findByTemplateNameAndAuditType(template.getTemplateName(), template.getAuditType());
            if (list != null && !list.isEmpty() && template.getTemplateId() != list.get(0).getTemplateId()) {
                result.put("status", 302);
                result.put("response", "Template already Exist with template Name : " + template.getTemplateName() + " and AuditTypeID : " + template.getAuditType().getAuditTypeId());
            } else {
                Date date = new Date();
                template.setCreatedBy(1); // todo change when login is implemented
                template.setUpdatedBy(1); // todo change when login is implemented
                template.setCreatedDate(date);
                template.setLastUpdatedDate(date);
                template.setIsActive(false);
                Template createdTemplate = templateRepository.save(template);
                if (createdTemplate != null) {
                    result.put("status", 200);
                    result.put("response", "Template Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add Template");
                }
            }
        } catch (Exception e) {

            log.error("Exception in createTemplate for Template : {} and exception : {} ", template.toString(), e.getMessage());
            log.trace("Exception in createTemplate for Template : {} and trace : {} ", template.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject updateTemplate(Template template) {
        log.info(this.getClass().getName() + " :- updateTemplate()");
        JSONObject result = new JSONObject();
        try {
            List<Template> list = templateRepository.findByTemplateNameAndAuditType(template.getTemplateName(), template.getAuditType());
            if (list != null && !list.isEmpty() && template.getTemplateId() != list.get(0).getTemplateId()) {
                result.put("status", 302);
                result.put("response", "Template already Exist with template Name : " + template.getTemplateName() + " and AuditTypeID : " + template.getAuditType().getAuditTypeId());
            } else {
                Template templateToUpdate = templateRepository.findById(template.getTemplateId()).get();
                if (templateToUpdate != null) {
                    if (template.getTemplateName() != null && !template.getTemplateName().trim().isEmpty()) {
                        templateToUpdate.setTemplateName(template.getTemplateName().trim());
                    }
                    if (template.getAuditType() != null) {
                        templateToUpdate.setAuditType(template.getAuditType());
                    }
                    if (template.getIsActive() != null) {
                        templateToUpdate.setIsActive(template.getIsActive());
                    }

                    templateToUpdate.setLastUpdatedDate(new Date());
                    templateRepository.save(templateToUpdate);
                    result.put("status", 200);
                    result.put("response", "Template Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update Template");
                }
            }
        } catch (Exception e) {

            log.error("Exception in updateTemplate for Template : {} and exception : {} ", template.toString(), e.getMessage());
            log.trace("Exception in updateTemplate for Template : {} and trace : {} ", template.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findTemplateById(Integer id) {
        log.info(this.getClass().getName() + " :- findTemplateById()");
        JSONObject result = new JSONObject();
        try {
            Template template = templateRepository.findById(id).get();
            if (template != null) {
                result.put("status", 200);
                result.put("response", template);
            } else {
                result.put("status", 302);
                result.put("response", "Template Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTemplateById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findTemplateById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findAllTemplate() {
        log.info(this.getClass().getName() + " :- findAllTemplate()");
        JSONObject result = new JSONObject();
        try {

            List<Template> templateList = templateRepository.findAll();
            templateList.forEach(template -> {
                template.setTemplateCode("EPS" + String.format("%06d", template.getTemplateId()));
            });
            if (templateList != null && !templateList.isEmpty()) {
                result.put("status", 200);
                result.put("response", templateList);
            } else {
                result.put("status", 302);
                result.put("response", "No Template found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllTemplate  exception : {} ", e.getMessage());
            log.trace("Exception in findAllTemplate  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findTemplatesByAuditTypeId(Integer auditTypeId) {
        log.info(this.getClass().getName() + " :- findTemplatesByAuditTypeId()");
        JSONObject result = new JSONObject();
        try {
            AuditType auditType = auditTypeRepository.findById(auditTypeId).get();
            List<Template> templateList = templateRepository.findByAuditType(auditType);
            if (templateList != null && !templateList.isEmpty()) {
                result.put("status", 200);
                result.put("response", templateList);
            } else {
                result.put("status", 302);
                result.put("response", "No Template found");
            }
        } catch (Exception e) {

            log.error("Exception in findTemplatesByAuditTypeId for auditTypeId : {} and exception : {} ", auditTypeId, e.getMessage());
            log.trace("Exception in findTemplatesByAuditTypeId for auditTypeId : {} and trace : {} ", auditTypeId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllTemplateList() {
        log.info(this.getClass().getName() + " :- findAllTemplateList()");
        JSONObject result = new JSONObject();
        try {
            List<Template> templateList = templateRepository.findAll();
            JSONArray newList = new JSONArray();
            for (Template template : templateList) {
                template.setTemplateCode("EPS" + String.format("%06d", template.getTemplateId()));
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("template", template);
                List<Page> pages = pageRepository.findByTemplate(template);
                jsonObject.put("noOfPages", pages.size());
                newList.add(jsonObject);
            }
            if (newList != null && !newList.isEmpty()) {
                result.put("status", 200);
                result.put("response", newList);
            } else {
                result.put("status", 302);
                result.put("response", "No Template found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllTemplateList  exception : {} ", e.getMessage());
            log.trace("Exception in findAllTemplateList  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getTemplateDetail(Integer templateId) {
        JSONObject result = new JSONObject();
        try {
            Template template = templateRepository.findById(templateId).get();
            if (template != null) {
                JSONObject templateJSON = new JSONObject();
                templateJSON.put("templateId", template.getTemplateId());
                templateJSON.put("templateName", template.getTemplateName());
                templateJSON.put("auditType", template.getAuditType());
                templateJSON.put("isActive", template.getIsActive());
                List<Page> pageList = pageRepository.findByTemplate(template);
                JSONArray pageJSONArray = new JSONArray();
                for (Page page : pageList) {
                    JSONObject pageJSON = new JSONObject();
                    pageJSON.put("pageId", page.getPageId());
                    pageJSON.put("pageName", page.getPageName());
                    pageJSON.put("sequence", page.getSequence());
                    pageJSON.put("pageDesc", page.getPageDesc());


                    List<Question> questionList = questionRepository.findByPageAndParentIdNull(page.getPageId());
                    JSONArray questionJSONArray = new JSONArray();
                    for (Question question : questionList) {
                        JSONObject questionJSON = new JSONObject();
                        questionJSON.put("questionId", question.getQuestionId());
                        questionJSON.put("question", question.getQuestion());
                        questionJSON.put("questionType", question.getQuestionType());
                        questionJSON.put("defaultValue", question.getDefaultValue());
                        questionJSON.put("isMadatory", question.getIsMadatory());
                        questionJSON.put("dataType", question.getDataType());
                        questionJSON.put("parentId", question.getParentId());
                        questionJSON.put("QuestionSequence", question.getSequence());
                        questionJSON.put("isYesNo", question.getIsYesNo());

                        if(question.getCaptureImgStatus()==0){
                            questionJSON.put("is_CaptureImg_Status","Not Required");
                        }else if(question.getCaptureImgStatus()==1){
                            questionJSON.put("is_CaptureImg_Status","Required But Not Mandatory");
                        }else if(question.getCaptureImgStatus()==2){
                            questionJSON.put("is_CaptureImg_Status"," Required And Mandatory");
                        }

                        List<Question> childQuestions = questionRepository.findByParentId(question.getQuestionId());
                        List<Question> influencerQuestions =
                                questionRepository.findByInfluenceBy(question.getQuestionId());
                        JSONArray child = new JSONArray();
                        if (childQuestions != null && childQuestions.size() > 0){
                            for (Question chq : childQuestions){
                            JSONObject childObj = new JSONObject();
                            childObj.put("questionId", chq.getQuestionId());
                            childObj.put("question", chq.getQuestion());
                            childObj.put("questionType", chq.getQuestionType());
                            childObj.put("defaultValue", chq.getDefaultValue());
                            childObj.put("isMadatory", chq.getIsMadatory());
                            childObj.put("dataType", chq.getDataType());
                            childObj.put("parentId", chq.getParentId());
                            childObj.put("influenceBy", chq.getInfluenceBy());
                            childObj.put("influencerResponseValue", chq.getInfluencerResponseValue());
                            childObj.put("QuestionSequence", chq.getSequence());
                            childObj.put("isYesNo", chq.getIsYesNo());
                                List<String> qtOptions = new ArrayList<>();
                                if (chq.getQuestionType().getIsOption() == true) {
                                    List<QuestionTypeOption> questionTypeOptions = new ArrayList<>();
                                    questionTypeOptions = questionTypeOptionRepository.findByQuestionId(chq.getQuestionId());
                                    if (questionTypeOptions != null && !questionTypeOptions.isEmpty()){
                                        questionTypeOptions.forEach(questionTypeOption -> {
                                            qtOptions.add(questionTypeOption.getOption());
                                        });
                                    }
                                }

                                childObj.put("questionTypeOptionList", qtOptions);
                            child.add(childObj);
                            }
                        }else if (influencerQuestions != null && influencerQuestions.size() > 0){
                            for (Question chq : influencerQuestions){
                                JSONObject childObj = new JSONObject();
                                childObj.put("questionId", chq.getQuestionId());
                                childObj.put("question", chq.getQuestion());
                                childObj.put("questionType", chq.getQuestionType());
                                childObj.put("defaultValue", chq.getDefaultValue());
                                childObj.put("isMadatory", chq.getIsMadatory());
                                childObj.put("dataType", chq.getDataType());
                                childObj.put("parentId", chq.getParentId());
                                childObj.put("influenceBy", chq.getInfluenceBy());
                                childObj.put("influencerResponseValue", chq.getInfluencerResponseValue());
                                childObj.put("QuestionSequence", chq.getSequence());
                                childObj.put("isYesNo", chq.getIsYesNo());
                                List<String> qtOptions = new ArrayList<>();
                                if (chq.getQuestionType().getIsOption() == true) {
                                    List<QuestionTypeOption> questionTypeOptions = new ArrayList<>();
                                    questionTypeOptions = questionTypeOptionRepository.findByQuestionId(chq.getQuestionId());
                                    if (questionTypeOptions != null && !questionTypeOptions.isEmpty()){
                                        questionTypeOptions.forEach(questionTypeOption -> {
                                            qtOptions.add(questionTypeOption.getOption());
                                        });
                                    }
                                }

                                childObj.put("questionTypeOptionList", qtOptions);
                                child.add(childObj);
                            }
                        }
                        questionJSON.put("children", child);
                        List<String> qtOptions = new ArrayList<>();
                        if (question.getQuestionType().getIsOption() == true) {
                            List<QuestionTypeOption> questionTypeOptions = new ArrayList<>();
                            questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
                            if (questionTypeOptions != null && !questionTypeOptions.isEmpty()){
                                questionTypeOptions.forEach(questionTypeOption -> {
                                    qtOptions.add(questionTypeOption.getOption());
                                });
                            }
                        }

                        questionJSON.put("questionTypeOptionList", qtOptions);
                        questionJSONArray.add(questionJSON);
                    }
                    pageJSON.put("questionList", questionJSONArray);
                    pageJSONArray.add(pageJSON);
                }
                templateJSON.put("pagesList", pageJSONArray);
                result.put("status", 200);
                result.put("response", templateJSON);
            } else {
                result.put("status", 302);
                result.put("response", "Template not found");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject createTemplateCopy(Integer templateId) {
        JSONObject result = new JSONObject();
        try {
            Template newTemplate = new Template();
            Page newpage = new Page();
            Template template = templateRepository.findById(templateId).get();
            if (template != null) {
                List<Page> pageList = pageRepository.findByTemplate(template);
                Page page = null;
                List<Page> latestPageList = new ArrayList<>();
                for (Page Newpage : pageList) {
                    Date date = new Date();
                    page = new Page();
                    page.setPageName(Newpage.getPageName());
                    page.setCreatedBy(1);
                    page.setUpdatedBy(1);
                    page.setCreatedDate(date);
                    page.setLastUpdatedDate(date);
                    page.setTemplate(Newpage.getTemplate());
                    page.setPageDesc(Newpage.getPageDesc());
                    page.setSequence(Newpage.getSequence());
                    latestPageList.add(page);
                    Page pages = pageRepository.save(page);
                    List<Question> questionList = questionRepository.findByPage(Newpage);
                    Question question = null;
                    List<Question> latestQuestionList = new ArrayList<Question>();
                    for (Question Newquestion : questionList) {
                        question = new Question();
                        question.setQuestionTypeOptionList(Newquestion.getQuestionTypeOptionList());
                        question.setQuestion(Newquestion.getQuestion());
                        question.setQuestionType(Newquestion.getQuestionType());
                        question.setIsMadatory(Newquestion.getIsMadatory());
                        question.setDefaultValue(Newquestion.getDefaultValue());
                        question.setDataType(Newquestion.getDataType());
                        question.setCaptureImgStatus(Newquestion.getCaptureImgStatus());
                        question.setPage(Newquestion.getPage());
                        question.setCreatedBy(1);
                        question.setUpdatedBy(1);
                        question.setCreatedDate(date);
                        question.setLastUpdatedDate(date);
                        latestQuestionList.add(question);
                        questionRepository.save(question);
                    }
                }
                newTemplate.setIsActive(template.getIsActive());
                Date date = new Date();
                newTemplate.setCreatedBy(1); // todo change when login is implemented
                newTemplate.setUpdatedBy(1); // todo change when login is implemented
                newTemplate.setCreatedDate(date);
                newTemplate.setLastUpdatedDate(date);
                newTemplate.setTemplateName(template.getTemplateName());
                newTemplate.setAuditType(template.getAuditType());
                Template createdTemplate = templateRepository.save(newTemplate);
                if (createdTemplate != null) {
                    result.put("status", 200);
                    result.put("response", "template copied");
                }

            } else {
                result.put("status", 302);
                result.put("response", "Template not found");
            }

        } catch (Exception e) {
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject exportTemplate(Integer templateId) {
        JSONObject result = new JSONObject();
        try {
            Template template = templateRepository.findById(templateId).get();
            List<Page> pageList = new ArrayList<>();
            Map<Integer, List<Question>> questionMap = new HashMap<>();
            if (template != null)
                pageList = pageRepository.findByTemplate(template);
            if (pageList != null && pageList.size() > 0) {
                pageList.forEach(page -> {
                    List<Question> qList = questionRepository.findByPage(page);
                    questionMap.put(page.getPageId(), qList);
                });
            }
            result = generateExcel(template, pageList, questionMap);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private JSONObject generateExcel(Template template, List<Page> pageList, Map<Integer, List<Question>> questionMap) {
        JSONObject result = new JSONObject();
        SimpleDateFormat formatDate = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss_aa");
        String date = formatDate.format(new Date());
        String urlPath = Constants.imagesDir;
        String filePathStatic = "templateExcel";
        String excelFilePath = urlPath + filePathStatic;
        String excelFileName = date + "_" + "templateDetail" + ".xlsx";
        log.info(" writing template excel");
        SXSSFWorkbook workbook = null;
        File directory = new File(excelFilePath);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        File file = new File(excelFilePath + "/" + excelFileName);
        if (file.exists() == false) {
            workbook = new SXSSFWorkbook(1000);
        } else {
            log.info("file already exist");
        }

        Sheet sheet = workbook.createSheet("Template Detail");
        ExcelUtils.createHeader(workbook, sheet, "EPS", 0, 1, 0, 9, 0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String summaryDate = sdf.format(new Date());
        ExcelUtils.historyTypeInfoRow(workbook, sheet, "Template Detail" + summaryDate, 2, 2,
                0, 9, 2);
        ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Template ID", "Template Name", "Audit Type", "Page ID", "Page Name", "Page Sequence", "Page Desc.", "Question ID"
                , "Question", "Question Type", "Is Mandatory", "Data Type", "Capture Image","Question Sequence"));
        CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 3);
        ExcelUtils.createAndWriteRow(sheet, headerList, 3, cellStyle, true, workbook);

        int rowCount = 2;
        try {
            cellStyle = ExcelUtils.createCellStyle(sheet, ++rowCount);
            for (Page page : pageList) {
                if (questionMap.get(page.getPageId()) != null && questionMap.get(page.getPageId()).size() > 0) {
                    for (Question question : questionMap.get(page.getPageId())) {
                        ArrayList<String> rowData = new ArrayList<>();
                        rowData.add(template.getTemplateId() + "");
                        rowData.add(template.getTemplateName() + "");
                        rowData.add(template.getAuditType().getAuditType() + "");
                        rowData.add(page.getPageId() + "");
                        rowData.add(page.getPageName() + "");
                        rowData.add(page.getSequence() + "");
                        rowData.add(page.getPageDesc() + "");
                        rowData.add(question.getQuestionId() + "");
                        rowData.add(question.getQuestion() + "");
                        rowData.add(question.getQuestionType().getQuestionType() + "");
                        rowData.add(question.getIsMadatory() + "");
                        rowData.add(question.getDataType() + "");
                        if(question.getCaptureImgStatus()==0){
                            rowData.add("Not Required" + "");
                        }else if(question.getCaptureImgStatus()==1){
                            rowData.add("Required But Not Mandatory" + "");
                        }else if(question.getCaptureImgStatus()==2){
                            rowData.add("Required And Mandatory" + "");
                        }
                        rowData.add(question.getSequence() + "");

                        ExcelUtils.createAndWriteRow(sheet, rowData, ++rowCount, cellStyle, false, null);
                    }
                } else {
                    ArrayList<String> rowData = new ArrayList<>();
                    rowData.add(template.getTemplateId() + "");
                    rowData.add(template.getTemplateName() + "");
                    rowData.add(template.getAuditType().getAuditType() + "");
                    rowData.add(page.getPageId() + "");
                    rowData.add(page.getPageName() + "");
                    rowData.add(page.getSequence() + "");
                    rowData.add(page.getPageDesc() + "");
                    rowData.add("No Question Added");
                    rowData.add("No Question Added");
                    rowData.add("No Question Added");
                    rowData.add("No Question Added");
                    rowData.add("No Question Added");
                    rowData.add("No Question Added");
                    ExcelUtils.createAndWriteRow(sheet, rowData, ++rowCount, cellStyle, false, null);
                }

            }
        } catch (Exception e) {
            log.error("Exception in writing sheet ", e);
            result.put("status", 302);
            result.put("response", "Unable to Generate Excel");
        }
        try (FileOutputStream outputStream = new FileOutputStream(excelFilePath + "/" + excelFileName)) {
            workbook.write(outputStream);
            outputStream.close();
            result.put("status", 200);
            result.put("response", filePathStatic + "/" + excelFileName);
        } catch (Exception e) {
            log.error("Exception in writing Template Detail excel ", e);
            result.put("status", 302);
            result.put("response", "Unable to Generate Excel");
        }
        return result;
    }

    public JSONObject getTemplateDetailV2(Integer templateId) {
        JSONObject result = new JSONObject();
        try {
            Template template = templateRepository.findById(templateId).get();
            if (template != null) {
                List<Question> questionList = questionRepository.findByTemplateId(templateId);
                Map<Page, List<Question>> pageQuestionMap =
                        questionList.stream().collect(Collectors.groupingBy(Question::getPage)).entrySet()
                                .stream().filter(entry -> entry.getValue().size() > 0)
                                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));


                JSONObject templateJSON = new JSONObject();
                templateJSON.put("templateId", template.getTemplateId());
                templateJSON.put("templateName", template.getTemplateName());
                templateJSON.put("auditType", template.getAuditType());
                templateJSON.put("isActive", template.getIsActive());
                Set<Page> pageList = pageQuestionMap.keySet();
                JSONArray pageJSONArray = new JSONArray();
                for (Page page : pageList) {
                    JSONObject pageJSON = new JSONObject();
                    pageJSON.put("pageId", page.getPageId());
                    pageJSON.put("pageName", page.getPageName());
                    pageJSON.put("sequence", page.getSequence());
                    pageJSON.put("pageDesc", page.getPageDesc());


                    List<Question> tempQuestionList = pageQuestionMap.get(page);

                    JSONArray questionJSONArray = new JSONArray();
                    for (Question question : tempQuestionList) {
                        JSONObject questionJSON = new JSONObject();
                        questionJSON.put("questionId", question.getQuestionId());
                        questionJSON.put("question", question.getQuestion());
                        questionJSON.put("questionType", question.getQuestionType());
                        questionJSON.put("defaultValue", question.getDefaultValue());
                        questionJSON.put("isMadatory", question.getIsMadatory());
                        questionJSON.put("dataType", question.getDataType());
                        questionJSON.put("parentId", question.getParentId());
                        questionJSON.put("QuestionSequence", question.getSequence());

                        if (question.getCaptureImgStatus() == 0) {
                            questionJSON.put("is_CaptureImg_Status", "Not Required");
                        } else if (question.getCaptureImgStatus() == 1) {
                            questionJSON.put("is_CaptureImg_Status", "Required But Not Mandatory");
                        } else if (question.getCaptureImgStatus() == 2) {
                            questionJSON.put("is_CaptureImg_Status", " Required And Mandatory");
                        }

                        List<Question> childQuestions = questionRepository.findByParentId(question.getQuestionId());
                        JSONArray child = new JSONArray();
                        if (childQuestions != null && childQuestions.size() > 0) {
                            for (Question chq : childQuestions) {
                                JSONObject childObj = new JSONObject();
                                childObj.put("questionId", chq.getQuestionId());
                                childObj.put("question", chq.getQuestion());
                                childObj.put("questionType", chq.getQuestionType());
                                childObj.put("defaultValue", chq.getDefaultValue());
                                childObj.put("isMadatory", chq.getIsMadatory());
                                childObj.put("dataType", chq.getDataType());
                                childObj.put("parentId", chq.getParentId());
                                childObj.put("QuestionSequence", chq.getSequence());
                                child.add(childObj);
                            }
                        }
                        questionJSON.put("children", child);
                        List<QuestionTypeOption> questionTypeOptions = new ArrayList<>();
                        if (question.getQuestionType().getIsOption() == true) {
                            questionTypeOptions = questionTypeOptionRepository.findByQuestionType(question.getQuestionType());
                        }

                        questionJSON.put("questionTypeOptionList", questionTypeOptions);
                        questionJSONArray.add(questionJSON);
                    }
                    pageJSON.put("questionList", questionJSONArray);
                    pageJSONArray.add(pageJSON);
                }
                templateJSON.put("pagesList", pageJSONArray);
                result.put("status", 200);
                result.put("response", templateJSON);
            } else {
                result.put("status", 302);
                result.put("response", "Template not found");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
}
