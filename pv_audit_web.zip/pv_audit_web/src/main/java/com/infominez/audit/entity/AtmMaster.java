package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;

@Entity
@Table(name = "atm_master" )
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = false)
@Proxy(lazy = false)
public class AtmMaster implements Serializable {
    private static final Long serialVersionUID = 1L;
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "atm_master_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer atmMasterId;

    @Basic(optional = false)
    @Column(name = "atm_id")
    private String atmId;

    @Basic(optional = false)
    @Column(name = "bank")
    private String bank;

    @Basic(optional = false)
    @Column(name = "atm_type")
    private String atmType;

    @Basic(optional = false)
    @Column(name = "site")
    private String site;

    @Basic(optional = false)
    @Column(name = "atm_brand")
    private String atmBrand;

    @Basic(optional = false)
    @Column(name = "vendor")
    private String vendor;

    @Basic(optional = false)
    @Column(name = "population_type")
    private String populationType;

    @Basic(optional = false)
    @Column(name = "state")
    private String state;

    @Basic(optional = false)
    @Column(name = "city")
    private String city;

    @Basic(optional = false)
    @Column(name = "site_address")
    private String siteAddress;

    @Column(name = "device_type")
    private String deviceType;

    @Column(name = "region")
    private String region;

    @Column(name = "atm_make")
    private String atmMake;

    @Column(name = "ups_make")
    private String upsMake;



}
