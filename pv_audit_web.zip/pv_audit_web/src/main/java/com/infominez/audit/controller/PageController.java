package com.infominez.audit.controller;

import com.infominez.audit.entity.Page;
import com.infominez.audit.service.PageService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;

import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;

@RestController
@RequestMapping("/page")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class PageController {
    
    private final PageService pageService;

  
    @PostMapping( "/create")
    public JSONObject create(@RequestBody Page page) {
        log.info(this.getClass().getName() + " :- create() ");
        return pageService.createPage(page);
    }

  
    @PostMapping( "/update")
    public JSONObject update(@RequestBody Page page) {
        log.info(this.getClass().getName() + " :- update() ");
        return pageService.updatePage(page);
    }

  
    @GetMapping( "/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return pageService.findPageById(id);
    }

  
    @GetMapping(  "/findAll")
    public JSONObject findAll() {
        log.info(this.getClass().getName() + " :- findAll() ");
        return pageService.findAllPage();
    }
  
    @GetMapping( "/findPageByTemplateId")
    public JSONObject findPageByTemplateId(@QueryParam("templateId") Integer templateId) {
        log.info(this.getClass().getName() + " :-  findPageByTemplateId() ");
        return pageService.findPagesByTemplateId(templateId);
    }
    @GetMapping(  "/findAllPageList")
    public JSONObject findAllPageList(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAllPageList() ");
        return pageService.findAllPageList();
    }
}
