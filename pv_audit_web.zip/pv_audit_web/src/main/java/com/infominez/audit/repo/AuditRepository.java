package com.infominez.audit.repo;

import com.infominez.audit.entity.Audit;
import com.infominez.audit.entity.Template;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AuditRepository extends JpaRepository<Audit,Integer> {
    List<Audit> findByTemplate(Template template);
    List<Audit> findByAuditNameAndTemplate(String auditName,Template template);
    
    @Query(value ="call getReportDataByAuditId(:auditId, :fromDate, :toDate)", nativeQuery = true)
    List<Object[]> getAuditReport(Integer auditId,String fromDate,String toDate); 
    
    //@Query(value ="call getReportDataByAuditId(20, '2020-12-01 00:00:00', '2020-12-23 23:59:59')", nativeQuery = true)
	//List<Object[]> getAuditReport(); 


    @Query(value ="call CashAuditMasterReport()", nativeQuery = true)
	List<Object[]> getCashAuditMasterReport();

    @Query(value ="select t.ticket_id,t.last_updated_date, tr.question_id, t.site_id, tr.response, tr.sequence " +
            "from ticket_response tr  " +
            "left join ticket t on t.ticket_id = tr.ticket_id  " +
            "left join audit a on t.audit_id = a.audit_id " +
            "where a.template_id = 37  " +
            "and t.last_updated_date > :fromDate and t.last_updated_date < :toDate " +
            "and t.status = 'COMPLETED'", nativeQuery = true)
    List<Object[]> downloadCash(String fromDate, String toDate);

    @Query(value ="select t.ticket_id,t.last_updated_date, tr.question_id, t.site_id, tr.response, tr.sequence " +
            "from ticket_response tr  " +
            "left join ticket t on t.ticket_id = tr.ticket_id  " +
            "left join audit a on t.audit_id = a.audit_id " +
            "where a.template_id = 37  " +
            "and  t.ticket_id =:ticketId ", nativeQuery = true)
    List<Object[]> getShortageOverage(Integer ticketId);

    @Query(value="call AuditSchedule()",nativeQuery=true)
    List<Object[]> auditSchedule();

    @Query(value="call ScheduledAuditTickets()",nativeQuery=true)
    List<Object[]> auditScheduleTicket();
}
