package com.infominez.audit.controller;


import com.infominez.audit.service.QuestionService;
import com.infominez.audit.wrapper.QuestionWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.QueryParam;

@RestController
@RequestMapping("/question")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class QuestionController {

    private final QuestionService questionService;

    @PostMapping("/create")
    public JSONObject create(@RequestBody QuestionWrapper question) {
        log.info(this.getClass().getName() + " :- create() ");
        return questionService.createQuestion(question);
    }

    @PostMapping("/update")
    public JSONObject update(@RequestBody QuestionWrapper question) {
        log.info(this.getClass().getName() + " :- update() ");
        return questionService.updateQuestion(question);
    }

    @GetMapping("/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return questionService.findQuestionById(id);
    }


    @GetMapping("/findAll")
    public JSONObject findAll() {
        log.info(this.getClass().getName() + " :- findAll() ");
        return questionService.findAllQuestion();
    }


    @GetMapping("/findQuestionByPageId")
    public JSONObject findQuestionByPageID(@QueryParam("pageId") Integer pageId) {
        log.info(this.getClass().getName() + " :-  findPageByTemplateId() ");
        return questionService.findQuestionByPageId(pageId);
    }


    @GetMapping("/findQuestionByQuestionId")
    public JSONObject findQuestionByQuestionId(@QueryParam("questionTypeId") Integer questionTypeId) {
        log.info(this.getClass().getName() + " :-  findQuestionByQuestionId() ");
        return questionService.findQuestionByQuestionTypeId(questionTypeId);
    }

    @PostMapping("/createQuestionWithMultipleOption")
    public JSONObject createQuestionWithMultipleOption(@RequestBody QuestionWrapper questionWrapper) {
        log.info(this.getClass().getName() + " :- createQuestionWithMultipleOption() ");
        return questionService.createQuestionWithMultipleOption(questionWrapper);
    }

    @GetMapping("/findQuestionByPageIdV2")
    public JSONObject findQuestionByPageIdV2(@QueryParam("pageId") Integer pageId) {
        log.info(this.getClass().getName() + " :-  findQuestionByPageIdV2() ");
        return questionService.findQuestionByPageIdV2(pageId);
    }
    
    @PostMapping("/updateQuestionWithMultipleOption")
    public JSONObject updateQuestionWithMultipleOption(@RequestBody QuestionWrapper questionWrapper) {
        log.info(this.getClass().getName() + " :- updateQuestionWithMultipleOption() ");
        return questionService.updateQuestionWithMultipleOption(questionWrapper);
    }

}
