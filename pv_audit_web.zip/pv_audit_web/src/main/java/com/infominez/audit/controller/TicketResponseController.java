package com.infominez.audit.controller;

import com.infominez.audit.entity.TicketResponse;

import com.infominez.audit.service.TicketResponseService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.util.IOUtils;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/ticketResponse")
@AllArgsConstructor
@Slf4j
public class TicketResponseController {
    private final TicketResponseService ticketResponseService;

    @PostMapping("/create")
    public JSONObject create(@RequestBody TicketResponse ticketResponse) {
        log.info(this.getClass().getName() + " :- create() ");
        return ticketResponseService.createTicketResponse(ticketResponse);
    }

    @PostMapping(  "/update")
    public JSONObject update(@RequestBody TicketResponse ticketResponse) {
        log.info(this.getClass().getName() + " :- update() ");
        return ticketResponseService.updateTicketResponse(ticketResponse);
    }

    @GetMapping(  "/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return ticketResponseService.findTicketResponseById(id);
    }

    @GetMapping(  "/findAll")
    public JSONObject findAll(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAll() ");
        return ticketResponseService.findAllTicketResponse();
    }

    @GetMapping( "/findTicketResponseByTicketId")
    public JSONObject findTicketResponseByTicketId(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- findTicketResponseByTicketId() ");
        return ticketResponseService.findTicketResponseByTicketId(ticketId);
    }
    @GetMapping( "/findTicketResponseByQuestionId")
    public JSONObject findTicketResponseByUsersId(@QueryParam("questionId") Integer questionId) {
        log.info(this.getClass().getName() + " :- findTicketResponseByQuestionId() ");
        return ticketResponseService.findTicketResponseByTicketId(questionId);
    }
    @PostMapping("/createMultipleTicketResponse")
    public JSONObject create(@RequestBody List<TicketResponse> ticketResponse) {
        log.info(this.getClass().getName() + " :- createMultipleTicketResponse() ");
        return ticketResponseService.createMultipleTicketResponse(ticketResponse);
    }
   @PostMapping("/filecreate")
    public JSONObject filecreate(@RequestPart("file") MultipartFile file,@RequestParam("path") String path,@RequestParam("fileName") String fileName) {
        log.info(this.getClass().getName() + " :- filecreate() ");
        return ticketResponseService.file(file,path,fileName);
    }

    @GetMapping( "/getResponseByTicketId")
    public JSONObject getResponseByTicketId(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- getResponseByTicketId() ");
        return ticketResponseService.getResponseByTicketId(ticketId);
    }
    @GetMapping("/downloadAuditResponseReport")
    public void downloadAuditResponseReport(@QueryParam("auditId") Integer auditId,
                                            @QueryParam("fromDate") String fromDate,@QueryParam("toDate") String toDate ,
                                HttpServletRequest request,
                                HttpServletResponse response) throws IOException {
        log.info("downloadAuditResponseReport()");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=downloadAuditResponseReport.xlsx");
        ByteArrayInputStream stream = ticketResponseService.downloadAuditResponseReport(auditId,fromDate,toDate);
        IOUtils.copy(stream, response.getOutputStream());
    }

}
