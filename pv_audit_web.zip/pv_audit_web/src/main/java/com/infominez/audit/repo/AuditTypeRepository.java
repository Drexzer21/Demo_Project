package com.infominez.audit.repo;

import com.infominez.audit.entity.AuditType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditTypeRepository extends JpaRepository<AuditType, Integer> {

    List<AuditType> findByAuditType(String auditType);

}
