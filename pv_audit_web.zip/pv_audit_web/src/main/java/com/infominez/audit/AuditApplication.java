package com.infominez.audit;

import com.infominez.audit.entity.Audit;
import com.infominez.audit.entity.Site;
import com.infominez.audit.entity.Users;
import com.infominez.audit.repo.AuditRepository;
import com.infominez.audit.repo.SiteRepository;
import com.infominez.audit.repo.TicketRepository;
import com.infominez.audit.repo.UsersRepository;
import com.infominez.audit.service.AuditService;
import com.infominez.audit.service.UserAuditScheduleService;
import com.infominez.audit.wrapper.AuditReport;

import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.converter.BufferedImageHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;

import static java.time.DayOfWeek.MONDAY;
import static java.time.DayOfWeek.SUNDAY;
import static java.time.temporal.TemporalAdjusters.nextOrSame;
import static java.time.temporal.TemporalAdjusters.previousOrSame;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SpringBootApplication
@EnableAsync
@EnableScheduling
public class AuditApplication {

    public static Map<String, Users> usersMap = new HashMap<>();
    public static Map<String, Site> siteMap = new HashMap<>();
    public static Map<String, Audit> auditMap = new HashMap<>();
    public static void main(String[] args) {
        SpringApplication.run(AuditApplication.class, args);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

    @Autowired
    public  SiteRepository siteRepository;

    @Autowired
    public  UsersRepository usersRepository;

    @Autowired
    public  AuditRepository auditRepository;

    @Autowired
    public TicketRepository ticketRepository;

    @Autowired
    public UserAuditScheduleService userAuditScheduleService;
    
    @Autowired
    public AuditService auditService;

    @Bean
    public HttpMessageConverter<BufferedImage> bufferedImageHttpMessageConverter() {
        return new BufferedImageHttpMessageConverter();
    }

    public static String getProperty(String key) {
        return usersMap.containsKey(key) ? usersMap.get(key).getMailingEmail() : null;
    }


    @Scheduled(fixedDelay = 900000, initialDelay = 10000)
    public void updateUserMap() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        System.out.println("User Map Update started at :: " + sdf.format(new Date()));
        try {
            List<Users> list = usersRepository.findAll();
            if (list != null) {
                Map<String, Users> tempMap = list.stream().collect(
                        Collectors.toMap(Users::getEmailId, Users::getClassObject));
                synchronized (usersMap) {
                    usersMap = new HashMap<String, Users>();
                    usersMap = tempMap;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("User Map Update  stopped at :: " + sdf.format(new Date()));
    }

    @Scheduled(fixedDelay = 900000, initialDelay = 10000)
    public void updateSiteMap() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        System.out.println("Site Map Update started at :: " + sdf.format(new Date()));
        try {
            List<Site> list = siteRepository.findAll();
            if (list != null) {
                Map<String, Site> tempMap = list.stream().collect(
                        Collectors.toMap(Site::getSiteCode, Site::getClassObject));
                synchronized (siteMap) {
                    siteMap = new HashMap<String, Site>();
                    siteMap = tempMap;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Site Map Update  stopped at :: " + sdf.format(new Date()));
    }

    @Scheduled(fixedDelay = 900000, initialDelay = 10000)
    public void updateAuditMap() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        System.out.println("Audit Map Update started at :: " + sdf.format(new Date()));
        try {
            List<Audit> list = auditRepository.findAll();
            if (list != null) {
                Map<String, Audit> tempMap = list.stream().collect(
                        Collectors.toMap(Audit::getAuditName, Audit::getClassObject));
                synchronized (auditMap) {
					auditMap = new HashMap<String, Audit>();
					auditMap = tempMap;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Audit Map Update  stopped at :: " + sdf.format(new Date()));
    }

    @Scheduled(fixedDelay = 300000, initialDelay = 10000)
    public void updateTicketStatusAuto() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            System.out.println("updateTicketStatusAuto started at :: " + sdf.format(new Date()));
            ticketRepository.updateTicketStatusAuto();
            System.out.println("updateTicketStatusAuto stopped at :: " + sdf.format(new Date()));
    }

  /*  @Scheduled(cron = "0 15 0 * * *")
    public void auditScheduleAuto() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        System.out.println("auditScheduleAuto started at :: " + sdf.format(new Date()));
        auditRepository.auditSchedule();
        System.out.println("auditScheduleAuto stopped at :: " + sdf.format(new Date()));
    }*/

//    @Scheduled(cron = "05 03 * * 4-6 *")
//    public void getScheduledAuditReportForAdmin() {
//    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//    	System.out.println("getScheduledAuditReportForAdmin started at :: " + sdf.format(new Date()));
//    	userAuditScheduleService.getScheduledAuditReportForAdmin();
//    	System.out.println("getScheduledAuditReportForAdmin stopped at :: " + sdf.format(new Date()));
//    }

//    @Scheduled(cron = "0 05 0 * * 4-6")
    public void getScheduledAuditReportForUsers() {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    	System.out.println("getScheduledAuditReportForUsers started at :: " + sdf.format(new Date()));
    	userAuditScheduleService.getUserScheduledAuditReportForUsers();
    	System.out.println("getScheduledAuditReportForUsers stopped at :: " + sdf.format(new Date()));
    }

//    @Scheduled(cron = "01 * * * * *")
//    public void getScheduledAuditReportForUsers() {
//    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//    	System.out.println("getScheduledAuditReportForUsers started at :: " + sdf.format(new Date()));
//    	userAuditScheduleService.getUserScheduledAuditReportForUsers();
//    	System.out.println("getScheduledAuditReportForUsers stopped at :: " + sdf.format(new Date()));
//    }

//     @Scheduled(cron = "* */50 3 * * * 4-6")
//    @Scheduled(cron = "0 05 3 * * 4-6")
//   @Scheduled(cron = "01 * * * * *")
    public void getScheduledAuditReportForAdmin() {
  	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
  	System.out.println("getScheduledAuditReportForAdmin started at :: " + sdf.format(new Date()));
  	userAuditScheduleService.getScheduledAuditReportForAdmin();
  	System.out.println("getScheduledAuditReportForAdmin stopped at :: " + sdf.format(new Date()));
  }

   @Scheduled(cron = "05 00 * * * *")
    public void scheduledAuditTickets() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        System.out.println("scheduledAuditTickets started at :: " + sdf.format(new Date()));
        auditRepository.auditScheduleTicket();
        System.out.println("scheduledAuditTickets stopped at :: " + sdf.format(new Date()));
    }
   
     @Scheduled(cron = "0 05 3 * * 4-6")
//  @Scheduled(cron = "01 * * * * *")
//   @Scheduled(cron = "0 05 12 * * 4-7")
     public void getScheduledAuditReportForAdminEmail() {
	  	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	  	System.out.println("getScheduledAuditReportForAdmin started at :: " + sdf.format(new Date()));
	  	userAuditScheduleService.getScheduledAuditReportForAdminEmail();
	  	System.out.println("getScheduledAuditReportForAdmin stopped at :: " + sdf.format(new Date()));
	  }
     
//     @Scheduled(cron="0 0 2 ? * MON") 
     public void getScheduledQRReport() throws IOException {
         
    	 AuditReport auditReport = new AuditReport();
         LocalDateTime today = LocalDateTime.now();
         LocalDateTime previousDate = today.minusDays(2);

         LocalDateTime localFromDate = previousDate.with(previousOrSame(MONDAY));
         LocalDateTime localToDate = previousDate.with(nextOrSame(SUNDAY));
         String fromDate = localFromDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd 00:00:00"));
         String toDate = localToDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd 23:59:59"));
         
         auditReport.setFromDate(fromDate);
         auditReport.setToDate(toDate);
        
         userAuditScheduleService.getScheduledQRReport(auditReport);
     }
     
}
