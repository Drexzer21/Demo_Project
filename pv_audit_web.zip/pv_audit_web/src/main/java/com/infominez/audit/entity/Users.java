package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;
import java.util.Date;
import java.util.stream.Stream;

@Entity
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name = "users" )
public class Users implements Serializable {
	
	private static final Long serialVersionUID = 1L;

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "user_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer userId;
	
    @Basic(optional = false)
    @Column(name = "first_name")
    private String firstName;

    @Basic(optional = false)
    @Column(name = "last_name")
    private String lastName;
    
    @Basic(optional = false)
    @Column(name = "username")
    private String userName;

    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    
    @Basic(optional = false)
    @Column(name = "phone_number")
    private String phoneNumber;
    
    @Basic(optional = false)
    @Column(name = "email_id")
    private String emailId;
    
    @Basic(optional = false)
    @Column(name = "is_active")
    private Boolean isActive;

    @JsonIgnore
    @Basic(optional = false)
            @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "last_updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDate;

    @Column(name = "sso_username")
    private String ssoUsername;

    @Column(name = "user_type")
    private String userType;
    
    @Column(name = "mailing_email ")
    private String mailingEmail ;

    @Transient
    public String getMapKey() {
    	return this.mailingEmail;
    }
    @Transient
    @JsonIgnore
    public Users getClassObject(){
        return this;
    }
}
