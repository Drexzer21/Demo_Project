package com.infominez.audit.wrapper;

import com.infominez.audit.entity.Site;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class UserAuditScheduleWrapper {
	private Integer userAuditScheduleId;
	private Integer templateId;
    private Integer usersId;
    private List<Site> siteList;
    private String visitType;
    private Integer noOfVisit;
    private String startDate;
    private String endDate;


}
