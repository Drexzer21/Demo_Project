package com.infominez.audit.repo;

import com.infominez.audit.entity.ConfigProperties;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConfigPropertiesRepository extends JpaRepository<ConfigProperties, Integer> {

    ConfigProperties findByType(String limit);
}
