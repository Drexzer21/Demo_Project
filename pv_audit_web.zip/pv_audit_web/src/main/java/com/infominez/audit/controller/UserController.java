package com.infominez.audit.controller;

import com.infominez.audit.entity.Users;
import com.infominez.audit.security.TokenProvider;

import com.infominez.audit.service.UsersService;
import com.infominez.audit.wrapper.BaseResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.util.IOUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * @author AYUSH PARTANI
 *
 */
@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class UserController {
	
	
	private final UsersService userService;

	@Autowired
	private TokenProvider tokenProvider;
	
	/*@RequestMapping( value = "/**"OPTIONS)
	public ResponseEntity handle() {
		return new ResponseEntity(HttpStatus.OK);
	}
	*/
	
    @PostMapping(  "/create")
	public JSONObject createUser(@RequestBody Users user) {
		log.info(this.getClass().getName() + " :- createUser");
		return userService.createUser(user);
	}
	
	
	@PostMapping(  "/update" )
	public JSONObject updateUser(@RequestBody Users user) {
		log.info(this.getClass().getName()+" :- updateUser");
		return userService.updateUser(user);
	}
	
	
	@GetMapping(  "/getAllUser")
    public JSONObject findAllUser() {

    	return userService.findAllUser();
	}
	
	
	@GetMapping( "/getUserById/{id}")
	public JSONObject findUserById(@PathVariable("id") Integer userId) {
		log.info(this.getClass().getName() + " :- findUserById");
		return userService.findUserById(userId);
	}

	
	@GetMapping(  "/getUserProfile")
	public JSONObject getUserProfile(HttpServletRequest request,
									   HttpServletResponse response) {
		log.info(this.getClass().getName() + " :- findUserById");
		JSONObject baseResponse = new JSONObject();
		try {
			String token = request.getHeader("Authorization").substring("Bearer".length()).trim();

			String username = tokenProvider.getUsernameByAccessToken(token);
			if (username != null){
				Users user = userService.findUserByName(username);
				baseResponse.put("status",200);
				baseResponse.put("response",user);
				return baseResponse;
			}else{
				baseResponse.put("status",302);
				baseResponse.put("response",null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			baseResponse.put("status",500);
			baseResponse.put("response","Something went to wrong Please Login again");
			return baseResponse;

		}

		return baseResponse;
	}
	
	 @GetMapping("/downloadAuditUsersList")
	    public void downloadAuditUsersList( HttpServletRequest request, HttpServletResponse response) throws IOException {
	        log.info("downloadAuditUsersList()");
	        response.setContentType("application/octet-stream");
	        response.setHeader("Content-Disposition", "attachment; filename=AuditUsersList.xlsx");
	        ByteArrayInputStream stream = userService.downloadAuditUsersList();
	        IOUtils.copy(stream, response.getOutputStream());
	    }
	 
	 @GetMapping( "/inActiveUser")
		public JSONObject inActiveUser(@QueryParam("userId") Integer userId) {
			log.info(this.getClass().getName() + " :- inActiveUser");
			return userService.inActiveUser(userId);
		}
	 
	  @PostMapping("/bulkUploadUsers")
	    public JSONObject bulkUploadUsers(@RequestPart("file") MultipartFile file, HttpServletRequest request, HttpServletResponse response) throws IOException {
	        log.info(this.getClass().getName() + " :-  bulkUploadUsers() ");
	        InputStream inputStream = new BufferedInputStream(file.getInputStream());
	        return userService.bulkUploadUsers(inputStream);
	    }
	@GetMapping( "/setActiveInActiveUser")
	public JSONObject setActiveInActiveUser(@QueryParam("userId") Integer userId) {
		log.info(this.getClass().getName() + " :- setActiveInActiveUser userId:{}",userId);
		return userService.setActiveInActiveUser(userId);
	}

}
