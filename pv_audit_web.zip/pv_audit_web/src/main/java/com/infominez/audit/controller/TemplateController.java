package com.infominez.audit.controller;

import com.infominez.audit.entity.Template;
import com.infominez.audit.service.TemplateService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;

import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;

@RestController
@RequestMapping("/template")
@AllArgsConstructor
@Slf4j
public class TemplateController {

    private final TemplateService templateService;

    @PostMapping("/create")
    public JSONObject create(@RequestBody Template template) {
        log.info(this.getClass().getName() + " :- create() ");
        return templateService.createTemplate(template);
    }

    @PostMapping(  "/update")
    public JSONObject update(@RequestBody Template template) {
        log.info(this.getClass().getName() + " :- update() ");
        return templateService.updateTemplate(template);
    }

    @GetMapping(  "/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return templateService.findTemplateById(id);
    }

    @GetMapping(  "/findAll")
    public JSONObject findAll(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAll() ");
        return templateService.findAllTemplate();
    }

    @GetMapping( "/findTemplateByAuditTypeId")
    public JSONObject findTemplateByAuditTypeId(@QueryParam("auditTypeId") Integer auditTypeId) {
        log.info(this.getClass().getName() + " :- findTemplateByAuditTypeId() ");
        return templateService.findTemplatesByAuditTypeId(auditTypeId);
    }

    @GetMapping(  "/findAllTempateList")
    public JSONObject findAllTempateList(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAllTempateList() ");
        return templateService.findAllTemplateList();
    }

    @GetMapping(  "/getTemplateDetail")
    public JSONObject getTemplateDetail(@QueryParam("templateId") Integer templateId,HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- getTemplateDetail() ");
        return templateService.getTemplateDetail(templateId);
    }
    @GetMapping("/createTemplateCopy")
    public JSONObject createTemplateCopy(@QueryParam("templateId") Integer templateId) {
        log.info(this.getClass().getName() + " :- createTemplateCopy() ");
        return templateService.createTemplateCopy(templateId);
    }
    @GetMapping("/exportTemplate")
    public JSONObject exportTemplate(@QueryParam("templateId") Integer templateId) {
        log.info(this.getClass().getName() + " :- exportTemplate() ");
        return templateService.exportTemplate(templateId);
    }

}
