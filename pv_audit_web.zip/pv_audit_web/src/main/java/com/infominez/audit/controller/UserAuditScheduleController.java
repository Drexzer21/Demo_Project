package com.infominez.audit.controller;

import com.infominez.audit.base.BaseController;
import com.infominez.audit.entity.ScheduleSite;
import com.infominez.audit.entity.UserAuditSchedule;
import com.infominez.audit.entity.Users;
import com.infominez.audit.service.UserAuditScheduleService;
import com.infominez.audit.wrapper.UserAuditScheduleWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.util.IOUtils;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/userAuditSchedule")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class UserAuditScheduleController extends BaseController{
	private final UserAuditScheduleService userAuditScheduleService;

    @PostMapping("/createUserAuditSchedule")
    public JSONObject createUserAuditSchedule(@RequestBody UserAuditSchedule userAuditSchedule) {
        log.info(this.getClass().getName() + " :- createUserAuditSchedule() ");
        return userAuditScheduleService.createUserAuditSchedule(userAuditSchedule);
    }

    @PostMapping(  "/updateUserAuditSchedule")
    public JSONObject updateUserAuditSchedule(@RequestBody UserAuditScheduleWrapper userAuditScheduleWrapper,
    		HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- updateUserAuditSchedule() ");
        JSONObject result = new JSONObject();
        Users user = super.getUser(request);
        if (user == null){
        	result.put("status", 500);
            result.put("response", "Unauthorized Access");
        }
        return userAuditScheduleService.updateUserAuditSchedule(userAuditScheduleWrapper,user.getUserId());
    }

    @GetMapping(  "/getUserAuditScheduleById/{id}")
    public JSONObject getUserAuditScheduleById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :-getUserAuditScheduleById () ");
        return userAuditScheduleService.getUserAuditScheduleById(id);
    }

    @GetMapping(  "/getAllUserAuditSchedule")
    public JSONObject getAllUserAuditSchedule(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :-getAllUserAuditSchedule () ");
        return userAuditScheduleService.getAllUserAuditSchedule();
    }
    
    @GetMapping(  "/deleteUserAuditSchedule")
    public JSONObject deleteUserAuditSchedule(@QueryParam("userAuditScheduleId") Integer userAuditScheduleId,HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- deleteUserAuditSchedule() ");
        return userAuditScheduleService.deleteUserAuditSchedule(userAuditScheduleId);
    }
    
    @GetMapping("/getAllUserAuditSchedulePageable")
    public  JSONObject getAllUserAuditSchedulePageable(@QueryParam("page") int page,
            @QueryParam("size") int size, HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " getAllUserAuditSchedulePageable",page,size);
        return userAuditScheduleService.getAllUserAuditSchedulePageable(page,size);
    }

    @PostMapping("/createUserAuditScheduleWithScheduleSite")
    public JSONObject createUserAuditScheduleWithScheduleSite(@RequestBody UserAuditScheduleWrapper userAuditScheduleWrapper,HttpServletRequest request,
    		HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- createUserAuditScheduleWithScheduleSite() ");
        JSONObject result = new JSONObject();
        Users user = super.getUser(request);
        if (user == null){
        	result.put("status", 500);
            result.put("response", "Unauthorized Access");
        }
        return userAuditScheduleService.createUserAuditScheduleWithScheduleSite(userAuditScheduleWrapper,user.getUserId());
    }
    @GetMapping("/findAllUserAuditSchedule")
    public JSONObject findAllUserAuditSchedule(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + ":- findAllUserAuditSchedule :{}");
        return userAuditScheduleService.findAllUserAuditSchedule();
    }

    @PostMapping("/bulkDeleteScheduleSite")
    public JSONObject bulkDeleteScheduleSite(@RequestBody List<ScheduleSite> scheduleSites ,HttpServletRequest request,
    		HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- bulkDeleteScheduleSite() ");

        return userAuditScheduleService.bulkDeleteScheduleSite(scheduleSites);
    }

 @GetMapping("/getScheduleDetails")
    public JSONObject getScheduleDetails(@QueryParam("id") Integer id,HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + ":- getScheduleDetails  id:{}", id);
        return userAuditScheduleService.getScheduleDetails(id);
    }

    @GetMapping("/getListOfUserScheduled")
    public JSONObject getListOfUserScheduled (HttpServletRequest request
            , HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- getListOfUserScheduled() ");
        return userAuditScheduleService.getListOfUserScheduled();
    }
    @PostMapping("/bulkUploadForAuditScheduling")
    public JSONObject bulkUploadUsers(@RequestPart("file") MultipartFile file, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info(this.getClass().getName() + " :-  bulkUploadForAuditScheduling() ");
        InputStream inputStream = new BufferedInputStream(file.getInputStream());
        return userAuditScheduleService.bulkUploadForAuditScheduling(inputStream);
    }
    
    @GetMapping("/getScheduledAuditReportForAdmin")
	 public void getScheduledAuditReportForAdminV2(HttpServletRequest request, HttpServletResponse response) throws IOException {
		log.info("getScheduledAuditReportForAdminV2()");
		response.setContentType("application/octet-stream");
		SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
		String fileName = "Scheduled_Audit_Report_As_On_" + df.format(new Date()); 
       response.setHeader("Content-Disposition", "attachment; filename ="+ fileName +".xlsx");
       ByteArrayInputStream stream = userAuditScheduleService.getScheduledAuditReportForAdminV2();
       IOUtils.copy(stream, response.getOutputStream());
	}
    
//    @GetMapping("/getUserScheduledAuditReportForUsers")
//	 public void getUserScheduledAuditReportForUsers(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		log.info("getUserScheduledAuditReportForUsers ()");
//		response.setContentType("application/octet-stream");
//      response.setHeader("Content-Disposition", "attachment; filename=ScheduledAuditReportForUsers.xlsx");
//      ByteArrayInputStream stream = userAuditScheduleService.getUserScheduledAuditReportForUsers();
//      IOUtils.copy(stream, response.getOutputStream());
//	}


}
