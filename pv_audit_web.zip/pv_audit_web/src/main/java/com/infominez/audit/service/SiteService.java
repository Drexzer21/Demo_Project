package com.infominez.audit.service;

import com.infominez.audit.entity.Site;
import com.infominez.audit.repo.SiteRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class SiteService {
    private final SiteRepository siteRepository;


    public JSONObject createSite(Site site) {
        log.info(this.getClass().getName() + " :- createSite() : {}", site.toString());
        JSONObject result = new JSONObject();
        try {
            List<Site> list = siteRepository.findBySiteName(site.getSiteName());
            if (list != null && !list.isEmpty() && site.getSiteId() != list.get(0).getSiteId()) {
                result.put("status", 302);
                result.put("response", "Site already Exist with SiteId : " + site.getSiteId());
            } else {
                Site createdSite = siteRepository.save(site);

                if (createdSite != null) {
                    result.put("status", 200);
                    result.put("response", "Site Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add Site");
                }
            }
        } catch (Exception e) {

            log.error("Exception in createSite for Site : {} and exception : {} ", site.toString(), e.getMessage());
            log.trace("Exception in createSite for Site : {} and trace : {} ", site.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject getAllState() {
        JSONObject result = new JSONObject();
        try {
            List<Object> list = siteRepository.getAllState();
            JSONArray stateList = new JSONArray();
            for (Object obj : list) {
                JSONObject state = new JSONObject();
                state.put("state", obj);
                stateList.add(state);
            }
            result.put("status", 200);
            result.put("response", stateList);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getAllCity() {
        JSONObject result = new JSONObject();
        try {
            List<Object> list = siteRepository.getAllCity();
            JSONArray cityList = new JSONArray();
            for (Object obj : list) {
                JSONObject city = new JSONObject();
                city.put("city", obj);
                cityList.add(city);
            }
            result.put("status", 200);
            result.put("response", cityList);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private String getCellValue(Cell cell) {
        return new DataFormatter().formatCellValue(cell);
    }


    public JSONObject bulkUploadSite(InputStream inputStream) {
        log.info("Bulk Upload Site");
        JSONObject result = new JSONObject();
        try {
            List<Site> dbSite = siteRepository.findAll();
            List<Site> tobeInsertSite = new ArrayList<>();
            Workbook wb = WorkbookFactory.create(inputStream);
            Sheet sheet = wb.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = (Row) rowIterator.next();
                if (row.getRowNum() > 0) {
                    Site site = new Site();
                    site.setSiteName(getCellValue(row.getCell(0)));
                    site.setSiteCode(getCellValue(row.getCell(1)));
                    site.setState(getCellValue(row.getCell(2)));
                    site.setCity(getCellValue(row.getCell(3)));
                    site.setSiteAddress(getCellValue(row.getCell(4)));
                    site.setPincode(getCellValue(row.getCell(5)));
                    site.setAssets(getCellValue(row.getCell(6)));
                    
                    String latitude = getCellValue(row.getCell(7));
                    if (latitude !=null) {
                        try{
                    	double lati=Double.parseDouble(latitude);
                    site.setLatitude(lati);
					}catch (Exception e) {
                            site.setLatitude(null);

                        }
                        }
                    String longitude = getCellValue(row.getCell(8));
                    if (longitude !=null) {
                        try {
                            double longi = Double.parseDouble(longitude);
                            site.setLongitude(longi);
                        } catch (Exception e) {
                            site.setLongitude(null);

                        }
                    }
                    if (!checkIfExistInList(site, dbSite)) {
                        if (!checkIfExistInList(site, tobeInsertSite)) {
                            tobeInsertSite.add(site);
                        }
                    }
                }
            }
            List<Site> inserted = siteRepository.saveAll(tobeInsertSite);
            if (inserted != null && inserted.size() > 0) {
                result.put("status", 200);
                result.put("response", "Bulk Upload Site Successfull");
            } else {
                result.put("status", 302);
                result.put("response", "Bulk Upload Site FAILED");
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception occur in Site bulk Upload : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }


        return result;
    }

    private boolean checkIfExistInList(Site site, List<Site> dbSite) {
        Boolean result = true;
        if (dbSite != null && dbSite.size() > 0) {
            for (Site object : dbSite) {
                if (object.getSiteCode().equalsIgnoreCase(site.getSiteCode())) {
                    result = true;
                    break;
                } else
                    result = false;
            }
        } else {
            result = false;
        }
        return result;
    }

    public JSONObject  getSiteWithFilters(JSONObject jsonObject) {
        JSONObject result = new JSONObject();
        try{
            String state = jsonObject.get("state") != null ? String.valueOf(jsonObject.get("state")) : null;
            String city = jsonObject.get("city") != null ? String.valueOf(jsonObject.get("city")) : null;
            List<Site> list = siteRepository.findByStateAndCity(state,city);
            if (list != null) {
                result.put("status", 200);
                result.put("response", list);
            } else {
                result.put("status", 302);
                result.put("response", "Site Not found");
            }
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getAllSites() {
        JSONObject result = new JSONObject();
        try {
            result.put("status", 200);
            result.put("response", siteRepository.findAll());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getSiteWithFiltersForSchedule(JSONObject jsonObject) {
        JSONObject result = new JSONObject();
        try{
            if (jsonObject.get("templateId") == null){
                result.put("status", 302);
                result.put("response", "Please Select Template");
                return result;
            }
            if (jsonObject.get("userId") == null){
                result.put("status", 302);
                result.put("response", "Please Select User");
                return result;
            }
            Integer templateId = Integer.parseInt(String.valueOf(jsonObject.get("templateId")));
            Integer userId = Integer.parseInt(String.valueOf(jsonObject.get("userId")));
            String state = jsonObject.get("state") != null ? String.valueOf(jsonObject.get("state")) : null;
            String city = jsonObject.get("city") != null ? String.valueOf(jsonObject.get("city")) : null;
            List<Site> list = siteRepository.getSiteWithFiltersForSchedule(templateId, userId,state,city);
            if (list != null) {
                result.put("status", 200);
                result.put("response", list);
            } else {
                result.put("status", 302);
                result.put("response", "Site Not found");
            }
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
}
