package com.infominez.audit.repo;

import com.infominez.audit.entity.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface TicketRepository extends JpaRepository<Ticket,Integer> {
    List<Ticket> findByAudit(Audit audit);
    List<Ticket> findByUsers(Users users);
    List<Ticket> findByAndSite(Site site);
    List<Ticket> findByAuditAndUsersAndSite(Audit audit,Users users,Site site);
    List<Ticket> findByAuditAndUsersAndSiteAndStatusNot(Audit audit,Users users,Site site,String status);

    @Query(value = "select a.audit_name, a.start_date, a.end_date, " +
            "sum( case when t.status = 'COMPLETED' then 1 else 0 end ) as doneCount, " +
            "sum( case when t.status != 'COMPLETED' then 1 else 0 end ) as pendingCount, " +
            "count(*) as total, " +
            "a.audit_id," +
            "sum( case when t.is_adhoc = '1' then 1 else 0 end ) as adhocTicketCount "+
            " from ticket t " +
            "join audit a on a.audit_id = t.audit_id " +
            "join users u on u.user_id = t.user_id " +
            "join site s on s.site_id = t.site_id  " +
            "where t.user_id = :userId " +
            " and  a.end_date  > now() " +
            "and (t.is_scheduled_ticket is null or t.is_scheduled_ticket = 0 ) " +
            "group by a.audit_name , a.start_date, a.end_date, a.audit_id ",
            nativeQuery = true)
    List<Object[]> getDashboardData(Integer userId);


    @Query(value = "select a.audit_name, a.start_date, a.end_date, " +
            "sum( case when t.status = 'COMPLETED' then 1 else 0 end ) as doneCount, " +
            "sum( case when t.status != 'COMPLETED' then 1 else 0 end ) as pendingCount, " +
            "count(*) as total, " +
            "a.audit_id," +
            "sum( case when t.is_adhoc = '1' then 1 else 0 end ) as adhocTicketCount "+
            " from ticket t " +
            "join audit a on a.audit_id = t.audit_id " +
            "join users u on u.user_id = t.user_id " +
            "join site s on s.site_id = t.site_id  " +
            "where t.user_id = :userId " +
            " and  a.end_date  > now() " +
            "and  t.is_scheduled_ticket is not null and t.is_scheduled_ticket = 1   " +
            "group by a.audit_name , a.start_date, a.end_date, a.audit_id ",
            nativeQuery = true)
    List<Object[]> getDashboardDataOffline(Integer userId);

    @Query(value = "select t from Ticket t where t.audit.auditId = :auditId and t.status = :status and t.users" +
            ".userId=:userId",
            nativeQuery =
            false)
    List<Ticket> findByAuditAndStatus(Integer auditId, String status, Integer userId);

    @Query(value = "select * from ticket t where t.audit_id = :auditId and t.status != :status and t.user_id= :userId and is_select_for_offline = 1",
            nativeQuery = true)
    List<Ticket> findPendingOfflineDataByAuditAndStatus(Integer auditId, String status, Integer userId);

    @Query(value = "select * from ticket t where t.audit_id = :auditId and t.status != :status and t.user_id =:userId",
            nativeQuery = true)
    List<Ticket> findByAuditAndStatusReverse(Integer auditId, String status, Integer userId);
    List<Ticket> findByStatus(String status);

    @Query(value = "select count(*) as totalCount, " +
            "sum(case when t.status != 'COMPLETED' then 1 else 0 end) as pendingCount, " +
            "sum(case when t.status = 'COMPLETED' then 1 else 0 end) as completeCount " +
            "from ticket t " +
            " inner  join audit a on a.audit_id = t.audit_id  " +
            "where t.user_id = ? " +
            "and  a.end_date  > now() " +
            "and (t.is_scheduled_ticket is null or t.is_scheduled_ticket = 0 )",
            nativeQuery = true)
    List<Object[]> getCurrentAuditByUser(Integer userId);

    @Query(value = "select count(*) as totalCount, " +
            "sum(case when t.status != 'COMPLETED' then 1 else 0 end) as pendingCount, " +
            "sum(case when t.status = 'COMPLETED' then 1 else 0 end) as completeCount " +
            "from ticket t " +
            " inner  join audit a on a.audit_id = t.audit_id  " +
            "where t.user_id = ? " +
            "and  a.end_date  > now() " +
            "and t.is_scheduled_ticket is not  null and  t.is_scheduled_ticket = 1 ",
            nativeQuery = true)
    List<Object[]> getCurrentAuditByUserScheduled(Integer userId);

    @Query(value = "select t.template_name , a.audit_name, a.start_date, a.end_date, " +
            "count(distinct(tt.user_id)) as team, " +
            "count(tt.ticket_id) as total, " +
            "sum(case when tt.user_id is not null then 1 else 0 end ) as assigned, " +
            "sum(case when tt.user_id is null then 1 else 0 end ) as unassigned, " +
            "sum(case when tt.user_id is not null and tt.status = 'COMPLETED' then 1 else 0 end ) as completed, " +
            "sum(case when tt.user_id is not null and tt.status != 'COMPLETED' then 1 else 0 end ) as PENDING, " +
            "(case when a.start_date < now() and a.end_date > now() then 'LIVE' else 'UPCOMING' end ) as state " +
            " from template t " +
            "inner join audit a on a.template_id = t.template_id " +
            "left outer join ticket tt on tt.audit_id = a.audit_id " +
            "where a.end_date > now() " +
            "group by a.audit_id " +
            " ",
            nativeQuery = true)
    List<Object[]> getAdminDashboardData();


    @Query(value = "call UpdateTicketStatus(?)",
            nativeQuery = true)
    void callUpdateTicketStatus(Integer ticketId);

    @Query("Select t from Ticket t where t.isScheduledTicket = false and t.audit.auditName like %:searchTerm% " +
            "OR t.ticketId like %:searchTerm% " +
            "OR t.audit.template.templateName  like %:searchTerm%  " +
            "OR t.site.siteCode  like %:searchTerm%  " +
            "OR t.site.city  like %:searchTerm%  " +
            "OR t.site.siteAddress  like %:searchTerm%  " +
            "OR t.site.state  like %:searchTerm%  " +
            "OR t.users.userName like %:searchTerm%  " +
            "OR t.users.ssoUsername like %:searchTerm%  " +
            "OR t.users.emailId like %:searchTerm%  " +
            "OR t.site.siteName  like %:searchTerm%  " +
            "OR t.site.pincode  like %:searchTerm%  ")
    List<Ticket> searchTicket(@Param("searchTerm") String searchTerm);

    Page<Ticket> findAllByIsDeleted(Boolean isDeleted, Pageable pageable);

    @Query(value = "call autoUpdateTicket()",
            nativeQuery = true)
    void updateTicketStatusAuto();


    @Query(value = "select count(*) as totalCount, " +
            "sum(case when t.status != 'COMPLETED' then 1 else 0 end) as pendingCount, " +
            "sum(case when t.status = 'COMPLETED' then 1 else 0 end) as completeCount " +
            "from ticket t " +
            " inner  join audit a on a.audit_id = t.audit_id  " +
            "where t.user_id = ? " +
            "and  a.end_date  > now() " +
            " and t.is_scheduled_ticket = 1",
            nativeQuery = true)
    List<Object[]> getScheduledAuditByUser(Integer userId);


    List<Ticket> findByIsScheduledTicketAndLastUpdatedDateBetween(Boolean isScheduledTicket,Date fromDate, Date toDate);


    Page<Ticket> findAllByIsDeletedAndIsScheduledTicketAndLastUpdatedDateBetween(Boolean isDeleted,Boolean isScheduledTicket, Pageable pageable,Date fromDate, Date toDate);

    @Query("Select t from Ticket t where t.isScheduledTicket = true and t.audit.auditName like %:searchTerm% " +
            "OR t.ticketId like %:searchTerm% " +
            "OR t.audit.template.templateName  like %:searchTerm%  " +
            "OR t.site.siteCode  like %:searchTerm%  " +
            "OR t.site.city  like %:searchTerm%  " +
            "OR t.site.siteAddress  like %:searchTerm%  " +
            "OR t.site.state  like %:searchTerm%  " +
            "OR t.users.userName like %:searchTerm%  " +
            "OR t.users.ssoUsername like %:searchTerm%  " +
            "OR t.users.emailId like %:searchTerm%  " +
            "OR t.site.siteName  like %:searchTerm%  " +
            "OR t.site.pincode  like %:searchTerm%  ")
    List<Ticket> searchTicketScheduled(@Param("searchTerm") String searchTerm);

    @Query(value = "select * from ticket where is_scheduled_ticket= 1 and (user_id = :userId or :userId IS NULL)  and (site_id = :siteId or :siteId IS NULL) and (is_adhoc = :isAdhoc or :isAdhoc is null) and last_updated_date >= :fromDate and last_updated_date <= :toDate ",
            nativeQuery = true)
    List<Ticket> findByIsScheduledTicket(Integer userId,Integer siteId,Boolean isAdhoc,Date fromDate, Date toDate);

    @Query(value = "SELECT * FROM ticket t "
    		+ "inner join site s on t.site_id = s.site_id "
    		+ "where t.is_deleted = :isDeleted and t.is_scheduled_ticket = :isScheduledTicket "
    		+ "and (t.user_id = :userId or :userId IS NULL) "
    		+ "and (s.site_code = :siteCode or :siteCode IS NULL) "
    		+ "and t.is_adhoc = :isAdhoc "
    		+ "and t.created_date >= :fromDate and t.created_date <= :toDate ",
    		countQuery = "SELECT count(*) FROM ticket t "
    	    		+ "inner join site s on t.site_id = s.site_id "
    	    		+ "where t.is_deleted = :isDeleted and t.is_scheduled_ticket = :isScheduledTicket "
    	    		+ "and (t.user_id = :userId or :userId IS NULL) "
    	    		+ "and (s.site_code = :siteCode or :siteCode IS NULL) "
    	    		+ "and t.is_adhoc = :isAdhoc "
    	    		+ "and t.created_date >= :fromDate and t.created_date <= :toDate ",
    	    		nativeQuery = true)
    Page<Ticket> findAllByTicketFiltersWithType(Boolean isDeleted,Boolean isScheduledTicket, Pageable pageable,Integer userId,String siteCode,Boolean isAdhoc,Date fromDate, Date toDate);

    @Query(value = "SELECT * FROM ticket t "
    		+ " inner join site s on t.site_id = s.site_id "
    		+ "where t.is_deleted = :isDeleted and t.is_scheduled_ticket = :isScheduledTicket "
    		+ "and (t.user_id = :userId or :userId IS NULL) "
    		+ "and (s.site_code = :siteCode or :siteCode IS NULL) "
    		+ "and t.created_date >= :fromDate and t.created_date <= :toDate ",
    		countQuery = "SELECT count(*) FROM ticket t "
    	    		+ "inner join site s on t.site_id = s.site_id "
    	    		+ "where t.is_deleted = :isDeleted and t.is_scheduled_ticket = :isScheduledTicket "
    	    		+ "and (t.user_id = :userId or :userId IS NULL) "
    	    		+ "and (s.site_code = :siteCode or :siteCode IS NULL) "
    	    		+ "and t.created_date >= :fromDate and t.created_date <= :toDate ",
    	    nativeQuery = true)
    Page<Ticket> findAllByTicketFiltersWithoutType(Boolean isDeleted,Boolean isScheduledTicket, Pageable pageable,Integer userId,String siteCode,Date fromDate, Date toDate);

    @Query(value = "select a.audit_name, a.start_date, a.end_date, " +
            "sum( case when t.status = 'COMPLETED' then 1 else 0 end ) as doneCount, " +
            "sum( case when t.status != 'COMPLETED' then 1 else 0 end ) as pendingCount, " +
            "count(*) as total, " +
            "a.audit_id," +
            "sum( case when t.is_adhoc = '1' then 1 else 0 end ) as adhocTicketCount "+
            " from ticket t " +
            "join audit a on a.audit_id = t.audit_id " +
            "join users u on u.user_id = t.user_id " +
            "join site s on s.site_id = t.site_id  " +
            "where t.user_id = :userId " +
            " and  a.end_date  > now() " +
            " and t.is_scheduled_ticket = 1 " +
            "group by a.audit_name , a.start_date, a.end_date, a.audit_id ",
            nativeQuery = true)
    List<Object[]> getDashboardDataScheduled(Integer userId);

    @Query(value = "select * from ticket where audit_id = :auditId and user_id = :userId and site_id= :siteId  and  is_adhoc =  1 and status != 'COMPLETED' ",
            nativeQuery = true)
    Ticket getPendingAdhocTicket(Integer auditId, Integer userId, Integer siteId);

    @Query(value = "select * from ticket where ticket_id = :ticketId",
            nativeQuery = true)
    Ticket findScheduledTicket(Integer ticketId);

    @Query(value = "select count(*) from ticket t  " +
            "inner join audit a on a.audit_id = t.audit_id " +
            "where t.user_id = :userId and t.is_select_for_offline = 1 " +
            "and a.end_date > now() " +
            "and t.status in ('PENDING', 'IN-PROGRESS')",
            nativeQuery = true)
    Integer getCountOfOfflineMarkedTicketOfUser(Integer userId);
    
    @Query(value =  "select checkIsAdhocAllowed(:ticketId)", nativeQuery = true)
    Boolean checkIsAdhocAllowed(Integer ticketId);
}
