package com.infominez.audit.service;


import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.Question;
import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.entity.QuestionTypeOption;
import com.infominez.audit.repo.PageRepository;
import com.infominez.audit.repo.QuestionRepository;
import com.infominez.audit.repo.QuestionTypeOptionRepository;
import com.infominez.audit.repo.QuestionTypeRepository;
import com.infominez.audit.utils.EnumUtils;
import com.infominez.audit.wrapper.QuestionRequest;
import com.infominez.audit.wrapper.QuestionWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class QuestionService {

    private final QuestionRepository questionRepository;
    private final QuestionTypeRepository questionTypeRepository;
    private final PageRepository pageRepository;
    private final QuestionTypeOptionRepository questionTypeOptionRepository;

    public JSONObject createQuestion(QuestionWrapper question) {
        log.info(this.getClass().getName() + " :- createQuestion()");
        JSONObject result = new JSONObject();
        try {
            List<Question> list = questionRepository.findByPageAndQuestionAndQuestionType(question.getPage(), question.getQuestion(), question.getQuestionType());
            if (list != null && !list.isEmpty()) {
                result.put("status", 302);
                result.put("response", "Question already Exist with Question : " + question.getQuestion() + " , PageID : " + question.getPage().getPageId() + "and Question Type Id" + question.getQuestionType().getQuestionTypeId());
                return result;
            }
            if(question.getIsDerived()==true){
                if(question.getOperands() == null || question.getOperands().isEmpty()){
                    result.put("status", 302);
                    result.put("response", "Please choose the operands");
                    return result;
                }
                if(question.getOperator() == null || question.getOperator().isEmpty()){
                    result.put("status", 302);
                    result.put("response", "Please choose the operators");
                    return result;
                }
                if(question.getOperator().size() != question.getOperands().size()-1){
                    result.put("status", 302);
                    result.put("response", "Operators should be one less than operands.");
                    return result;
                }
            }
            Question createdQuestion = new Question();
                Date date = new Date();
                createdQuestion.setCreatedBy(1); // todo change when login is implemented
                createdQuestion.setUpdatedBy(1); // todo change when login is implemented
                createdQuestion.setCreatedDate(date);
                createdQuestion.setLastUpdatedDate(date);
                createdQuestion.setIsDerived(true);
                String operandList = question.getOperands().stream().map(String::valueOf).collect(Collectors.joining(","));
                System.out.println("operandList : "+ operandList);
                createdQuestion.setOperand(operandList);
                String operatorList = question.getOperands().stream().map(String::valueOf).collect(Collectors.joining(","));
                System.out.println("operatorList : "+ operatorList);
                createdQuestion.setOperator(operatorList);
                if(question.getQuestion() != null && !question.getQuestion().isEmpty()){
                    createdQuestion.setQuestion(question.getQuestion());
                }
                if(question.getQuestionType() != null){
                    createdQuestion.setQuestionType(question.getQuestionType());
                }
                if(question.getQuestionType().getQuestionType().equalsIgnoreCase("signature")){
                	createdQuestion.setCaptureImgStatus(2);
                	createdQuestion.setIsMadatory(true);
                } else {
                	if (question.getCaptureImgStatus() != null) {
                		createdQuestion.setCaptureImgStatus(question.getCaptureImgStatus());
                	}
                	if(question.getIsMadatory() != null ){
                        createdQuestion.setIsMadatory(question.getIsMadatory());
                    }
                }

            if(question.getInfluenceBy() != null ){
                createdQuestion.setInfluenceBy(question.getInfluenceBy());
            }
            if(question.getInfluencerResponseValue() != null && !question.getInfluencerResponseValue().isEmpty()){
                createdQuestion.setInfluencerResponseValue(question.getInfluencerResponseValue());
            }
            if(question.getIsPrefilled() != null ){
                createdQuestion.setIsPrefilled(question.getIsPrefilled());
            }
            if(question.getSequence() != null ){
                createdQuestion.setSequence(question.getSequence());
            }
            if(question.getParentId() != null ){
                createdQuestion.setParentId(question.getParentId());
            }
            if(question.getDataType() != null && !question.getDataType().isEmpty()){
                createdQuestion.setDataType(question.getDataType());
            }
            if(question.getDefaultValue() != null && !question.getDefaultValue().isEmpty()){
                createdQuestion.setDefaultValue(question.getDefaultValue());
            }
            if(question.getPage() != null ){
                createdQuestion.setPage(question.getPage());
            }
            if(question.getIsYesNo() != null ){
            	 createdQuestion.setIsYesNo(question.getIsYesNo());
            }

             createdQuestion = questionRepository.save(createdQuestion);
                if (createdQuestion != null) {
                    result.put("status", 200);
                    result.put("response", "Question Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add Question");
                }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in createQuestion for Question : {} and exception : {} ", question.toString(), e.getMessage());
            log.trace("Exception in createPage for Question : {} and trace : {} ", question.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;

    }


    public JSONObject updateQuestion(QuestionWrapper question) {
        log.info(this.getClass().getName() + " :- updateQuestion()");
        JSONObject result = new JSONObject();
        try {
            Date date = new Date();
            List<Question> list = questionRepository.findByPageAndQuestionAndQuestionType(question.getPage(), question.getQuestion(), question.getQuestionType());
            if (list != null && !list.isEmpty() && !question.getQuestionId().equals(list.get(0).getQuestionId())) {
                result.put("status", 302);
                result.put("response", "Question already Exist with Question : " + question.getQuestion() + " , PageID : " + question.getPage().getPageId() + "and Question Type Id" + question.getQuestionType().getQuestionTypeId());
            } else {
                Question QuestionToUpdate = questionRepository.findById(question.getQuestionId()).get();
                if (QuestionToUpdate != null) {
                    if (question.getQuestion() != null && !question.getQuestion().trim().isEmpty())
                        QuestionToUpdate.setQuestion(question.getQuestion().trim());

                    if (question.getQuestionType() != null){
                        QuestionType qt = questionTypeRepository.findById(question.getQuestionType().getQuestionTypeId()).get();
                        QuestionToUpdate.setQuestionType(qt);
                    }
                    if (question.getDefaultValue() != null)
                        QuestionToUpdate.setDefaultValue(question.getDefaultValue());

                    if (question.getIsMadatory() != null)
                        QuestionToUpdate.setIsMadatory(question.getIsMadatory());

                    if (question.getDataType() != null)
                        QuestionToUpdate.setDataType(question.getDataType());

                    if (question.getCaptureImgStatus() != null)
                        QuestionToUpdate.setCaptureImgStatus(question.getCaptureImgStatus());

                    if (question.getCaptureImgStatus() != null)
                        QuestionToUpdate.setCaptureImgStatus(question.getCaptureImgStatus());

                    if (question.getIsDerived() != null)
                        QuestionToUpdate.setIsDerived(question.getIsDerived());

                    if (question.getOperands() != null && !question.getOperands().isEmpty())
                        QuestionToUpdate.setOperand(question.getOperands().toString());

                    if (question.getOperator() != null && !question.getOperator().isEmpty()) {
                        if(question.getOperator().size() != question.getOperands().size()-1){
                            result.put("status", 302);
                            result.put("response", "Operators should be one less than operands.");
                            return result;
                        }
                        QuestionToUpdate.setOperator(question.getOperator().toString());
                    }

                     QuestionToUpdate.setLastUpdatedDate(date);
                     questionRepository.save(QuestionToUpdate);
                    Question updated = questionRepository.findById(QuestionToUpdate.getQuestionId()).get();
                    if (updated.getQuestionType().getIsOption()) {
                        List<QuestionTypeOption> qtoList = questionTypeOptionRepository.findByQuestionId(updated.getQuestionId());
                        questionTypeOptionRepository.deleteAll(qtoList);
                        for (String option : question.getQuestionTypeOptionList()) {
                            QuestionTypeOption questionTypeOption = new QuestionTypeOption();
                            questionTypeOption.setOption(option);
                            questionTypeOption.setQuestionId(question.getQuestionId());
                            questionTypeOption.setQuestionType(question.getQuestionType());
                            questionTypeOption.setCreatedBy(1);
                            questionTypeOption.setUpdatedBy(1);
                            questionTypeOption.setCreatedDate(date);
                            questionTypeOption.setLastUpdatedDate(date);
                            questionTypeOptionRepository.save(questionTypeOption);
                        }
                    }
                    result.put("status", 200);
                    result.put("response", "Question Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update Question");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in updateQuestion for Question : {} and exception : {} ", question.toString(), e.getMessage());
            log.trace("Exception in updateQuestion for Question : {} and trace : {} ", question.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findQuestionById(Integer id) {
        log.info(this.getClass().getName() + " :- findQuestionById()");
        JSONObject result = new JSONObject();
        try {
            Question questions = questionRepository.findById(id).get();
            List<Question> toSendQuestionList = new ArrayList<>();
            toSendQuestionList.add(getQuestionWithOption(questions));
            if (toSendQuestionList != null) {
                result.put("status", 200);
                result.put("response", toSendQuestionList);
            } else {
                result.put("status", 302);
                result.put("response", "Question Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findQuestionById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findQuestionById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findAllQuestion() {
        log.info(this.getClass().getName() + " :- findAllQuestion()");
        JSONObject result = new JSONObject();
        try {
            List<Question> questions = questionRepository.findAll();
            List<Question> toSendQuestionList = new ArrayList<>();
            for(Question question:questions){
                toSendQuestionList.add(getQuestionWithOption(question));
            }
            if (toSendQuestionList != null) {
                result.put("status", 200);
                result.put("response", toSendQuestionList);
            } else {
                result.put("status", 302);
                result.put("response", "Question Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllQuestion for id : {} and exception : {} ", e.getMessage());
            log.trace("Exception in findAllQuestion for id : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findQuestionByPageId(Integer pageId) {
        log.info(this.getClass().getName() + " :- findQuestionByPageId()");
        JSONObject result = new JSONObject();
        try {
            Page page = pageRepository.findById(pageId).get();
            List<Question> questionList = questionRepository.findByPage(page);
            List<Question> toSendQuestionList = new ArrayList<>();
            for(Question question:questionList){
              toSendQuestionList.add(getQuestionWithOption(question));
            }
            if (toSendQuestionList != null && !toSendQuestionList.isEmpty()) {
                result.put("status", 200);
                result.put("response", toSendQuestionList);
            } else {
                result.put("status", 302);
                result.put("response", "Question Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findQuestionByPageId for id : {} and exception : {} ", pageId, e.getMessage());
            log.trace("Exception in findQuestionByPageId for id : {} and trace : {} ", pageId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findQuestionByQuestionTypeId(Integer questionTypeId) {
        log.info(this.getClass().getName() + " :- findQuestionByQuestionTypeId()");
        JSONObject result = new JSONObject();
        try {
            List<Question> questions = questionRepository.findByQuestionType(questionTypeId);
            List<Question> toSendQuestionList = new ArrayList<>();
            for(Question question:questions){
                toSendQuestionList.add(getQuestionWithOption(question));
            }
            if (toSendQuestionList != null) {
                result.put("status", 200);
                result.put("response", toSendQuestionList);
            } else {
                result.put("status", 302);
                result.put("response", "Question Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findQuestionByQuestionTypeId for id : {} and exception : {} ", questionTypeId, e.getMessage());
            log.trace("Exception in findQuestionByQuestionTypeId for id : {} and trace : {} ", questionTypeId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject createQuestionWithMultipleOption(QuestionWrapper questionWrapper) {
        log.info(this.getClass().getName() + " :- createQuestionWithMultipleOption() questionWrapper : {} ", questionWrapper.toString());
        JSONObject result = new JSONObject();
        try {
            List<Question> list = questionRepository.findByPageAndQuestionAndQuestionType(questionWrapper.getPage(), questionWrapper.getQuestion(), questionWrapper.getQuestionType());
            if (list != null && !list.isEmpty()) {
                result.put("status", 302);
                result.put("response", "Question already Exist with Question : " + questionWrapper.getQuestion() + " , PageID : " + questionWrapper.getPage().getPageId() + "and Question Type Id" + questionWrapper.getQuestionType().getQuestionTypeId());
            }
            if(questionWrapper.getIsDerived()){
                if(questionWrapper.getOperands() == null || questionWrapper.getOperands().isEmpty()){
                    result.put("status", 302);
                    result.put("response", "Please choose the operands");
                    return result;
                }
                if(questionWrapper.getOperator() == null || questionWrapper.getOperator().isEmpty()){
                    result.put("status", 302);
                    result.put("response", "Please choose the operators");
                    return result;
                }
                if(questionWrapper.getOperator().size() != questionWrapper.getOperands().size()-1){
                    result.put("status", 302);
                    result.put("response", "Operators should be one less than operands.");
                    return result;
                }
            }

            Question duplicateSequence = questionRepository.findByPageAndSequence(questionWrapper.getPage(), questionWrapper.getSequence());
            if (duplicateSequence != null) {
            	result.put("status", 302);
                result.put("response", "Sequence already exist with page");
                return result;
            }
            if (questionWrapper.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                if (questionWrapper.getIsDerived() != null && questionWrapper.getIsDerived()){
                    result.put("status", 302);
                    result.put("response", "Question should not be Derived");
                    return result;
                }
                if (questionWrapper.getIsPrefilled() != null && questionWrapper.getIsPrefilled()){
                    result.put("status", 302);
                    result.put("response", "Question should not be Prefilled");
                    return result;
                }
               /* if (questionWrapper.getParentId() != null){
                    result.put("status", 302);
                    result.put("response", "Question with parent not allowed");
                    return result;
                }
                if (questionWrapper.getInfluenceBy() != null){
                    result.put("status", 302);
                    result.put("response", "Question with Influence not allowed");
                    return result;
                }*/
            }else if(!questionWrapper.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                if (questionWrapper.getIsDerived() != null && questionWrapper.getIsDerived()){
                    List<Question> operandQuestionList = questionRepository.findOperandQuestionQRByList(questionWrapper.getOperands());
                    if (operandQuestionList != null && !operandQuestionList.isEmpty()){
                    result.put("status", 302);
                    result.put("response", "QR question can't be used as Operand");
                    return result;
                    }
                }
              /*  if (questionWrapper.getParentId() != null){
                    Question parent =  questionRepository.findById(questionWrapper.getParentId()).orElse(null);
                    if (parent != null && parent.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                    result.put("status", 302);
                    result.put("response", "QR question can't be used as Parent");
                    return result;
                    }
                }
                if (questionWrapper.getInfluenceBy() != null){
                    Question influence =  questionRepository.findById(questionWrapper.getInfluenceBy()).orElse(null);
                    if (influence != null && influence.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                        result.put("status", 302);
                        result.put("response", "QR question can't be used as Influence");
                        return result;
                    }
                }*/
            }
            Question question = new Question();
                Date date = new Date();
                question.setCreatedBy(1); // todo change when login is implemented
                question.setUpdatedBy(1); // todo change when login is implemented
                question.setCreatedDate(date);
                question.setLastUpdatedDate(date);
                question.setPage(questionWrapper.getPage());
                question.setDataType(questionWrapper.getDataType());
                question.setQuestion(questionWrapper.getQuestion());
                question.setDefaultValue(questionWrapper.getDefaultValue());
                question.setQuestionType(questionWrapper.getQuestionType());
                //question.setIsMadatory(questionWrapper.getIsMadatory());
                question.setSequence(questionWrapper.getSequence());
                //question.setCaptureImgStatus(questionWrapper.getCaptureImgStatus());
                question.setParentId(questionWrapper.getParentId());
                question.setInfluenceBy(questionWrapper.getInfluenceBy());
                question.setInfluencerResponseValue(questionWrapper.getInfluencerResponseValue());
                question.setIsPrefilled(questionWrapper.getIsPrefilled());
                question.setPrefilledBy(questionWrapper.getPrefilledBy());
                question.setIsDerived(questionWrapper.getIsDerived());
                question.setIsYesNo(questionWrapper.getIsYesNo());

                if(questionWrapper.getQuestionType().getQuestionType().equalsIgnoreCase("signature")){
                	question.setCaptureImgStatus(2);
                	question.setIsMadatory(true);
                } else {
                	if (questionWrapper.getCaptureImgStatus() != null) {
                		log.debug(this.getClass().getName() + " :- createQuestionWithMultipleOption() captureImgStatus request value : {} ", questionWrapper.getCaptureImgStatus());
                		question.setCaptureImgStatus(questionWrapper.getCaptureImgStatus());
                	}
                	if(questionWrapper.getIsMadatory() != null ) {
                		question.setIsMadatory(questionWrapper.getIsMadatory());
                    }
                }
                if (questionWrapper.getIsDerived()) {
                	String operandList = questionWrapper.getOperands().stream().map(String::valueOf).collect(Collectors.joining(","));
                    question.setOperand(operandList);
                    String operatorList = questionWrapper.getOperator().stream().map(String::valueOf).collect(Collectors.joining(","));
                    question.setOperator(operatorList);
                }
                log.debug(this.getClass().getName() + " :- createQuestionWithMultipleOption() question save : {} ", question.toString());
                Question createdQuestion = questionRepository.save(question);

                // task create question type option
                if (question.getQuestionType().getIsOption()) {
                    for (String option : questionWrapper.getQuestionTypeOptionList()) {
                        QuestionTypeOption questionTypeOption = new QuestionTypeOption();
                        questionTypeOption.setOption(option);
                        questionTypeOption.setQuestionId(createdQuestion.getQuestionId());
                        questionTypeOption.setQuestionType(createdQuestion.getQuestionType());
                        questionTypeOption.setCreatedBy(1);
                        questionTypeOption.setUpdatedBy(1);
                        questionTypeOption.setCreatedDate(date);
                        questionTypeOption.setLastUpdatedDate(date);
                        questionTypeOptionRepository.save(questionTypeOption);
                    }
                }
                if (createdQuestion != null) {
                    result.put("status", 200);
                    result.put("response", "Question Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add Question");
                }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in createQuestionWithMultipleOption for Question : {} and exception : {} ", questionWrapper.toString(), e.getMessage());
            log.trace("Exception in createQuestionWithMultipleOption for Question : {} and trace : {} ", questionWrapper.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;

    }

    public JSONObject updateQuestionWithMultipleOption(QuestionWrapper questionWrapper) {
        log.info(this.getClass().getName() + " :- updateQuestionWithMultipleOption()");
        JSONObject result = new JSONObject();
        try {
            List<Question> list = questionRepository.findByPageAndQuestionAndQuestionType(questionWrapper.getPage(), questionWrapper.getQuestion(), questionWrapper.getQuestionType());
            if (list != null && !list.isEmpty()) {
                result.put("status", 302);
                result.put("response", "Question already Exist with Question : " + questionWrapper.getQuestion() + " , PageID : " + questionWrapper.getPage().getPageId() + "and Question Type Id" + questionWrapper.getQuestionType().getQuestionTypeId());
            }
            if(questionWrapper.getIsDerived()){
                if(questionWrapper.getOperands() == null || questionWrapper.getOperands().isEmpty()){
                    result.put("status", 302);
                    result.put("response", "Please choose the operands");
                    return result;
                }
                if(questionWrapper.getOperator() == null || questionWrapper.getOperator().isEmpty()){
                    result.put("status", 302);
                    result.put("response", "Please choose the operators");
                    return result;
                }
                if(questionWrapper.getOperator().size() != questionWrapper.getOperands().size()-1){
                    result.put("status", 302);
                    result.put("response", "Operators should be one less than operands.");
                    return result;
                }
            }

            Question duplicateSequence = questionRepository.findByPageAndSequence(questionWrapper.getPage(), questionWrapper.getSequence());
            if (duplicateSequence != null && !questionWrapper.getQuestionId().equals(duplicateSequence.getQuestionId())) {
            	result.put("status", 302);
                result.put("response", "Sequence already exist with page");
                return result;
            }

            if (questionWrapper.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                if (questionWrapper.getIsDerived() != null && questionWrapper.getIsDerived()){
                    result.put("status", 302);
                    result.put("response", "Question should not be Derived");
                    return result;
                }
                if (questionWrapper.getIsPrefilled() != null && questionWrapper.getIsPrefilled()){
                    result.put("status", 302);
                    result.put("response", "Question should not be Prefilled");
                    return result;
                }
               /* if (questionWrapper.getParentId() != null){
                    result.put("status", 302);
                    result.put("response", "Question with parent not allowed");
                    return result;
                }
                if (questionWrapper.getInfluenceBy() != null){
                    result.put("status", 302);
                    result.put("response", "Question with Influence not allowed");
                    return result;
                }*/
            }else if(!questionWrapper.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                if (questionWrapper.getIsDerived() != null && questionWrapper.getIsDerived()){
                    List<Question> operandQuestionList = questionRepository.findOperandQuestionQRByList(questionWrapper.getOperands());
                    if (operandQuestionList != null && !operandQuestionList.isEmpty()){
                        result.put("status", 302);
                        result.put("response", "QR question can't be used as Operand");
                        return result;
                    }
                }
               /* if (questionWrapper.getParentId() != null){
                    Question parent =  questionRepository.findById(questionWrapper.getParentId()).orElse(null);
                    if (parent != null && parent.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                        result.put("status", 302);
                        result.put("response", "QR question can't be used as Parent");
                        return result;
                    }
                }
                if (questionWrapper.getInfluenceBy() != null){
                    Question influence =  questionRepository.findById(questionWrapper.getInfluenceBy()).orElse(null);
                    if (influence != null && influence.getQuestionType().getQuestionType().equalsIgnoreCase("QR")){
                        result.put("status", 302);
                        result.put("response", "QR question can't be used as Influence");
                        return result;
                    }
                }*/
            }

                Question QuestionToUpdate = questionRepository.findById(questionWrapper.getQuestionId()).get();
                if (QuestionToUpdate != null) {
                    if (questionWrapper.getQuestion() != null && !questionWrapper.getQuestion().trim().isEmpty()) {
                        QuestionToUpdate.setQuestion(questionWrapper.getQuestion().trim());
                    }
                    if (questionWrapper.getPage() != null) {
                        QuestionToUpdate.setPage(questionWrapper.getPage());
                    }
                    if (questionWrapper.getQuestionType() != null) {
                        QuestionToUpdate.setQuestionType(questionWrapper.getQuestionType());
                    }
                    if (questionWrapper.getDefaultValue() != null) {
                        QuestionToUpdate.setDefaultValue(questionWrapper.getDefaultValue());
                    }
                    if (questionWrapper.getDataType() != null) {
                        QuestionToUpdate.setDataType(questionWrapper.getDataType());
                    }
                    if (questionWrapper.getSequence() != null) {
                        QuestionToUpdate.setSequence(questionWrapper.getSequence());
                    }
                    if (questionWrapper.getParentId() != null) {
                        QuestionToUpdate.setParentId(questionWrapper.getParentId());
                    }
//                    if (questionWrapper.getInfluenceBy() != null) {
                        QuestionToUpdate.setInfluenceBy(questionWrapper.getInfluenceBy());
//                    }
//                    if (questionWrapper.getInfluencerResponseValue() != null) {
                        QuestionToUpdate.setInfluencerResponseValue(questionWrapper.getInfluencerResponseValue());
//                    }
//                    if (questionWrapper.getIsPrefilled() != null) {
                        QuestionToUpdate.setIsPrefilled(questionWrapper.getIsPrefilled());
//                    }
//                    if (questionWrapper.getPrefilledBy() != null) {
                        QuestionToUpdate.setPrefilledBy(questionWrapper.getPrefilledBy());
//                    }

//                    if (questionWrapper.getIsDerived() != null) {
                        QuestionToUpdate.setIsDerived(questionWrapper.getIsDerived());
//                    }
                    if(questionWrapper.getQuestionType().getQuestionType().equalsIgnoreCase("signature")){
                    	QuestionToUpdate.setCaptureImgStatus(2);
                    	QuestionToUpdate.setIsMadatory(true);
                    } else {
                    	if (questionWrapper.getCaptureImgStatus() != null) {
                    		QuestionToUpdate.setCaptureImgStatus(questionWrapper.getCaptureImgStatus());
                    	} else {
                    		QuestionToUpdate.setCaptureImgStatus(0);
                    	}
                    	if(questionWrapper.getIsMadatory() != null ){
                    		QuestionToUpdate.setIsMadatory(questionWrapper.getIsMadatory());
                        }
                    }

                    if (questionWrapper.getIsDerived()) {
                    	if (questionWrapper.getOperands() != null) {
                    		String operandList = questionWrapper.getOperands().stream().map(String::valueOf).collect(Collectors.joining(","));
                        	QuestionToUpdate.setOperand(operandList);
                        }
                    	if (questionWrapper.getOperator() != null) {
                    		String operatorList = questionWrapper.getOperator().stream().map(String::valueOf).collect(Collectors.joining(","));
                            QuestionToUpdate.setOperator(operatorList);
                        }

                    } else {
                    	QuestionToUpdate.setOperand(null);
                    	QuestionToUpdate.setOperator(null);
                    }
                    if(questionWrapper.getIsYesNo() != null) {
                    	QuestionToUpdate.setIsYesNo(questionWrapper.getIsYesNo());
                    }

                    QuestionToUpdate.setLastUpdatedDate(new Date());
                    System.out.println("QuestionToUpdate() : "+QuestionToUpdate.toString());
                    questionRepository.save(QuestionToUpdate);
                    result.put("status", 200);
                    result.put("response", "Question Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update Question");
                }
        }catch(Exception e) {
                log.error("Exception in updateQuestionWithMultipleOption for Question : {} and exception : {} ", questionWrapper.toString(), e.getMessage());
            log.trace("Exception in updateQuestionWithMultipleOption for Question : {} and trace : {} ", questionWrapper.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;

    }

    public Question getQuestionWithOption(Question question){
        List<QuestionTypeOption> questionTypeOptions = questionTypeOptionRepository.findByQuestionId(question.getQuestionId());
        question.setQuestionTypeOptionList(questionTypeOptions);
        return question;
    }


    public JSONObject findQuestionByPageIdV2(Integer pageId) {
        JSONObject result = new JSONObject();
        try{
            List<Object[]> list = questionRepository.getQuestionByPageId(pageId);
            JSONArray array = new JSONArray();
            if (list != null && list.size() > 0){
                for (Object[] obj : list){
                    JSONObject temp = new JSONObject();
                    temp.put("questionId", obj[0]);
                    temp.put("pageName", obj[1]);
                    temp.put("question", obj[2]);
                    temp.put("questionType", obj[3]);
                    temp.put("defaultValue", obj[4]);
                    temp.put("isMandatory", obj[5]);
                    temp.put("dataType", obj[6]);
                    temp.put("captureImageStatus", obj[7]);
                    temp.put("sequence", obj[8]);
                    temp.put("parent", obj[9]);
                    temp.put("influencer", obj[10]);
                    temp.put("influencerResponseValue", obj[11]);
                    temp.put("isPrefilled", obj[12]);
                    temp.put("prefilledBy", obj[13]);
                    temp.put("parentId", obj[14]);
                    temp.put("influencerId", obj[15]);
                    temp.put("questionTypeId", obj[16]);
                    temp.put("isDerived", obj[17]);
                    temp.put("operator", obj[18]);
                    temp.put("operand", obj[19]);
                    temp.put("operandName", obj[20]);
                    temp.put("isYesNo", obj[21]);
                    List<QuestionTypeOption> questionTypeOptionList = questionTypeOptionRepository.findByQuestionId(Integer.parseInt(String.valueOf(obj[0])));
                    temp.put("questionTypeOptionList", questionTypeOptionList);
                    array.add(temp);
                }
                result.put("status", 200);
                result.put("response", array);
            }else {
                result.put("status", 302);
                result.put("response", "No Questions Found");
            }
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
}
