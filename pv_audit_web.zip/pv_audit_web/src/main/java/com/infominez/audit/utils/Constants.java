package com.infominez.audit.utils;

public interface Constants {
//        public String imagesDir="C:\\AUDIT\\images\\";
    public String imagesDir = "/home/imz/AUDIT/images/";
    public String excelDir = "/home/imz/AUDIT/excel/";
    // WLA
//    public String imagesDir = "/AUDIT_WLA/images/";
//    public String excelDir = "/AUDIT_WLA/excel/";
//    public String imagesDir = "/var/www/html/miramus/assets/images/";

}
