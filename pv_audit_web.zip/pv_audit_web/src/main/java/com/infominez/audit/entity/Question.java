package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.infominez.audit.utils.EnumUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "question" )
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = false)
@Proxy(lazy = false)
public class Question implements Serializable {
    private static final Long serialVersionUID = 1L;


    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "question_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer questionId;

    @JoinColumn(name = "page_id")
    @ManyToOne(fetch = FetchType.LAZY)
    @Basic(optional = false)
    private Page page;

    @Basic(optional = false)
    @Column(name = "question")
    private String question;

    @JoinColumn(name = "question_type_id")
    @ManyToOne(fetch = FetchType.LAZY)
    @Basic(optional = false)
    private QuestionType questionType;

    @Basic(optional = false)
    @Column(name = "default_value")
    private String defaultValue;

    @JsonIgnore
    @Column(name = "created_by")
    private Integer createdBy;

    @JsonIgnore
    @Column(name = "updated_by")
    private Integer updatedBy;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "last_updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDate;

    @Basic(optional = false)
    @Column(name = "is_mandatory")
    private Boolean isMadatory;

    @Basic(optional = false)
    @Column(name = "datatype")
    private String dataType;

    @Basic(optional = false)
    @Column(name = "capture_img_status")
    private Integer captureImgStatus;

    @Basic(optional = false)
    @Column(name = "sequence")
    private Integer sequence;

    @Column(name = "parent_id")
    private Integer parentId;

    @Column(name = "influence_by")
    private Integer influenceBy;

    @Column(name = "influencer_response_value")
    private String influencerResponseValue;

    @Column(name = "is_prefilled")
    private Boolean isPrefilled;

    @Column(name = "prefilled_by")
    private String prefilledBy;

    @Column(name = "is_derived")
    private Boolean isDerived;

    @Column(name = "is_yes_no")
    private Boolean isYesNo;

    @Column(name = "operand")
    private String operand;

    @Column(name = "operator")
    private String operator;

    @Transient
    private List<QuestionTypeOption> questionTypeOptionList;

    @Transient
    @JsonIgnore
    public Question getClassObject(){
        return this;
    }

}
