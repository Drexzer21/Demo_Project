package com.infominez.audit.wrapper;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.infominez.audit.entity.Question;
import com.infominez.audit.entity.Ticket;
import lombok.Data;
import lombok.NonNull;
import lombok.ToString;

import javax.persistence.Transient;

@Data
@ToString(of = {"ticketResponseId", "ticket", "question", "response", "sequence", "latitude", "longitude"})
public class TicketResponseWrapper {
    private Integer ticketResponseId;
    @NonNull
    private Ticket ticket;
    @NonNull
    private Question question;
    @NonNull
    private String response;

    private String base64Image;
    @NonNull
    private Integer sequence;
    private Double latitude;
    private Double longitude;
    private String qrString;
    private Boolean isCorrect;
    private String remark;

    @Transient
    @JsonIgnore
    public TicketResponseWrapper getClassObject(){
        return this;
    }

    @Transient
    @JsonIgnore
    public String key(){
        return String.valueOf(ticket.getTicketId() + "" + question.getQuestionId() + "" + sequence);
    }
}
