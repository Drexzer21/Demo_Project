package com.infominez.audit.repo;

import com.infominez.audit.entity.QuestionType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuestionTypeRepository extends JpaRepository<QuestionType,Integer> {
    List<QuestionType> findByQuestionType(String questionType);
}
