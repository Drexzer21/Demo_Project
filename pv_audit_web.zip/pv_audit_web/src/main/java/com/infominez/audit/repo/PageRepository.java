package com.infominez.audit.repo;

import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.Template;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PageRepository extends JpaRepository<Page,Integer> {
    List<Page> findByTemplate(Template template);

    List<Page> findByPageNameAndTemplate(String pageName, Template template);
    
    Page findByTemplateAndSequence(Template template, Integer sequence);
}
