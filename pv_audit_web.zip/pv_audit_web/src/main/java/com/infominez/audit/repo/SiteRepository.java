package com.infominez.audit.repo;

import com.infominez.audit.entity.Site;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SiteRepository extends JpaRepository<Site, Integer> {

    @Query(value = "select distinct(state) from site",
            nativeQuery = true)
    List<Object> getAllState();

    @Query(value = "select distinct(city) from site",
            nativeQuery = true)
    List<Object> getAllCity();

    @Query("SELECT s from Site s where (s.state =:state OR :state IS NULL) AND (s.city =:city OR :city IS NULL)")
    List<Site> findByStateAndCity(String state, String city);

    List<Site> findByStateOrCity(String state, String city);

    List<Site> findBySiteName(String siteName);

    Site findBySiteCode(String siteCode);

    @Query(value="select * from site where site_id not in ( " +
            "select distinct(st.site_id) from schedule_site st  " +
            "inner join user_audit_schedule uas on uas.user_audit_schedule_id = st.user_audit_schedule_id " +
            "where uas.template_id = :templateId " +
            "and uas.user_id = :userId " +
            ") " +
            "and state = ifnull(:state, state) " +
            "and city = ifnull(:city ,city )  ",nativeQuery = true)
    List<Site> getSiteWithFiltersForSchedule(Integer templateId, Integer userId, String state, String city);
}
