package com.infominez.audit.service;

import com.infominez.audit.entity.*;
import com.infominez.audit.repo.QuestionRepository;
import com.infominez.audit.repo.TicketRepository;
import com.infominez.audit.repo.TicketResponseRepository;

import com.infominez.audit.utils.ExcelUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class  TicketResponseService {

    private final TicketResponseRepository ticketResponseRepository;
    private final TicketRepository ticketRepository;
    private final QuestionRepository questionRepository;

    public JSONObject createTicketResponse(TicketResponse ticketResponse) {
        log.info(this.getClass().getName() + " :- createTicketResponse()");
        JSONObject result = new JSONObject();
        try {
            List<TicketResponse> list = ticketResponseRepository.findByResponseAndTicketAndQuestion(ticketResponse.getResponse(), ticketResponse.getTicket(), ticketResponse.getQuestion());
            if (list != null && !list.isEmpty() && ticketResponse.getTicketResponseId() != list.get(0).getTicketResponseId()) {
                result.put("status", 302);
                result.put("response", "TicketResponse already Exist with Response : " + ticketResponse.getResponse() + " and TicketId : " + ticketResponse.getTicket() + "And QuestionId" + ticketResponse.getQuestion());
            } else {
                Date date = new Date();
                ticketResponse.setCreatedBy(1); // todo change when login is implemented
                ticketResponse.setUpdatedBy(1); // todo change when login is implemented
                ticketResponse.setCreatedDate(date);
                ticketResponse.setLastUpdatedDate(date);
                TicketResponse createdTicketResponse = ticketResponseRepository.save(ticketResponse);
                if (createdTicketResponse != null) {
                    result.put("status", 200);
                    result.put("response", "TicketResponse Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add TicketResponse");
                }
            }
        } catch (Exception e) {

            log.error("Exception in createTicketResponse for TicketResponse : {} and exception : {} ", ticketResponse.toString(), e.getMessage());
            log.trace("Exception in createTicketResponse for TicketResponse : {} and trace : {} ", ticketResponse.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject updateTicketResponse(TicketResponse ticketResponse) {
        log.info(this.getClass().getName() + " :- updateTicketResponseResponse()");
        JSONObject result = new JSONObject();
        try {
            List<TicketResponse> list = ticketResponseRepository.findByResponseAndTicketAndQuestion(ticketResponse.getResponse(), ticketResponse.getTicket(), ticketResponse.getQuestion());
            if (list != null && !list.isEmpty() && ticketResponse.getTicketResponseId() != list.get(0).getTicketResponseId()) {
                result.put("status", 302);
                result.put("response", "TicketResponse already Exist with Response : " + ticketResponse.getResponse() + " and TicketId : " + ticketResponse.getTicket() + "And QuestionId" + ticketResponse.getQuestion());
            } else {
                TicketResponse ticketResponseToUpdate = ticketResponseRepository.findById(ticketResponse.getTicketResponseId()).get();
                if (ticketResponseToUpdate != null) {
                    if (ticketResponse.getTicket() != null) {
                        ticketResponseToUpdate.setTicket(ticketResponse.getTicket());
                    }
                    if (ticketResponse.getImagePath() != null) {
                        ticketResponseToUpdate.setImagePath(ticketResponse.getImagePath());
                    }

                    ticketResponseToUpdate.setLastUpdatedDate(new Date());
                    ticketResponseRepository.save(ticketResponseToUpdate);
                    result.put("status", 200);
                    result.put("response", "TicketResponse Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update TicketResponse");
                }
            }
        } catch (Exception e) {

            log.error("Exception in updateTicketResponse for TicketResponse  : {} and exception : {} ", ticketResponse.toString(), e.getMessage());
            log.trace("Exception in updateTicketResponse for TicketResponse  : {} and trace : {} ", ticketResponse.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findTicketResponseById(Integer id) {
        log.info(this.getClass().getName() + " :- findTicketResponseById()");
        JSONObject result = new JSONObject();
        try {
            TicketResponse ticketResponse = ticketResponseRepository.findById(id).get();
            if (ticketResponse != null) {
                result.put("status", 200);
                result.put("response", ticketResponse);
            } else {
                result.put("status", 302);
                result.put("response", "TicketResponse Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTicketResponseById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findTicketResponseById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllTicketResponse() {
        log.info(this.getClass().getName() + " :- findAllTicketResponse()");
        JSONObject result = new JSONObject();
        try {
            List<TicketResponse> ticketResponses = ticketResponseRepository.findAll();
            if (ticketResponses != null) {
                result.put("status", 200);
                result.put("response", ticketResponses);
            } else {
                result.put("status", 302);
                result.put("response", "TicketResponse Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllTicketResponse  : {} and exception : {} ", e.getMessage());
            log.trace("Exception in findAllTicketResponse  : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findTicketResponseByTicketId(Integer ticketid) {
        log.info(this.getClass().getName() + " :- findTicketResponseByTicketId()");
        JSONObject result = new JSONObject();
        try {
            List<TicketResponse> ticketResponse = ticketResponseRepository.findByTicketId(ticketid);
            if (ticketResponse != null) {
                result.put("status", 200);
                result.put("response", ticketResponse);

            } else {
                result.put("status", 302);
                result.put("response", "TicketResponse Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTicketResponseByTicketId for ticketid : {} and exception : {} ", ticketid, e.getMessage());
            log.trace("Exception in findTicketResponseByTicketId for ticketid : {} and trace : {} ", ticketid, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findTicketResponseByQuestionId(Integer questionid) {
        log.info(this.getClass().getName() + " :- findTicketResponseByQuestionId()");
        JSONObject result = new JSONObject();
        try {
            Question question = questionRepository.findById(questionid).get();
            List<TicketResponse> ticketResponse = ticketResponseRepository.findByQuestion(question);
            if (ticketResponse != null) {
                result.put("status", 200);
                result.put("response", ticketResponse);
            } else {
                result.put("status", 302);
                result.put("response", "TicketResponse Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTicketResponseByQuestionId for questionid : {} and exception : {} ", questionid, e.getMessage());
            log.trace("Exception in findTicketResponseByQuestionId for questionid : {} and trace : {} ", questionid, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject createMultipleTicketResponse(List<TicketResponse> ticketResponseList) {
        log.info(this.getClass().getName() + " :- createMultipleTicketResponse()");
        JSONObject result = new JSONObject();
        try {

            for (TicketResponse ticketResponse : ticketResponseList) {
                List<TicketResponse> list = ticketResponseRepository.findByResponseAndTicketAndQuestion(ticketResponse.getResponse(), ticketResponse.getTicket(), ticketResponse.getQuestion());
                if (list != null && !list.isEmpty() && ticketResponse.getTicketResponseId() != list.get(0).getTicketResponseId()) {
                    result.put("status", 302);
                    result.put("response", "TicketResponse already Exist with Response : " + ticketResponse.getResponse() + " and TicketId : " + ticketResponse.getTicket() + "And QuestionId" + ticketResponse.getQuestion());
                } else {
                    Date date = new Date();
                    ticketResponse.setCreatedBy(1); // todo change when login is implemented
                    ticketResponse.setUpdatedBy(1); // todo change when login is implemented
                    ticketResponse.setCreatedDate(date);
                    ticketResponse.setLastUpdatedDate(date);

                    TicketResponse createdTicketResponse = ticketResponseRepository.save(ticketResponse);
                    if (createdTicketResponse != null) {
                        result.put("status", 200);
                        result.put("response", "TicketResponse Added Successfully");
                    } else {
                        result.put("status", 302);
                        result.put("response", "Unable to add TicketResponse");
                    }
                }
            }
        } catch (Exception e) {

            log.error("Exception in createMultipleTicketResponse for TicketResponse : {} and exception : {} ", ticketResponseList.toString(), e.getMessage());
            log.trace("Exception in createMultipleTicketResponse for TicketResponse : {} and trace : {} ", ticketResponseList.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject file(MultipartFile file, String path, String fileName) {
        JSONObject jsonObject = new JSONObject();

        try {

           /* File file = new File(path);
            if (file.exists()){
                File fileToCreate = new File(path + "\\" + fileName );
                result = fileToCreate.createNewFile();  //creates a new file
            }else if (file.mkdir()){
                File fileToCreate = new File(path + "\\" + fileName );
                result = fileToCreate.createNewFile();  //creates a new file
            }
            Files.copy(files.getInputStream(), Paths.get(path), StandardCopyOption.REPLACE_EXISTING);*/
            File directory = new File(path);
            if (!directory.exists()) {
                directory.mkdirs();
            }
            path = path + "\\"+ fileName;
            // Copies Spring's file inputStream to (absolute path)
            Files.copy(file.getInputStream(), Paths.get(path), StandardCopyOption.REPLACE_EXISTING);


                jsonObject.put("status", 200);
                jsonObject.put("response", "file created " + path);

        } catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");   //prints exception if any
        }


        return jsonObject;

    }

    public JSONObject getResponseByTicketId(Integer ticketId ) {
        log.info(this.getClass().getName() + " :- getResponseByTicketId()");
        JSONObject result = new JSONObject();
        try {
            List<JSONObject> ticketResponse = getTicketResponseJSON(ticketId);
            if (ticketResponse != null) {
                List<JSONObject> list = new ArrayList<>();
                Map<String, List<JSONObject>> ticketResponseMap =
                        ticketResponse.stream().collect(Collectors.groupingBy(object -> String.valueOf(object.get("page_name")))).entrySet()
                                .stream().filter(entry -> entry.getValue().size() > 0)
                                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                ticketResponseMap.forEach((s, objects) -> {
                            JSONObject tempObj = new JSONObject();
                            objects.sort((m1, m2) -> {
                                if(Integer.parseInt(String.valueOf(m1.get("sequence"))) == Integer.parseInt(String.valueOf(m2.get("sequence")))){
                                    return 0;
                                }
                                if(Integer.parseInt(String.valueOf(m1.get("sequence"))) > Integer.parseInt(String.valueOf(m2.get("sequence")))){
                                    return 1;
                                }else{
                                    return -1;
                                }
//                                return m1.get("sequence") ? -1 : 1;
                            });
                            tempObj.put("page",s);
                            tempObj.put("pageSequence",objects.get(0).get("pageSequence"));
                            tempObj.put("questionResponses", objects);
                            list.add(tempObj);
                        }
                        );
                list.sort((m1, m2) -> {
                    if(Integer.parseInt(String.valueOf(m1.get("pageSequence"))) == Integer.parseInt(String.valueOf(m2.get("pageSequence")))){
                        return 0;
                    }
                    if(Integer.parseInt(String.valueOf(m1.get("pageSequence"))) > Integer.parseInt(String.valueOf(m2.get("pageSequence")))){
                        return 1;
                    }else{
                        return -1;
                    }
//                                return m1.get("sequence") ? -1 : 1;
                });
                result.put("status", 200);
                result.put("response", list);
                List<Object[]> counts = ticketResponseRepository.getCountByTicketId(ticketId);
                result.put("done", counts != null ? counts.get(0)[0] : 0);
                result.put("pending", counts != null ? counts.get(0)[1] : 0);
                result.put("total", counts != null ? counts.get(0)[2] : 0);
            } else {
                result.put("status", 302);
                result.put("response", "TicketResponse Not found");
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in getResponseByTicketId for ticketid : {} and exception : {} ", ticketId, e.getMessage());
            log.trace("Exception in getResponseByTicketId for ticketid : {} and trace : {} ", ticketId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private List<JSONObject> getTicketResponseJSON(Integer ticketId) {
        try{
            List<JSONObject> result = new ArrayList<>();
            List<Object[]> list = ticketResponseRepository.getTicketResponseByTicketId(ticketId);
            if (list != null){
                list.forEach(object -> {
                    JSONObject response = new JSONObject();
                    response.put("ticket_id", object[0]);
                    response.put("ticket_response_id", object[1]);
                    response.put("question", object[2]);
                    response.put("page_name", object[3]);
                    response.put("template_name", object[4]);
                    response.put("response", object[5]);
                    response.put("image_path", object[6]);
                    response.put("created_date", object[7]);
                    response.put("last_updated_date", object[8]);
                    response.put("sequence", object[9]);
                    response.put("question_id", object[10]);
                    response.put("parent_id", object[11]);
                    response.put("key", object[12]);
                    response.put("parent", object[13]);
                    response.put("pageSequence", object[14]);
                    response.put("questionLatitude", object[15]);
                    response.put("questionLongitude", object[16]);
                   response.put("siteLatitude", object[17]);
                  response.put("siteLongitude", object[18]);
                  response.put("qr_string", object[19]);
                  response.put("is_correct", object[20]);
                  response.put("remark", object[21]);

                    result.add(response);
                });
                return result;
            }else{
                return null;
            }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    public static String getStringFromString(String s){
        if (s != null){
            if (s.trim().length()>0){
                return s.trim();
            }else{
                return null;
            }
        }else{
            return null;
        }
    }


    public ByteArrayInputStream downloadAuditResponseReport(Integer auditId,String fromDate,String toDate) {

            log.info(" writing downloadAuditResponseReport excel");

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try (SXSSFWorkbook workbook = new SXSSFWorkbook()) {
            Sheet summary = workbook.createSheet("Summary");
            Sheet data = workbook.createSheet("Data");


            ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Page Name", "Question",
                    "Response", "Sequence", "Site_Code", "Site_Address", "Ticket_Id"," Is_Location_Incorrect"));
            CellStyle cellStyle = ExcelUtils.createCellStyle(data, 0);
            ExcelUtils.createAndWriteRowWithColor(data, headerList, 0, cellStyle, true, workbook,
                    IndexedColors.BLACK.getIndex(), IndexedColors.WHITE.getIndex());

          String FromDate = getStringFromString(fromDate);
           String  ToDate = getStringFromString(toDate);
            List<Object[]> datas = ticketResponseRepository.callTicketResponseDistanceDiffData(auditId,FromDate, ToDate);

            int rowCount = 1;
            try {
                cellStyle = ExcelUtils.createCellStyle(data, ++rowCount);
                for (Object[] object : datas) {
                    ArrayList<String> rowData = new ArrayList<>();
                    rowData.add(object[0] + "");
                    rowData.add(object[1] + "");
                    rowData.add(object[2] + "");
                    rowData.add(object[3] + "");
                    rowData.add(object[4] + "");
                    rowData.add(object[5] + "");
                    rowData.add(object[6] + "");
                    rowData.add(object[7] + "");

                    ExcelUtils.createAndWriteRow(data, rowData, rowCount++, cellStyle, false, null);
                }
            } catch (Exception e) {
                log.error("Exception in writing Data sheet ", e);
                return null;
            }

            // Create Summary sheet code

            ExcelUtils.createHeaderWithColor(workbook, summary, "Audit Response Distance Difference Report" ,0, 0, 0, 5
                    , 0,
                    IndexedColors.BLACK.getIndex(), IndexedColors.WHITE.getIndex());


            ArrayList<String> headerLists = new ArrayList<>(Arrays.asList("Ticket_Id", "Site_Code",
                        "Updated Date", "Correct Location", "Incorrect Location", "Total"));
                CellStyle cellStyles = ExcelUtils.createCellStyle(summary, 1);
                ExcelUtils.createAndWriteRowWithColor(summary, headerLists, 1, cellStyles, true, workbook,
                        IndexedColors.BLACK.getIndex(), IndexedColors.WHITE.getIndex());

                String FromDates = getStringFromString(fromDate);
                String  ToDates = getStringFromString(toDate);
                List<Object[]> summaryReport = ticketResponseRepository.callTicketResponseDistanceDiffSummary(auditId,FromDates,
                        ToDates);

                int rowCounts = 1;
                try {
                    cellStyles = ExcelUtils.createCellStyle(summary, ++rowCounts);
                    for (Object[] object : summaryReport) {
                        ArrayList<String> rowData = new ArrayList<>();
                        rowData.add(object[0] + "");
                        rowData.add(object[1] + "");
                        rowData.add(object[2] + "");
                        rowData.add(object[3] + "");
                        rowData.add(object[4] + "");
                        rowData.add(object[5] + "");
                        ExcelUtils.createAndWriteRow(summary, rowData, rowCounts++, cellStyles, false, null);
                    }

            } catch (Exception e) {
                log.error("Exception in writing Summary sheet ", e);
                return null;
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing downloadAuditResponseReport excel ", e);
            return null;
        }
    }
}



