package com.infominez.audit.repo;

import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.PageImageResponse;
import com.infominez.audit.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PageImageResponseRepository extends JpaRepository<PageImageResponse,Integer> {

    List<PageImageResponse> findByTicket(Ticket ticket);

    List<PageImageResponse> findByPage(Page page);

    List<PageImageResponse> findByTicketAndPage(Ticket ticket,Page page);
}
