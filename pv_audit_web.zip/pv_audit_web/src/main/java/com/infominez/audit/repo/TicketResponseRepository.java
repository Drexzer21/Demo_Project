package com.infominez.audit.repo;

import com.infominez.audit.entity.Question;
import com.infominez.audit.entity.Ticket;
import com.infominez.audit.entity.TicketResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface TicketResponseRepository extends JpaRepository<TicketResponse, Integer> {

    @Query(value = "select tr from TicketResponse tr where tr.ticket.ticketId = :ticketId",
            nativeQuery =
                    false)
    List<TicketResponse> findByTicketId(Integer ticketId);
    List<TicketResponse> findByQuestion(Question question);
    List<TicketResponse> findByQuestionAndTicket(Question question,Ticket ticket);
    List<TicketResponse> findByResponseAndTicketAndQuestion(String response,Ticket ticket,Question question);

    @Query(value="select * from ticket_response  where ticket_id IN(:ticketId);",nativeQuery=true)
    List<TicketResponse> findByTicketIds(Integer ticketId);


    @Query(value = "select tr.* from ticket_response tr " +
            "left join question q on tr.question_id = q.question_id " +
            "left join page p on q.page_id = p.page_id " +
            "where ticket_id = ? and p.page_id = ?;",
            nativeQuery = true)
    List<Object[]> getTicketResponseByTicketIdAndPageId(Integer ticketId, Integer pageId);


    @Query(value = "select tr.ticket_id, tr.ticket_response_id, q.question,  " +
            "p.page_name, t.template_name, tr.response, tr.image_path,  " +
            "tr.created_date, tr.last_updated_date, tr.sequence , q.question_id, q.parent_id, " +
            " concat(q.question_id,'_', tr.sequence) as _key, " +
            " concat(q.parent_id,'_0' ) as _parent ," +
            " p.sequence as page_sequence , tr.latitude, tr.longitude, " +
            " s.latitude as s_latitude,  s.longitude as s_longitude , qr_string, is_correct, remark " +
            "from ticket_response tr  " +
            "left join question q on tr.question_id = q.question_id  " +
            "left join page p on q.page_id = p.page_id  " +
            "left join ticket tt on tr.ticket_id =tt.ticket_id "+
            "left join template t on p.template_id = t.template_id  " +
            "left join site s on tt.site_id = s.site_id  " +

            "where tt.ticket_id = ?;",
            nativeQuery = true)
    List<Object[]> getTicketResponseByTicketId(Integer ticketId);

    @Query(value = "call GetCountByTicketId(?)",
            nativeQuery = true)
    List<Object[]> getCountByTicketId(Integer ticketid);

    @Query(value = "select tr from TicketResponse  tr where tr.ticket.ticketId in (:ticketIds)",
            nativeQuery =
                    false)
    List<TicketResponse> findByTicketIds(@Param("ticketIds") List<Integer> ticketIds);

    @Query(value = "call IsPageAnswered(?,?)",
            nativeQuery = true)
    Object IsPageAnswered(Integer ticketid, Integer pageId);

    @Query(value = "call TicketResponseDistanceDiffData(?,?,?)",
            nativeQuery = true)
    List<Object[]> callTicketResponseDistanceDiffData(Integer auditId,String fromDate,String toDate);

    @Query(value = "call ticketResponseDistanceDiffSummary(?,?,?)",
            nativeQuery = true)
    List<Object[]> callTicketResponseDistanceDiffSummary(Integer auditId,String fromDate,String toDate);


    @Query(value = "select  tr.ticket_response_id, q.question," +
            "            p.page_name,  tr.response, tr.image_path," +
            "              q.sequence as questionSequence, q.question_id," +
            "             p.sequence as pageSequence " +
            "            from ticket_response tr " +
            "            left join question q on tr.question_id = q.question_id " +
            "            left join page p on q.page_id = p.page_id " +
            "            left join ticket tt on tr.ticket_id =tt.ticket_id " +
            "            where tt.ticket_id = ?;",
            nativeQuery = true)
    List<Object[]> getPreviewDataByTicketId(Integer ticketId);

}
