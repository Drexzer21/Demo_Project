package com.infominez.audit.repo;

import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.entity.QuestionTypeOption;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuestionTypeOptionRepository extends JpaRepository<QuestionTypeOption,Integer> {

    List<QuestionTypeOption> findByQuestionType(QuestionType questionType);
    List<QuestionTypeOption> findByQuestionTypeAndOption(QuestionType questionType, String option);
    List<QuestionTypeOption> findByQuestionTypeAndOptionAndQuestionId(QuestionType questionType, String option, Integer questionId);

    List<QuestionTypeOption> findByQuestionId(Integer questionId);
}
