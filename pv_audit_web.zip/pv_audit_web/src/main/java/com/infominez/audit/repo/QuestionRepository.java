package com.infominez.audit.repo;

import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.Question;
import com.infominez.audit.entity.QuestionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface QuestionRepository extends JpaRepository<Question,Integer> {
    List<Question> findByPage(Page page);

    @Query(value = "SELECT * from question q " +
            "join question_type qt on qt.question_type_id = q.question_type_id " +
            "where q.question_type_id = ? "
            , nativeQuery = true)
    List<Question> findByQuestionType(Integer questionTypeId);

    List<Question> findByPageAndQuestionAndQuestionType(Page page, String question, QuestionType questionType);

    @Query("SELECT q from Question q where q.page.pageId = :pageId and q.parentId is null and  q.influenceBy is null")
    List<Question> findByPageAndParentIdNull(Integer pageId);

    List<Question> findByParentId(Integer parentId);

    @Query(value = "SELECT q.question_id, p.page_name, q.question, qt.type, q.default_value, " +
            " q.is_mandatory, q.datatype, q.capture_img_status, q.sequence, " +
            " (select question from question where question_id = q.parent_id) as parent," +
            " (select question from question where question_id = q.influence_by) as inflencer, " +
            " q.influencer_response_value, q.is_prefilled, q.prefilled_by ,q.parent_id, q.influence_by, q.question_type_id, " +
            " q.is_derived, q.operator, q.operand, " +
            " (select group_concat(question) from question where find_in_set(question_id, q.operand)) as operandName , q.is_yes_no " +
            "from question q " +
            "inner join page p on q.page_id = p.page_id " +
            "join question_type qt on q.question_type_id = qt.question_type_id " +
            "where q.page_id = ?"
            , nativeQuery = true)
    List<Object[]> getQuestionByPageId(Integer pageId);

    List<Question> findByInfluenceBy(Integer questionId);

    @Query("SELECT q from Question q where q.page.template.templateId = :templateId")
    List<Question> findByTemplateId(Integer templateId);

    Question findByPageAndSequence(Page page, Integer sequence);

    @Query(value = "select  group_concat(operand) from question where is_derived = 1  and page_id =:pageId", nativeQuery = true )
    String findDrivedParticipantList(Integer pageId);

    @Query(value = "select * from question where question_id in (:questionIds) and question_type_id  = 8 ", nativeQuery = true )
    List<Question> findOperandQuestionQRByList(List<Integer> questionIds);
}
