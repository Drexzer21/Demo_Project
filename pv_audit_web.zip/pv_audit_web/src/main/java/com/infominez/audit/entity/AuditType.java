package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.json.simple.JSONObject;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;
import java.util.Date;

@Entity
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name = "audit_type" )
public class AuditType implements Serializable {
    private static final Long serialVersionUID = 1L;


    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "audit_type_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer auditTypeId;


    @Basic(optional = false)
    @Column(name = "audit_type")
    private String auditType;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "created_by")
    private Integer createdBy;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "updated_by")
    private Integer updatedBy;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "created_date")
    private Date createdDate;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "last_updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDate;


    public AuditType(Integer auditTypeId, String auditType, Integer createdBy, Integer updatedBy, Date createdDate,
                     Date lastUpdatedDate) {
        this.auditTypeId = auditTypeId;
        this.auditType = auditType;
        this.createdBy = createdBy;
        this.updatedBy = updatedBy;
        this.createdDate = createdDate;
        this.lastUpdatedDate = lastUpdatedDate;
    }
}
