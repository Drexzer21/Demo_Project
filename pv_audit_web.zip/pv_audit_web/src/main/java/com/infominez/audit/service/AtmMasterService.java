package com.infominez.audit.service;

import com.infominez.audit.entity.AtmMaster;
import com.infominez.audit.repo.AtmMasterRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class AtmMasterService {
    private final AtmMasterRepository atmMasterRepository;

    public JSONObject createAtmMaster(AtmMaster atmMaster) {
        log.info(this.getClass().getName() + " :- createAtmMaster()");
        JSONObject result = new JSONObject();
        try {
            List<AtmMaster> list = atmMasterRepository.findByAtmId(atmMaster.getAtmId());
            if (list != null && !list.isEmpty() && atmMaster.getAtmMasterId() != list.get(0).getAtmMasterId()) {
                result.put("status", 302);
                result.put("response", "AtmMaster already Exist with AtmId : " + atmMaster.getAtmId());
            } else {
                AtmMaster createdAtmMaster = atmMasterRepository.save(atmMaster);

                if (createdAtmMaster != null) {
                    result.put("status", 200);
                    result.put("response", "object Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add object");
                }
            }
        } catch (Exception e) {

            log.error("Exception in createAtmMaster for AtmMaster : {} and exception : {} ", atmMaster.toString(), e.getMessage());
            log.trace("Exception in createAtmMaster for AtmMaster : {} and trace : {} ", atmMaster.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject updateAtmMaster(AtmMaster atmMaster) {
        log.info(this.getClass().getName() + " :- updateAtmMaster()");
        JSONObject result = new JSONObject();
        try {
            List<AtmMaster> list = atmMasterRepository.findByAtmId(atmMaster.getAtmId());
            if (list != null && !list.isEmpty() && atmMaster.getAtmMasterId() != list.get(0).getAtmMasterId()) {
                result.put("status", 302);
                result.put("response", "AtmMaster already Exist with AtmId : " + atmMaster.getAtmId());
            } else {
                AtmMaster atmMasterToUpdate = atmMasterRepository.findById(atmMaster.getAtmMasterId()).get();
                if (atmMasterToUpdate != null) {
                    if (atmMaster.getAtmId() != null) {
                        atmMasterToUpdate.setAtmId(atmMaster.getAtmId());
                    }
                    if (atmMaster.getAtmBrand() != null) {
                        atmMasterToUpdate.setAtmBrand(atmMaster.getAtmBrand());
                    }
                    if (atmMaster.getAtmType() != null) {
                        atmMasterToUpdate.setAtmType(atmMaster.getAtmType());
                    }
                    if (atmMaster.getBank() != null) {
                        atmMasterToUpdate.setBank(atmMaster.getBank());
                    }
                    if (atmMaster.getSite() != null) {
                        atmMasterToUpdate.setSite(atmMaster.getSite());
                    }
                    if (atmMaster.getVendor() != null) {
                        atmMasterToUpdate.setVendor(atmMaster.getVendor());
                    }
                    if (atmMaster.getPopulationType() != null) {
                        atmMasterToUpdate.setPopulationType(atmMaster.getPopulationType());
                    }
                    if (atmMaster.getState() != null) {
                        atmMasterToUpdate.setState(atmMaster.getState());
                    }
                    if (atmMaster.getCity() != null) {
                        atmMasterToUpdate.setCity(atmMaster.getCity());
                    }
                    if (atmMaster.getSiteAddress() != null) {
                        atmMasterToUpdate.setSiteAddress(atmMaster.getSiteAddress());
                    }
                    if (atmMaster.getDeviceType() != null) {
                        atmMasterToUpdate.setDeviceType(atmMaster.getDeviceType());
                    }
                    if (atmMaster.getRegion() != null) {
                        atmMasterToUpdate.setRegion(atmMaster.getRegion());
                    }
                    if (atmMaster.getAtmMake() != null) {
                        atmMasterToUpdate.setAtmMake(atmMaster.getAtmMake());
                    }
                    if (atmMaster.getUpsMake() != null) {
                        atmMasterToUpdate.setUpsMake(atmMaster.getUpsMake());
                    }

                    atmMasterRepository.save(atmMasterToUpdate);
                    result.put("status", 200);
                    result.put("response", "AtmMaster Updated Successfully");

                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update AtmMaster");
                }
            }
        } catch (Exception e) {

            log.error("Exception in updateObject for AtmMaster : {} and exception : {} ", atmMaster.toString(), e.getMessage());
            log.trace("Exception in updateObject for AtmMaster : {} and trace : {} ", atmMaster.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;

    }
    public JSONObject findAtmMasterById(Integer id) {
        log.info(this.getClass().getName() + " :- findAtmMasterById()");
        JSONObject result = new JSONObject();
        try {
            AtmMaster atmMaster = atmMasterRepository.findById(id).get();
            if (atmMaster != null) {
                result.put("status", 200);
                result.put("response", atmMaster);
            } else {
                result.put("status", 302);
                result.put("response", "AtmMaster Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAtmMasterById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findAtmMasterById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllAtmMaster() {
        log.info(this.getClass().getName() + " :- findAllAtmMaster()");
        JSONObject result = new JSONObject();
        try {
            List<AtmMaster> atmMasters = atmMasterRepository.findAll();
            if (atmMasters != null) {
                result.put("status", 200);
                result.put("response", atmMasters);
            } else {
                result.put("status", 302);
                result.put("response", "AtmMasters Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllAtmMaster : {} and exception : {} ",  e.getMessage());
            log.trace("Exception in findAllAtmMaster  : {} and trace : {} ",  e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
    public JSONObject GetAllBanks() {
        JSONObject result = new JSONObject();
        try{
            List<Object> list = atmMasterRepository.GetAllBanks();
            JSONArray bankList = new JSONArray();
            for (Object obj : list){
                JSONObject bank = new JSONObject();
                bank.put("bankName", obj);
                bankList.add(bank);
            }
            result.put("status", 200);
            result.put("response", bankList);
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
    public JSONObject GetAllVendor() {
        JSONObject result = new JSONObject();
        try{
            List<Object> list = atmMasterRepository.GetAllVendor();
            JSONArray vendorList = new JSONArray();
            for (Object obj : list){
                JSONObject vendor = new JSONObject();
                vendor.put("vendorName", obj);
                vendorList.add(vendor);
            }
            result.put("status", 200);
            result.put("response", vendorList);
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject  GetAllAtmBrand() {
        JSONObject result = new JSONObject();
        try{
            List<Object> list = atmMasterRepository.GetAllAtmBrand();
            JSONArray atmBrandList = new JSONArray();
            for (Object obj : list){
                JSONObject atmBrand = new JSONObject();
                atmBrand.put("atmBrandName", obj);
                atmBrandList.add(atmBrand);
            }
            result.put("status", 200);
            result.put("response", atmBrandList);
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject  GetAllAtmType() {
        JSONObject result = new JSONObject();
        try{
            List<Object> list = atmMasterRepository.GetAllAtmType();
            JSONArray atmTypeList = new JSONArray();
            for (Object obj : list){
                JSONObject atmType = new JSONObject();
                atmType.put("atmTypeName", obj);
                atmTypeList.add(atmType);
            }
            result.put("status", 200);
            result.put("response", atmTypeList);
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject  GetAtmMasterByBankAndVendorAndAtmBrandAndAtmType(String bank,String vendor,String atmBrand,String atmType) {
        JSONObject result = new JSONObject();
        try{
            List<AtmMaster> list = atmMasterRepository.findByBankAndVendorAndAtmBrandAndAtmType(bank,vendor,atmBrand,atmType);
            if (list != null) {
                result.put("status", 200);
                result.put("response", list);
            } else {
                result.put("status", 302);
                result.put("response", "AtmMasters Not found");
            }
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private String getCellValue(Cell cell) {
        return new DataFormatter().formatCellValue(cell);
    }


    public JSONObject bulkUploadAtmMaster(InputStream inputStream){
        log.info("Bulk Upload Atm Master");
        JSONObject result = new JSONObject();
        try{
            List<AtmMaster> dbAM=atmMasterRepository.findAll();
            List<AtmMaster> tobeInsertAM= new ArrayList<>();
            Workbook wb = WorkbookFactory.create(inputStream);
            Sheet sheet = wb.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = (Row) rowIterator.next();
                if (row.getRowNum() > 0) {
                    AtmMaster atmMaster=new AtmMaster();
                    atmMaster.setAtmId(getCellValue(row.getCell(0)));
                    atmMaster.setBank(getCellValue(row.getCell(1)));
                    atmMaster.setAtmType(getCellValue(row.getCell(2)));
                    atmMaster.setState(getCellValue(row.getCell(3)));
                    atmMaster.setCity(getCellValue(row.getCell(4)));
                    atmMaster.setSite(getCellValue(row.getCell(5)));
                    atmMaster.setSiteAddress(getCellValue(row.getCell(6)));
                    atmMaster.setPopulationType(getCellValue(row.getCell(7)));
                    atmMaster.setAtmBrand(getCellValue(row.getCell(8)));
                    atmMaster.setVendor(getCellValue(row.getCell(9)));
                    atmMaster.setRegion(getCellValue(row.getCell(10)));
                    atmMaster.setDeviceType(getCellValue(row.getCell(11)));
                    atmMaster.setAtmMake(getCellValue(row.getCell(12)));
                    atmMaster.setUpsMake(getCellValue(row.getCell(13)));
                    if (!checkIfExistInList(atmMaster, dbAM)) {
                        if (!checkIfExistInList(atmMaster, tobeInsertAM)) {
                            tobeInsertAM.add(atmMaster);
                        }
                    }
                }
            }
            List<AtmMaster> inserted=atmMasterRepository.saveAll(tobeInsertAM);
            if (inserted != null && inserted.size() > 0) {
                result.put("status", 200);
                result.put("response", "Bulk Upload ATM Master Successfull");
            } else {
                result.put("status", 302);
                result.put("response", "Bulk Upload ATM Master FAILED");
            }

        }catch (Exception e) {
            e.printStackTrace();
            log.error("Exception occur in atm Master bulk Upload : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }


        return result;
    }
    private boolean checkIfExistInList(AtmMaster am, List<AtmMaster> dbAM) {
        Boolean result= true;
        if (dbAM != null && dbAM.size() >0){
            for (AtmMaster object : dbAM){
                if(object.getAtmId().equalsIgnoreCase(am.getAtmId())){
                    result = true;
                    break;
                }else
                    result = false;
            }
        }else{
            result = false;
        }
        return result;
    }


}
