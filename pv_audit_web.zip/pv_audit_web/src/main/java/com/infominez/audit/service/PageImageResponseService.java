package com.infominez.audit.service;

import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.PageImageResponse;
import com.infominez.audit.entity.Template;
import com.infominez.audit.entity.Ticket;
import com.infominez.audit.repo.PageImageResponseRepository;
import com.infominez.audit.repo.PageRepository;
import com.infominez.audit.repo.TicketRepository;
import com.infominez.audit.utils.Constants;
import com.infominez.audit.utils.FileUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class PageImageResponseService {
    private final PageImageResponseRepository pageImageResponseRepository;
    private final PageRepository pageRepository;
    private final TicketRepository ticketRepository;

    public JSONObject createPageImageResponse(PageImageResponse pageImageResponsee) {
        log.info(this.getClass().getName() + " :- createPageImageResponse()");
        JSONObject result = new JSONObject();
        try {
            List<PageImageResponse> list = pageImageResponseRepository.findByTicketAndPage(pageImageResponsee.getTicket(), pageImageResponsee.getPage());
            if (list != null && !list.isEmpty()) {
                result.put("status", 302);
                result.put("response", "PageImageResponse already Exist with Page id : " + pageImageResponsee.getPage().getPageId() + " and TicketID : " + pageImageResponsee.getTicket().getTicketId());
            } else {


                PageImageResponse createdPageImageResponse = pageImageResponseRepository.save(pageImageResponsee);
                if (createdPageImageResponse != null) {
                    result.put("status", 200);
                    result.put("response", "pageImageResponsee Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add pageImageResponsee");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in createPageImageResponse for pageImageResponsee : {} and exception : {} ", pageImageResponsee.toString(), e.getMessage());
            log.trace("Exception in createPageImageResponse for pageImageResponsee : {} and trace : {} ", pageImageResponsee.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject updatePageImageResponse(PageImageResponse pageImageResponsee) {
        log.info(this.getClass().getName() + " :- updatePageImageResponse()");
        JSONObject result = new JSONObject();
        try {
            List<PageImageResponse> list = pageImageResponseRepository.findByTicketAndPage(pageImageResponsee.getTicket(), pageImageResponsee.getPage());
            if (list != null && !list.isEmpty() && pageImageResponsee.getPageImageResponseId() != list.get(0).getPageImageResponseId()) {
                result.put("status", 302);
                result.put("response", "PageImageResponse already Exist with Page id : " + pageImageResponsee.getPage().getPageId() + " and TicketID : " + pageImageResponsee.getTicket().getTicketId());
            } else {
                PageImageResponse pageImageResponseToUpdate = pageImageResponseRepository.findById(pageImageResponsee.getPageImageResponseId()).get();
                if (pageImageResponseToUpdate != null) {

                    if (pageImageResponsee.getTicket() != null) {
                        pageImageResponseToUpdate.setTicket(pageImageResponsee.getTicket());
                    }


                    if (pageImageResponsee.getPage() != null) {
                        pageImageResponseToUpdate.setPage(pageImageResponsee.getPage());
                    }


                    if (pageImageResponsee.getImagePath() != null) {
                        pageImageResponseToUpdate.setImagePath(pageImageResponsee.getImagePath());
                    }


                    pageImageResponseRepository.save(pageImageResponseToUpdate);
                    result.put("status", 200);
                    result.put("response", "pageImageResponsee Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update pageImageResponsee");
                }
            }
        } catch (Exception e) {

            log.error("Exception in updatePage for Page : {} and exception : {} ", pageImageResponsee.toString(), e.getMessage());
            log.trace("Exception in updatePage for Page : {} and trace : {} ", pageImageResponsee.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findPageImageResponseeById(Integer id) {
        log.info(this.getClass().getName() + " :- findPageImageResponseeById()");
        JSONObject result = new JSONObject();
        try {
            PageImageResponse pageImageResponse = pageImageResponseRepository.findById(id).get();
            if (pageImageResponse != null) {
                result.put("status", 200);
                result.put("response", pageImageResponse);
            } else {
                result.put("status", 302);
                result.put("response", "pageImageResponse Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findPageById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findPageById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllPageImageResponse() {
        log.info(this.getClass().getName() + " :- findAllPageImageResponse()");
        JSONObject result = new JSONObject();
        try {
            List<PageImageResponse> pageImageResponses = pageImageResponseRepository.findAll();
            if (pageImageResponses != null) {
                result.put("status", 200);
                result.put("response", pageImageResponses);
            } else {
                result.put("status", 302);
                result.put("response", "pageImageResponses Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllPageImageResponse for PageImageResponse : {} and exception : {} ", e.getMessage());
            log.trace("Exception in findAllPageImageResponse for PageImageResponse : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findPageImageResponseByTicket(Integer ticketId) {
        log.info(this.getClass().getName() + " :- findPageImageResponseByTicket()");
        JSONObject result = new JSONObject();
        try {
            Ticket ticket = ticketRepository.findById(ticketId).get();
            List<PageImageResponse> pageImageResponses = pageImageResponseRepository.findByTicket(ticket);
            if (pageImageResponses != null) {
                result.put("status", 200);
                result.put("response", pageImageResponses);
            } else {
                result.put("status", 302);
                result.put("response", "pageImageResponses Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findPageImageResponseByTicket for id : {} and exception : {} ", ticketId, e.getMessage());
            log.trace("Exception in findPageImageResponseByTicket for id : {} and trace : {} ", ticketId, e.getStackTrace());

            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findPageImageResponseByPage(Integer pageId) {
        log.info(this.getClass().getName() + " :- findPageImageResponseByPage()");
        JSONObject result = new JSONObject();
        try {
            Page page = pageRepository.findById(pageId).get();
            List<PageImageResponse> pageImageResponses = pageImageResponseRepository.findByPage(page);
            if (pageImageResponses != null) {
                result.put("status", 200);
                result.put("response", pageImageResponses);
            } else {
                result.put("status", 302);
                result.put("response", "pageImageResponses Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findPageImageResponseByPage for id : {} and exception : {} ", pageId, e.getMessage());
            log.trace("Exception in findPageImageResponseByPage for id : {} and trace : {} ", pageId, e.getStackTrace());

            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject savePageImage(MultipartFile file, Integer pageId, Integer ticketId) {
        JSONObject result = new JSONObject();
        try {
            Page page = pageRepository.findById(pageId).get();
            Ticket ticket = ticketRepository.findById(ticketId).get();
            PageImageResponse pageImageResponse = new PageImageResponse();
            if (page != null && ticket != null) {
                pageImageResponse.setPage(page);
                pageImageResponse.setTicket(ticket);

                String imagesDir = Constants.imagesDir;
                String filePathStatic = "ticketPages/" + ticket.getTicketId() + "/" + page.getPageId() + "/";
                imagesDir = imagesDir + filePathStatic;
                String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss-"));
                String fileName = ticket.getTicketId() + "_" + page.getPageId() + "_" + date + ".png";
                String path = FileUtils.writeFile(file, imagesDir, fileName);
                pageImageResponse.setImagePath(filePathStatic + fileName);
                PageImageResponse createdPageImageResponse = pageImageResponseRepository.save(pageImageResponse);
                if (createdPageImageResponse != null) {
                    result.put("status", 200);
                    result.put("response", "Image Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add Image");
                }
            } else {
                result.put("status", 302);
                result.put("response", "Ticket or Page Not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 200);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
}
