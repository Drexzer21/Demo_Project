package com.infominez.audit.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

/**
 * @author AYUSH PARTANI
 *
 */
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	private final TokenProvider tokenProvider;

	  public SecurityConfig(TokenProvider tokenProvider) {
	    this.tokenProvider = tokenProvider;
	  }

	  @Bean
	  @Override
	  public AuthenticationManager authenticationManagerBean() throws Exception {
	    return super.authenticationManagerBean();
	  }
	

	/*  @Override
	  protected void configure(HttpSecurity http) throws Exception {
			http
			  .csrf()
			    .disable()
			  .cors()
			    .and()
			  .sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
			  .authorizeRequests()
			    .antMatchers("/signup").permitAll()
			    .antMatchers("/login").permitAll()
			    .antMatchers("/role/**").permitAll()
					.antMatchers("/testInvestigation/generateTestReport").permitAll()
			    .anyRequest().authenticated()
			    .and()
			  .apply(new JWTConfigurer(this.tokenProvider));
			
	  }*/

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
				.csrf()
				.disable()
				.cors()
				.and()
				.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
				.authorizeRequests()
//				.antMatchers("/oauth/token").permitAll()
				.antMatchers("/**").permitAll()
				.anyRequest().authenticated()
				.and()
				.apply(new JWTConfigurer(this.tokenProvider));

	}
	

}
