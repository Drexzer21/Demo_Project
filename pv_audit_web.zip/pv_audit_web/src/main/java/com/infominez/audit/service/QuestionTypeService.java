package com.infominez.audit.service;


import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.repo.QuestionTypeRepository;
import com.infominez.audit.wrapper.BaseResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class QuestionTypeService {

    private final QuestionTypeRepository questionTypeRepository;

    public JSONObject createQuestionType(QuestionType questionType) {
        JSONObject baseResponse = new JSONObject();
        try {
            List<QuestionType> list = questionTypeRepository.findByQuestionType(questionType.getQuestionType());
            if (list != null && !list.isEmpty()) {
                baseResponse.put("status", 302);
                baseResponse.put("response", "Question Type Already exist");
            } else {
                Date date = new Date();
                questionType.setCreatedBy(1);
                questionType.setUpdatedBy(1);
                questionType.setCreatedDate(date);
                questionType.setLastUpdatedDate(date);
                questionType.setIsOption(false);

                baseResponse.put("response", questionTypeRepository.save(questionType));
            }
        } catch (Exception e) {
            baseResponse.put("status", 500);
            baseResponse.put("response", "Internal Server Error");
        }

        return baseResponse;
    }


    public JSONObject updateQuestionType(QuestionType questionType) {
        log.info(this.getClass().getName() + " :- updateQuestionType()");
        JSONObject baseResponse = new JSONObject();
        try {
            List<QuestionType> list = questionTypeRepository.findByQuestionType(questionType.getQuestionType());
            if (list != null && !list.isEmpty() && questionType.getQuestionTypeId() != list.get(0).getQuestionTypeId()) {
                baseResponse.put("status", 302);
                baseResponse.put("response", "Question Type Already exist");
            } else {

                Date date = new Date();
                QuestionType getQuestionType = questionTypeRepository.findById(questionType.getQuestionTypeId()).get();
                if (questionType.getQuestionType() != null && !questionType.getQuestionType().isEmpty()) {
                    getQuestionType.setQuestionType(questionType.getQuestionType());
                }
                if (questionType.getIsOption() != null) {
                    getQuestionType.setIsOption(questionType.getIsOption());
                }

                questionType.setLastUpdatedDate(date);
                baseResponse.put("status", 200);
                baseResponse.put("response", questionTypeRepository.save(questionType));
            }
        } catch (Exception e) {
            baseResponse.put("status", 500);
            baseResponse.put("response", "Internal Server Error");
        }
        return baseResponse;
    }


    public JSONObject findQuestionTypeById(Integer questionTypeId) {
        log.info(this.getClass().getName() + " :- findQuestionTypeById()");
        JSONObject jsonObject = new JSONObject();
        try {
            QuestionType questionType = questionTypeRepository.findById(questionTypeId).get();
            if (questionType != null ) {
                jsonObject.put("status", 200);
                jsonObject.put("response", questionType);
            } else {
                jsonObject.put("status", 302);
                jsonObject.put("response", "No Question Found");
            }
        } catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }


        return jsonObject;
    }

    public JSONObject findAllQuestionType() {
        JSONObject result = new JSONObject();
        try {
            List<QuestionType> list = questionTypeRepository.findAll();
            if (list != null && !list.isEmpty()) {
                result.put("status", 200);
                result.put("response", list);
            } else {
                result.put("status", 302);
                result.put("response", "No Question Found");
            }
        } catch (Exception e) {
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
}


