package com.infominez.audit.service;


import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.entity.QuestionTypeOption;
import com.infominez.audit.repo.QuestionTypeOptionRepository;
import com.infominez.audit.repo.QuestionTypeRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class QuestionTypeOptionService {
    private final QuestionTypeOptionRepository questionTypeOptionRepository;
    private final QuestionTypeRepository questionTypeRepository;

    public JSONObject createQuestionTypeOption(QuestionTypeOption questionTypeOption) {
        JSONObject jsonObject = new JSONObject();
        try {
            List<QuestionTypeOption> list = questionTypeOptionRepository.findByQuestionTypeAndOptionAndQuestionId(questionTypeOption.getQuestionType(), questionTypeOption.getOption(), questionTypeOption.getQuestionId());

            if (list != null && !list.isEmpty()) {
                jsonObject.put("status", 302);
                jsonObject.put("response", "Question Type Option Already exist");
            } else {
                Date date = new Date();
                questionTypeOption.setCreatedBy(1);
                questionTypeOption.setUpdatedBy(1);
                questionTypeOption.setCreatedDate(date);
                questionTypeOption.setLastUpdatedDate(date);
                QuestionTypeOption temp = questionTypeOptionRepository.findById(questionTypeOptionRepository.save(questionTypeOption).getQuestionTypeOptionId()).get();
                if (temp != null) {
                    jsonObject.put("status", 200);
                    jsonObject.put("response", "Question Type Option Created Successfully");
                } else {
                    jsonObject.put("status", 302);
                    jsonObject.put("response", "Unable to create Question Type Option");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }

        return jsonObject;
    }

    public JSONObject updateQuestionTypeOption(QuestionTypeOption questionTypeOption) {
        log.info(this.getClass().getName() + " :- updateQuestionTypeOption()");

        JSONObject jsonObject = new JSONObject();
        try {
            List<QuestionTypeOption> list = questionTypeOptionRepository.findByQuestionTypeAndOptionAndQuestionId(questionTypeOption.getQuestionType(), questionTypeOption.getOption(), questionTypeOption.getQuestionId());
            if (list != null && !list.isEmpty() && list.get(0).getQuestionTypeOptionId() != questionTypeOption.getQuestionTypeOptionId()) {
                jsonObject.put("status", 302);
                jsonObject.put("response", "Question Type Option Already exist");
            } else {
                Date date = new Date();
                QuestionTypeOption updatedquestionTypeOption = questionTypeOptionRepository.findById(questionTypeOption.getQuestionTypeOptionId()).get();
                if (questionTypeOption.getQuestionType() != null) {
                    updatedquestionTypeOption.setQuestionType(questionTypeOption.getQuestionType());
                }
                if (questionTypeOption.getOption() != null) {
                    updatedquestionTypeOption.setOption(questionTypeOption.getOption());
                }
                questionTypeOption.setLastUpdatedDate(date);
                QuestionTypeOption temp = questionTypeOptionRepository.findById(questionTypeOptionRepository.save(updatedquestionTypeOption).getQuestionTypeOptionId()).get();
                if (temp != null) {
                    jsonObject.put("status", 200);
                    jsonObject.put("response", "Question Type Option Updated Successfully");
                } else {
                    jsonObject.put("status", 302);
                    jsonObject.put("response", "Unable to Update Question Type Option");
                }
            }
        } catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }
        return jsonObject;
    }

    public JSONObject findQuestionTypeOptionById(Integer questionTypeOptionId) {
        log.info(this.getClass().getName() + " :- findQuestionTypeOptionById()");
        JSONObject jsonObject = new JSONObject();
        try {
            QuestionTypeOption questionTypeOption = questionTypeOptionRepository.findById(questionTypeOptionId).get();
            if (questionTypeOption != null) {
                jsonObject.put("status", 200);
                jsonObject.put("response", questionTypeOption);
            } else {
                jsonObject.put("status", 302);
                jsonObject.put("response", "No Question type option Found");
            }
        } catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }


        return jsonObject;
    }

    public JSONObject findAllQuestionTypeOption() {
        JSONObject result = new JSONObject();
        try {
            List<QuestionTypeOption> list = questionTypeOptionRepository.findAll();
            if (list != null && !list.isEmpty()) {
                result.put("status", 200);
                result.put("response", list);
            } else {
                result.put("status", 302);
                result.put("response", "No Question Type Option Found");
            }
        } catch (Exception e) {
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findByQuestionType(Integer questionTypeId) {

        log.info(this.getClass().getName() + " :- findQuestionTypeOptionById()");
        JSONObject jsonObject = new JSONObject();
        try {
            QuestionType questionType1 = questionTypeRepository.findById(questionTypeId).get();
            List<QuestionTypeOption> questionTypeOption = questionTypeOptionRepository.findByQuestionType(questionType1);
            if (questionTypeOption != null) {
                jsonObject.put("status", 200);
                jsonObject.put("response", questionTypeOption);
            } else {
                jsonObject.put("status", 302);
                jsonObject.put("response", "No Question type option Found");
            }
        } catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }


        return jsonObject;

    }


    public JSONObject findByQuestion(Integer questionId) {

        log.info(this.getClass().getName() + " :- findByQuestion()");
        JSONObject jsonObject = new JSONObject();
        try {
            List<QuestionTypeOption> questionTypeOption = questionTypeOptionRepository.findByQuestionId(questionId);
            if (questionTypeOption != null) {
                jsonObject.put("status", 200);
                jsonObject.put("response", questionTypeOption);
            } else {
                jsonObject.put("status", 302);
                jsonObject.put("response", "No Question type option Found");
            }
        } catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }


        return jsonObject;

    }
}
