package com.infominez.audit.wrapper;

import com.infominez.audit.entity.Audit;
import com.infominez.audit.entity.Site;
import com.infominez.audit.entity.Users;
import lombok.Data;

import java.util.List;
@Data
public class TicketWrapper {

    private Audit audit;
    private Users users;
    private List<Site> siteList;


}
