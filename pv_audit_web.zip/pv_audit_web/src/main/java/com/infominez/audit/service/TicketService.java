package com.infominez.audit.service;


import com.infominez.audit.AuditApplication;
import com.infominez.audit.entity.*;
import com.infominez.audit.repo.*;
import com.infominez.audit.utils.Constants;
import com.infominez.audit.utils.ExcelUtils;
import com.infominez.audit.wrapper.TicketWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import javax.persistence.criteria.CriteriaBuilder;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Slf4j
@AllArgsConstructor
public class TicketService {
    private final TicketRepository ticketRepository;
    private final AuditRepository auditRepository;
    private final UsersRepository usersRepository;
    private final SiteRepository siteRepository;
    private final TicketResponseRepository ticketResponseRepository;

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public JSONObject createTicket(Ticket ticket) {
        log.info(this.getClass().getName() + " :- createTicket()");
        JSONObject result = new JSONObject();
        try {
            List<Ticket> list = ticketRepository.findByAuditAndUsersAndSite(ticket.getAudit(), ticket.getUsers(), ticket.getSite());
            if (list != null && !list.isEmpty() && ticket.getTicketId() != list.get(0).getTicketId()) {
                result.put("status", 302);
                result.put("response", "ticket already Exist with AuditId : " + ticket.getAudit() + " and UsersId : " + ticket.getUsers() + "And ObjectId" + ticket.getSite());
            } else {
                Date date = new Date();
                ticket.setCreatedBy(1); // todo change when login is implemented
                ticket.setUpdatedBy(1); // todo change when login is implemented
                ticket.setCreatedDate(date);
                ticket.setLastUpdatedDate(date);
                ticket.setStatus("PENDING");
                ticket.setIsAdhoc(false);
                ticket.setIsScheduledTicket(false);
                ticket.setIsDeleted(false);
                Ticket createdticket = ticketRepository.save(ticket);
                if (createdticket != null) {
                    result.put("status", 200);
                    result.put("response", "ticket Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add ticket");
                }
            }
        } catch (Exception e) {

            log.error("Exception in createticket for ticket : {} and exception : {} ", ticket.toString(), e.getMessage());
            log.trace("Exception in createticket for ticket : {} and trace : {} ", ticket.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject updateTicket(Ticket ticket) {
        log.info(this.getClass().getName() + " :- updateTicket()");
        JSONObject result = new JSONObject();
        try {
            List<Ticket> list = ticketRepository.findByAuditAndUsersAndSite(ticket.getAudit(), ticket.getUsers(), ticket.getSite());
            if (list != null && !list.isEmpty() && ticket.getTicketId() != list.get(0).getTicketId()) {
                result.put("status", 302);
                result.put("response", "ticket already Exist with AuditId : " + ticket.getAudit() + " and UsersId : " + ticket.getUsers() + "And ObjectId" + ticket.getSite());
            } else {
                Ticket ticketToUpdate = ticketRepository.findById(ticket.getTicketId()).get();
                if (ticketToUpdate != null) {
                    if (ticket.getAudit() != null) {
                        ticketToUpdate.setAudit(ticket.getAudit());
                    }
                    if (ticket.getUsers() != null) {
                        ticketToUpdate.setUsers(ticket.getUsers());
                    }
                    if (ticket.getSite() != null) {
                        ticketToUpdate.setSite(ticket.getSite());
                    }
                    if (ticket.getStatus() != null) {
                        ticketToUpdate.setStatus(ticket.getStatus());
                    }
                    ticketToUpdate.setIsDeleted(false);
                    ticketToUpdate.setLastUpdatedDate(new Date());
                    ticketRepository.save(ticketToUpdate);
                    result.put("status", 200);
                    result.put("response", "Ticket Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update Ticket");
                }
            }
        } catch (Exception e) {

            log.error("Exception in updateTicket for Ticket : {} and exception : {} ", ticket.toString(), e.getMessage());
            log.trace("Exception in updateTicket for Ticket : {} and trace : {} ", ticket.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findTicketById(Integer id) {
        log.info(this.getClass().getName() + " :- findTicketById()");
        JSONObject result = new JSONObject();
        try {
            Ticket ticket = ticketRepository.findById(id).get();
            if (ticket != null) {
                result.put("status", 200);
                result.put("response", ticket);
            } else {
                result.put("status", 302);
                result.put("response", "Ticket Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTicketById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findTicketById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllTicket() {
        log.info(this.getClass().getName() + " :- findAllTicket()");
        JSONObject result = new JSONObject();
        JSONArray array=new JSONArray();
        try {
            List<Ticket> getTicket = ticketRepository.findAll();
            if (getTicket != null) {
            for(Ticket ticket:getTicket) {
            	if( !ticket.getIsDeleted()) {
            	array.add(ticket);
            	}

            }
                result.put("status", 200);
                result.put("response", array);
            } else {
                result.put("status", 302);
                result.put("response", "Ticket Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllTicket for : {} and exception : {} ", e.getMessage());
            log.trace("Exception in findAllTicket for : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
            e.printStackTrace();

        }
        return result;
    }

    public JSONObject findTicketByUsersId(Integer usersId) {
        log.info(this.getClass().getName() + " :- findUsersByAuditId()");
        JSONObject result = new JSONObject();
        JSONArray array=new JSONArray();
        try {
            Users users = usersRepository.findById(usersId).get();
            List<Ticket> getTicket = ticketRepository.findByUsers(users);
            if (getTicket != null) {
            	 for(Ticket ticket:getTicket) {
                 	if( !ticket.getIsDeleted()) {
                 	array.add(ticket);
                 	}
            	 }
                result.put("status", 200);
                result.put("response", array);
            } else {
                result.put("status", 302);
                result.put("response", "Ticket Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTicketByUsersId for usersId : {} and exception : {} ", usersId, e.getMessage());
            log.trace("Exception in findTicketByUsersId for usersId : {} and trace : {} ", usersId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findTicketByAuditId(Integer auditId) {
        log.info(this.getClass().getName() + " :- findTicketByAuditId()");
        JSONObject result = new JSONObject();
        JSONArray array=new JSONArray();
        try {
            Audit audit = auditRepository.findById(auditId).get();
            List<Ticket> getTicket = ticketRepository.findByAudit(audit);
            if (getTicket != null) {
            	for(Ticket ticket:getTicket) {
                 	if( !ticket.getIsDeleted()) {
                 	array.add(ticket);
                 	}
            	 }
                result.put("status", 200);
                result.put("response", array);
            } else {
                result.put("status", 302);
                result.put("response", "Ticket Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTicketByAuditId for auditId : {} and exception : {} ", auditId, e.getMessage());
            log.trace("Exception in findTicketByAuditId for auditId : {} and trace : {} ", auditId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findTicketBySiteId(Integer siteId) {
        log.info(this.getClass().getName() + " :- findTicketBySiteId()");
        JSONObject result = new JSONObject();
        JSONArray array=new JSONArray();
        try {
            Site site = siteRepository.findById(siteId).get();
            List<Ticket> getTicket = ticketRepository.findByAndSite(site);
            if (getTicket != null) {
            	for(Ticket ticket:getTicket) {
                 	if( !ticket.getIsDeleted()) {
                 	array.add(ticket);
                 	}
            	 }
                result.put("status", 200);
                result.put("response", array);
            } else {
                result.put("status", 302);
                result.put("response", "Ticket Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findTicketBySiteId for siteId : {} and exception : {} ", siteId, e.getMessage());
            log.trace("Exception in findTicketBySiteId for siteId : {} and trace : {} ", siteId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject createMultipleObjectTicket(TicketWrapper ticketWrapper) {
        log.info(this.getClass().getName() + " :- createMultipleObjectTicket()");
        JSONObject result = new JSONObject();
        try {
            Map<Integer, String> responseMap = new HashMap<>();
            for (Site site : ticketWrapper.getSiteList()) {
                List<Ticket> list = ticketRepository.findByAuditAndUsersAndSiteAndStatusNot(ticketWrapper.getAudit(),
                        ticketWrapper.getUsers(), site,"COMPLETED");
                if (list != null && !list.isEmpty()) {
                    responseMap.put(site.getSiteId(), "ticket already Exist with AuditId : " + ticketWrapper.getAudit() + " and UsersId : " + ticketWrapper.getUsers() + "And ObjectId" + site.getSiteId());
                } else {
                    Ticket ticket = new Ticket();
                    Date date = new Date();
                    ticket.setCreatedBy(1); // todo change when login is implemented
                    ticket.setUpdatedBy(1); // todo change when login is implemented
                    ticket.setCreatedDate(date);
                    ticket.setLastUpdatedDate(date);
                    ticket.setAudit(ticketWrapper.getAudit());
                    ticket.setUsers(ticketWrapper.getUsers());
                    ticket.setSite(site);
                    ticket.setStatus("PENDING");
                    ticket.setIsAdhoc(false);
                    ticket.setIsScheduledTicket(false);
                    ticket.setIsDeleted(false);
                    Ticket createdticket = ticketRepository.save(ticket);
                    if (createdticket != null) {
                        responseMap.put(site.getSiteId(), "Created Success");
                    } else {
                        responseMap.put(site.getSiteId(), "Created FAILED");
                    }
                }
            }
            result.put("status", 200);
            result.put("response", responseMap);
        } catch (Exception e) {
            log.error("Exception in createMultipleObjectTicket for ticket : {} and exception : {} ", ticketWrapper.toString(), e.getMessage());
            log.trace("Exception in createMultipleObjectTicket for ticket : {} and trace : {} ", ticketWrapper.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findByStatus(String status) {
        log.info(this.getClass().getName() + " :- findByStatus()");
        JSONObject result = new JSONObject();
        JSONArray array=new JSONArray();
        try {
            List<Ticket> getTicket = ticketRepository.findByStatus(status);
            if (getTicket != null) {
            	for(Ticket ticket:getTicket) {
                 	if( !ticket.getIsDeleted()) {
                 	array.add(ticket);
                 	}
            	 }
                result.put("status", 200);
                result.put("response", array);
            } else {
                result.put("status", 302);
                result.put("response", "Ticket Not found");
            }
        } catch (Exception e) {
            log.error("Exception in findByStatus for status : {} and exception : {} ", status, e.getMessage());
            log.trace("Exception in findByStatus for status : {} and trace : {} ", status, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getAdminDashboardData() {
        log.info(this.getClass().getName() + " :- getAdminDashboardData()");
        JSONObject result = new JSONObject();
        try {
            JSONArray array = new JSONArray();
            List<Object[]> list = ticketRepository.getAdminDashboardData();
            if (list != null && list.size() > 0) {
                list.forEach(obj -> {
                    JSONObject object = new JSONObject();
                    object.put("templateName", obj[0]);
                    object.put("auditName", obj[1]);
                    object.put("startDate", obj[2]);
                    object.put("endDate", obj[3]);
                    object.put("team", obj[4]);
                    object.put("total", obj[5]);
                    object.put("assigned", obj[6]);
                    object.put("unassigned", obj[7]);
                    object.put("completed", obj[8]);
                    object.put("pending", obj[9]);
                    object.put("state", obj[10]);
                    array.add(object);
                });
                result.put("status", 200);
                result.put("response", array);
            } else {
                result.put("status", 302);
                result.put("response", "No Audit Available");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject bulkAssignAudit(InputStream inputStream, Users creator) {
        log.info("bulkAssignAudit");
        JSONObject result = new JSONObject();
        try {
            Date date = new Date();
            List<Ticket> tobeInsert = new ArrayList<>();
            Workbook wb = WorkbookFactory.create(inputStream);
            Sheet sheet = wb.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = (Row) rowIterator.next();
                if (row.getRowNum() > 0) {
                    String siteCode = getCellValue(row.getCell(0));
                    String email = getCellValue(row.getCell(1));
                    String auditName = getCellValue(row.getCell(2));

                    Audit audit = AuditApplication.auditMap.get(auditName);
                    Site site = AuditApplication.siteMap.get(siteCode);
                    Users user = AuditApplication.usersMap.get(email);
                    if (audit != null && site != null && user != null) {
                        Ticket ticket = new Ticket();
                        ticket.setAudit(audit);
                        ticket.setSite(site);
                        ticket.setUsers(user);
                        ticket.setCreatedBy(creator.getUserId());
                        ticket.setUpdatedBy(creator.getUserId());
                        ticket.setCreatedDate(date);
                        ticket.setLastUpdatedDate(date);
                        ticket.setStatus("PENDING");
                        ticket.setIsAdhoc(false);
                        ticket.setIsScheduledTicket(false);
                        ticket.setIsDeleted(false);
                        if (!checkIfExistInList(ticket, tobeInsert)) {
                            tobeInsert.add(ticket);
                        }
                    }

                }
            }
            List<Ticket> inserted = ticketRepository.saveAll(tobeInsert);
            if (inserted != null && inserted.size() > 0) {
                result.put("status", 200);
                result.put("response", "Bulk Upload Assign Audit Successfull");
            } else {
                result.put("status", 302);
                result.put("response", "Bulk Upload Assign Audit FAILED");
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception occur in Assign Audit bulk Upload : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }


        return result;
    }

    private String getCellValue(Cell cell) {
        return new DataFormatter().formatCellValue(cell);
    }

    private boolean checkIfExistInList(Ticket ticket, List<Ticket> dbTickets) {
        Boolean result = true;
        if (dbTickets != null && dbTickets.size() > 0) {
            for (Ticket object : dbTickets) {
                if (object.getAudit().getAuditId().equals(ticket.getAudit().getAuditId())
                        && object.getSite().getSiteId().equals(ticket.getSite().getSiteId())
                        && object.getUsers().getUserId().equals(ticket.getUsers().getUserId())) {
                    result = true;
                    break;
                } else
                    result = false;
            }
        } else {
            result = false;
        }
        return result;
    }

    public JSONObject findAllTicketPaginated(int page, int size) {
        JSONObject result = new JSONObject();
        try {

            Pageable paging = PageRequest.of(page, size);
            Page<Ticket> pages = ticketRepository.findAllByIsDeleted(false,paging);
            if (pages != null && !pages.getContent().isEmpty()) {
                result.put("status", 200);
                result.put("content", pages.getContent());
                result.put("totalPages", pages.getTotalPages());
                result.put("totalElements", pages.getTotalElements());
                result.put("numberOfElements", pages.getNumberOfElements());
                result.put("size", pages.getSize());
                result.put("number", pages.getNumber());
            } else {
                result.put("status", 302);
                result.put("response", "No Data Available");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject searchTicket(String searchTerm) {
        JSONObject result = new JSONObject();
        try {
            List<Ticket> list = ticketRepository.searchTicket(searchTerm);
            if(list != null && !list.isEmpty()){
                result.put("status" , 200);
                result.put("response", list);
            } else {
                result.put("status", 302);
                result.put("response", "No Data Available");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject EncodeFileToBase64Binary(String path) {

        JSONObject jsonObject = new JSONObject();
        String urlPath = Constants.imagesDir;
        String finalPath = urlPath+path;
        String base64Image = "";
        File file = new File(finalPath);
        try(FileInputStream imageInFile = new FileInputStream(file)) {
            byte imageData[] = new byte[(int) file.length()];
            imageInFile.read(imageData);
            base64Image = Base64.encodeBase64String(imageData);

            jsonObject.put("status",200);
            jsonObject.put("response",base64Image);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            jsonObject.put("status",400);
            jsonObject.put("response","Something went to wrong ");
        } catch (IOException e) {			// TODO Auto-generated catch block
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
            jsonObject.put("status",400);
            jsonObject.put("response","Something went to wrong ");
        }


        return jsonObject;
    }

    public ByteArrayInputStream  downloadTicket() {
        log.info(" writing ticket excel");
        try(SXSSFWorkbook workbook = new SXSSFWorkbook()){
        Sheet sheet = workbook.createSheet("Assigned Audit");
        ExcelUtils.createHeader(workbook, sheet, "EPS", 0, 1, 0, 9, 0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String summaryDate = sdf.format(new Date());
        ExcelUtils.historyTypeInfoRow(workbook, sheet, "Assigned Audit" + summaryDate, 2, 2,
                0, 9, 2);
        ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Id", "Audit Name", "Template Name", "User Name", "Site", "Site Code", "State",
                "City" , "Pin Code", "Status", "Updated On"));
        CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 3);
        ExcelUtils.createAndWriteRow(sheet, headerList, 3, cellStyle, true, workbook);

        int rowCount = 2;
        try {
            List<Ticket> ticketList = ticketRepository.findAll();
            cellStyle = ExcelUtils.createCellStyle(sheet, ++rowCount);
            for (Ticket ticket : ticketList) {
                    ArrayList<String> rowData = new ArrayList<>();
                    rowData.add(ticket.getTicketId() + "");
                    rowData.add(ticket.getAudit().getAuditName());
                    rowData.add(ticket.getAudit().getTemplate().getTemplateName());
                    rowData.add(ticket.getUsers().getSsoUsername());
                    rowData.add(ticket.getSite().getSiteName());
                    rowData.add(ticket.getSite().getSiteCode());
                    rowData.add(ticket.getSite().getState());
                    rowData.add(ticket.getSite().getCity());
                    rowData.add(ticket.getSite().getPincode());
                    rowData.add(ticket.getStatus());
                    rowData.add(dateFormat.format(ticket.getLastUpdatedDate()));
                    ExcelUtils.createAndWriteRow(sheet, rowData, ++rowCount, cellStyle, false, null);
            }
        } catch (Exception e) {
            log.error("Exception in writing sheet ", e);
            return null;
        }
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing Assigned Audit excel ", e);
            return null;
        }
    }

    public JSONObject deleteTicket(Integer ticketId) {
        JSONObject result = new JSONObject();
        try {
            Ticket getTicket = ticketRepository.findById(ticketId).get();
            if(getTicket != null){
            	List<TicketResponse> ticketResponses=ticketResponseRepository.findByTicketId(ticketId);
            	if(ticketResponses==null || ticketResponses.isEmpty()) {
            		ticketRepository.delete(getTicket);
            	}else {

                        ticketResponseRepository.deleteAll(ticketResponses);

                        ticketRepository.delete(getTicket);
            	}

                result.put("status" , 200);
                result.put("response", "ticket deleted successfully");
            } else {
                result.put("status", 302);
                result.put("response", "No Data Available");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public BufferedImage getBufferedImage(String path) throws IOException {
        String urlPath = Constants.imagesDir;
        String finalPath = urlPath+path;
        BufferedImage bufferedImage = ImageIO.read(new File(finalPath));
        return bufferedImage;
    }

    public JSONObject createAdhocTicket(Integer ticketId) {
        log.info(this.getClass().getName() + " :- createTicket()");
        JSONObject result = new JSONObject();
        try {
           Ticket ticket = ticketRepository.findById(ticketId).get();
           if(ticket == null) {
               result.put("status", 302);
               result.put("response", "Ticket is not found");
               return result;
           }
           Boolean isAdhocAllowedOrNot = ticketRepository.checkIsAdhocAllowed(ticketId);
           if(!isAdhocAllowedOrNot) {
        	   result.put("status", 302);
               result.put("response", "Can't assign this adhoc");
               return result;
           }
           Ticket checkPreviousTicket = ticketRepository.getPendingAdhocTicket(ticket.getAudit().getAuditId(),
                   ticket.getUsers().getUserId(),ticket.getSite().getSiteId());
            if (checkPreviousTicket != null){
                result.put("status", 302);
                result.put("response", "Please complete previous ADHOC Audit");
                return result;
            }
           Ticket createAdhocTicket = new Ticket();
           createAdhocTicket.setAudit(ticket.getAudit());
           createAdhocTicket.setUsers(ticket.getUsers());
           createAdhocTicket.setSite(ticket.getSite());
           createAdhocTicket.setIsAdhoc(true);
           createAdhocTicket.setIsDeleted(false);
           createAdhocTicket.setCreatedBy(ticket.getCreatedBy());
           createAdhocTicket.setUpdatedBy(ticket.getCreatedBy());
           createAdhocTicket.setCreatedDate(new Date());
           createAdhocTicket.setLastUpdatedDate(new Date());
           createAdhocTicket.setIsScheduledTicket(true);
           createAdhocTicket.setScheduleSiteId(ticket.getScheduleSiteId());
           createAdhocTicket.setStatus("PENDING");

           Ticket createdticket = ticketRepository.save(createAdhocTicket);
                if (createdticket != null) {
                    result.put("status", 200);
                    result.put("response", "AdhocTicket Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add adhocTicket");
                }

        } catch (Exception e) {

            log.error("Exception in createAdhocTicket for ticketId : {} and exception : {} ", ticketId, e.getMessage());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public ByteArrayInputStream downloadTicketByFilter(String fromDate,String toDate) {
        log.info(" writing ticket excel");
        try (SXSSFWorkbook workbook = new SXSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Assigned Audit");
            ExcelUtils.createHeader(workbook, sheet, "EPS", 0, 1, 0, 9, 0);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            String summaryDate = sdf.format(new Date());
            ExcelUtils.historyTypeInfoRow(workbook, sheet, "Assigned Audit" + summaryDate, 2, 2,
                    0, 9, 2);
            ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Id", "Audit Name","Audit Date", "Template Name", "User Name", "Site", "Site Code", "State",
                    "City", "Pin Code", "Status", "Updated On"));
            CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 3);
            ExcelUtils.createAndWriteRow(sheet, headerList, 3, cellStyle, true, workbook);

            int rowCount = 2;
            try {

                Date FromDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(fromDate);
                Date ToDate =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(toDate);


                List<Ticket> ticketList = ticketRepository.findByIsScheduledTicketAndLastUpdatedDateBetween(false,FromDate,ToDate);
                cellStyle = ExcelUtils.createCellStyle(sheet, ++rowCount);
                for (Ticket ticket : ticketList) {
                    ArrayList<String> rowData = new ArrayList<>();
                    rowData.add(ticket.getTicketId() + "");
                    rowData.add(ticket.getAudit().getAuditName());
                    rowData.add(new SimpleDateFormat("yyyy-MM-dd").format(ticket.getAudit().getCreatedDate()));
                    rowData.add(ticket.getAudit().getTemplate().getTemplateName());
                    rowData.add(ticket.getUsers().getUserName());
                    rowData.add(ticket.getSite().getSiteName());
                    rowData.add(ticket.getSite().getSiteCode());
                    rowData.add(ticket.getSite().getState());
                    rowData.add(ticket.getSite().getCity());
                    rowData.add(ticket.getSite().getPincode());
                    rowData.add(ticket.getStatus());

                    rowData.add(dateFormat.format(ticket.getLastUpdatedDate()));

                    ExcelUtils.createAndWriteRow(sheet, rowData, ++rowCount, cellStyle, false, null);
                }
            } catch (Exception e) {
                log.error("Exception in writing sheet ", e);
                return null;
            }
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing Assigned Audit excel ", e);
            return null;
        }
    }
    public JSONObject findAllTicketPaginatedByFilter(int page, int size,String fromDate,String toDate) {
        JSONObject result = new JSONObject();
        try {

            Date FromDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(fromDate);
            Date ToDate =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(toDate);

            Pageable paging = PageRequest.of(page, size);
            Page<Ticket> pages = ticketRepository.findAllByIsDeletedAndIsScheduledTicketAndLastUpdatedDateBetween(false,false, paging,FromDate,
                    ToDate);
            if (pages != null && !pages.getContent().isEmpty()) {
                result.put("status", 200);
                result.put("content", pages.getContent());
                for (Ticket ticket : pages.getContent()) {
                	if (ticket.getAudit().getTemplate().getTemplateId().equals(37)) {
                		ticket.setIsCashAudit(true);
                	} else {
                		ticket.setIsCashAudit(false);
                	}
                }
                result.put("totalPages", pages.getTotalPages());
                result.put("totalElements", pages.getTotalElements());
                result.put("numberOfElements", pages.getNumberOfElements());
                result.put("size", pages.getSize());
                result.put("number", pages.getNumber());
            } else {
                result.put("status", 302);
                result.put("response", "No Data Available");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public ByteArrayInputStream downloadTicketByFilterScheduled(String fromDate, String toDate,Integer userId,Integer siteId,String type) {
        log.info(" writing ticket excel");
        try (SXSSFWorkbook workbook = new SXSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Assigned Audit");
            ExcelUtils.createHeader(workbook, sheet, "EPS", 0, 1, 0, 9, 0);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            String summaryDate = sdf.format(new Date());
            ExcelUtils.historyTypeInfoRow(workbook, sheet, "Assigned Audit" + summaryDate, 2, 2,
                    0, 9, 2);
            ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Id", "Audit Name","Audit Date", "Template Name", "User Name", "Site", "Site Code", "State",
                    "City", "Pin Code", "Status", "Updated On"));
            CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 3);
            ExcelUtils.createAndWriteRow(sheet, headerList, 3, cellStyle, true, workbook);

            int rowCount = 2;
            try {

                Date FromDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(fromDate);
                Date ToDate =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(toDate);

                List<Ticket> ticketList = null;
                if(type == null || type.isEmpty() || type.equals("ALL")){
                    ticketList = ticketRepository.findByIsScheduledTicket(userId,siteId,null,FromDate,ToDate);
                }else
                if(type == "ADHOC" || type.equals("ADHOC")) {
                    ticketList = ticketRepository.findByIsScheduledTicket(userId,siteId,true,FromDate,ToDate);

                }
                else if(type == "NON-ADHOC" || type.equals("NON-ADHOC")){
                    ticketList = ticketRepository.findByIsScheduledTicket(userId,siteId,false,FromDate,ToDate);
                }
                cellStyle = ExcelUtils.createCellStyle(sheet, ++rowCount);
                for (Ticket ticket : ticketList) {
                    ArrayList<String> rowData = new ArrayList<>();
                    rowData.add(ticket.getTicketId() + "");
                    rowData.add(ticket.getAudit().getAuditName());
                    rowData.add(new SimpleDateFormat("yyyy-MM-dd").format(ticket.getAudit().getCreatedDate()));
                    rowData.add(ticket.getAudit().getTemplate().getTemplateName());
                    rowData.add(ticket.getUsers().getUserName());
                    rowData.add(ticket.getSite().getSiteName());
                    rowData.add(ticket.getSite().getSiteCode());
                    rowData.add(ticket.getSite().getState());
                    rowData.add(ticket.getSite().getCity());
                    rowData.add(ticket.getSite().getPincode());
                    rowData.add(ticket.getStatus());

                    rowData.add(dateFormat.format(ticket.getLastUpdatedDate()));

                    ExcelUtils.createAndWriteRow(sheet, rowData, ++rowCount, cellStyle, false, null);
                }
            } catch (Exception e) {
                log.error("Exception in writing sheet ", e);
                return null;
            }
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing Assigned Audit excel ", e);
            return null;
        }
    }
    public JSONObject findAllTicketPaginatedByFilterScheduled(int page, int size,String fromDate,String toDate,Integer userId,String siteCode,String type) {
        JSONObject result = new JSONObject();
        try {

            Date FromDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(fromDate);
            Date ToDate =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(toDate);

            Pageable paging = PageRequest.of(page, size);
            Page<Ticket> pages = null;

            if(type == null || type.isEmpty()) {
                pages = ticketRepository.findAllByTicketFiltersWithoutType(false, true, paging, userId, siteCode,FromDate,
                        ToDate);
            }
            else{
                if(type.equals("ADHOC")) {
                    pages = ticketRepository.findAllByTicketFiltersWithType(false, true, paging, userId, siteCode, true, FromDate,
                            ToDate);
                }
                else if(type.equals("NON-ADHOC")){
                    pages = ticketRepository.findAllByTicketFiltersWithType(false, true, paging, userId, siteCode, false, FromDate,
                            ToDate);
                }
            }

            if (pages != null && !pages.getContent().isEmpty()) {
                result.put("status", 200);
                result.put("content", pages.getContent());
                result.put("totalPages", pages.getTotalPages());
                result.put("totalElements", pages.getTotalElements());
                result.put("numberOfElements", pages.getNumberOfElements());
                result.put("size", pages.getSize());
                result.put("number", pages.getNumber());
            } else {
                result.put("status", 302);
                result.put("response", "No Data Available");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject searchTicketScheduled(String searchTerm) {
        JSONObject result = new JSONObject();
        try {
            List<Ticket> list = ticketRepository.searchTicketScheduled(searchTerm);
            if(list != null && !list.isEmpty()){
                result.put("status" , 200);
                result.put("response", list);
            } else {
                result.put("status", 302);
                result.put("response", "No Data Available");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject changeAuditorForScheduledTicket(Integer ticketId, Integer userId) {
        JSONObject result = new JSONObject();
        try{
           Ticket ticket = ticketRepository.findById(ticketId).orElse(null);
           if(ticket == null){
               result.put("status", 302);
               result.put("response", "Ticket not found");
               return result;
           }
           if(!ticket.getIsScheduledTicket()){
                result.put("status", 302);
                result.put("response", "Audit for this ticket is not scheduled.");
               return result;

           }
           if(!ticket.getStatus().equalsIgnoreCase("PENDING")){
               result.put("status", 302);
               result.put("response", "Ticket is in progress or already completed.");
               return result;

           }
           Users users = usersRepository.findById(userId).get();
           if(users == null){
               result.put("status", 302);
               result.put("response", "User not found.");
               return result;

           }
           ticket.setUsers(users);
           ticket.setLastUpdatedDate(new Date());
           ticket.setUpdatedBy(1);
           Ticket updatedTicket = ticketRepository.save(ticket);
           result.put("status",200);
           result.put("response",updatedTicket);
           result.put("message","Change audit for this ticket successfully.");
        }
        catch(Exception e){
            e.printStackTrace();

        }
        return result;
    }


}
