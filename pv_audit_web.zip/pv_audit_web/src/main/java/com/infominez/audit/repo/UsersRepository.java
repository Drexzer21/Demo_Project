package com.infominez.audit.repo;

import com.infominez.audit.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UsersRepository extends JpaRepository<Users, Integer> {
    Users findByUserName(String userName);

    Users findBySsoUsername(String ssoUsername);
    Users findByEmailId(String emailId);
    
    
    
    @Query(value = "select * from users where sso_username is not null",
            nativeQuery = true)
    List<Users> getAllUsers();

}
