
package com.infominez.audit.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;
import org.json.simple.JSONObject;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "ticket" )
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = false)
@Proxy(lazy = false)
public class Ticket implements Serializable {
    private static final Long serialVersionUID = 1L;

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ticket_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer ticketId;

    @JoinColumn(name = "audit_id")
    @ManyToOne(fetch = FetchType.LAZY)
    @Basic(optional = false)
    private Audit audit;

    @JoinColumn(name = "user_id")
    @ManyToOne(fetch = FetchType.LAZY)
    @Basic(optional = false)
    private Users users;

    @JoinColumn(name = "site_id")
    @ManyToOne(fetch = FetchType.LAZY)
    @Basic(optional = false)
    private Site site;

    @JsonIgnore
    @Column(name = "created_by")
    private Integer createdBy;

    @JsonIgnore
    @Column(name = "updated_by")
    private Integer updatedBy;

    @Basic(optional = false)
    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Basic(optional = false)
    @Column(name = "last_updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDate;

    @Basic(optional = false)
    @Column(name = "status")
    private String status;

    @Column(name = "is_deleted")
    private Boolean isDeleted;

    @Column(name = "is_adhoc")
    private Boolean isAdhoc;

    @Column(name = "is_scheduled_ticket")
    private Boolean isScheduledTicket;


    @Transient
    private Object ticketData;
    
    @Transient
	private Boolean isCashAudit;
    
    @Column(name = "is_select_for_offline")
    private Boolean isSelectForOffline;
    
    @Column(name = "schedule_site_id")
    private Integer scheduleSiteId;
    
    @Transient
	private Boolean isShowAdhocButton;

}


