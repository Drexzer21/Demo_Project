package com.infominez.audit.controller;

import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.service.QuestionTypeService;
import com.infominez.audit.wrapper.BaseResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("/questionType")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class QuestionTypeController {

    private final QuestionTypeService questionTypeService;

    @RequestMapping( value = "/**", method = RequestMethod.OPTIONS)
    public ResponseEntity handle() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping( "/createQuestionType")
    public JSONObject createQuestionType(@RequestBody QuestionType questionType){
        return questionTypeService.createQuestionType(questionType);
    }

    @PostMapping( "/updateQuestionType")
    public JSONObject updateQuestionType(@RequestBody QuestionType questionType){
        log.info(this.getClass().getName() + " :- updateQuestionType");
        return questionTypeService.updateQuestionType(questionType);
    }

    @GetMapping( "/getAllQuestionType")
    public JSONObject findAllQuestionType(){
        log.info(this.getClass().getName() + " :- findAllQuestionType");
        return questionTypeService.findAllQuestionType();
    }

    @GetMapping( "/getquestionTypeById/{id}")
    public JSONObject findQuestionTypeById(@PathVariable("id") Integer questonTypeId, HttpServletRequest request,
                                             HttpServletResponse response){
        log.info(this.getClass().getName() + " :- findQuestionTypeById");
        return questionTypeService.findQuestionTypeById(questonTypeId);
    }




}
