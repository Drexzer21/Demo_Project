package com.infominez.audit.entity;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
public class EmailAuthenticator extends Authenticator {

	 String username = "epstar_notifications@epsho.electronicpay.in";

	 String password = "Asdf@1100";
	 public EmailAuthenticator() {
	        super();
	    }

	    public EmailAuthenticator(String user, String pwd) {
	        super();
	        username = user;
	        password = pwd;
	    }

	    public PasswordAuthentication getPasswordAuthentication() {
	        return new PasswordAuthentication(username, password);
	    }
}
