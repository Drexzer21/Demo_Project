package com.infominez.audit.service;
import com.infominez.audit.entity.*;
import com.infominez.audit.repo.*;
import com.infominez.audit.utils.AppConfiguration;
import com.infominez.audit.utils.ConnPool;
import com.infominez.audit.utils.EnumUtils;
import com.infominez.audit.utils.ExcelUtils;
import com.infominez.audit.utils.FileUtils;
import com.infominez.audit.utils.Utils;
import com.infominez.audit.wrapper.AuditReport;
import com.infominez.audit.wrapper.UserAuditScheduleWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class UserAuditScheduleService {
	private final AppConfiguration appConfig;
    private final UserAuditScheduleRepository userAuditScheduleRepository;
    private final ScheduleSiteRepository scheduleSiteRepository;
    private final TemplateRepository templateRepository;
    private final UsersRepository usersRepository;
    private final SiteRepository siteRepository;
    private final MailService mailService;


    public JSONObject createUserAuditSchedule(UserAuditSchedule userAuditSchedule) {
        log.info(this.getClass().getName() + " :- createUserAuditSchedule()");
        JSONObject result = new JSONObject();
        try {

            Date date = new Date();
            userAuditSchedule.setCreatedBy(1); // todo change when login is implemented
            userAuditSchedule.setUpdatedBy(1); // todo change when login is implemented
            userAuditSchedule.setCreatedDate(date);
            userAuditSchedule.setUpdatedDate(date);
            UserAuditSchedule createUserAuditSchedule = userAuditScheduleRepository.save(userAuditSchedule);
            if (createUserAuditSchedule != null) {
                result.put("status", 200);
                result.put("response", "UserAuditSchedule Added Successfully");
            } else {
                result.put("status", 302);
                result.put("response", "Unable to add UserAuditSchedule");
            }

        } catch (Exception e) {

            log.error("Exception in createUserAuditSchedule for UserAuditSchedule : {} and exception : {} ",
                    userAuditSchedule.toString(), e.getMessage());
            log.trace("Exception in createUserAuditSchedule for UserAuditSchedule : {} and trace : {} ",
                    userAuditSchedule.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject updateUserAuditSchedule(UserAuditScheduleWrapper userAuditScheduleWrapper,
                                              int userId) {
        log.info(this.getClass().getName() + " :- updateUserAuditSchedule()");
        JSONObject result = new JSONObject();
        try {
            UserAuditSchedule userAuditScheduleUpdate = userAuditScheduleRepository
                    .findById(userAuditScheduleWrapper.getUserAuditScheduleId()).get();
            if (userAuditScheduleUpdate != null) {
                if (userAuditScheduleWrapper.getTemplateId() != null) {
                    Template template = templateRepository.findById(userAuditScheduleWrapper.getTemplateId()).get();
                    userAuditScheduleUpdate.setTemplate(template);
                }
                if (userAuditScheduleWrapper.getUsersId() != null) {
                    Users users = usersRepository.findById(userAuditScheduleWrapper.getUsersId()).get();
                    userAuditScheduleUpdate.setUser(users);
                }

                if (userAuditScheduleWrapper.getSiteList() != null && !userAuditScheduleWrapper.getSiteList().isEmpty()) {
                    List<ScheduleSite> toBeInserted = new ArrayList<>();
                    for (Site site : userAuditScheduleWrapper.getSiteList()) {
                        List<ScheduleSite> scheduleSite = scheduleSiteRepository.findByUserAuditSchedule(userAuditScheduleUpdate);
                        if (scheduleSite != null && !scheduleSite.isEmpty()) {
                            scheduleSiteRepository.deleteAll(scheduleSite);
                        }
                        ScheduleSite newScheduleSite = new ScheduleSite();
                        newScheduleSite.setSite(site);
                        newScheduleSite.setUserAuditSchedule(userAuditScheduleUpdate);
                        toBeInserted.add(newScheduleSite);
                    }
                    scheduleSiteRepository.saveAll(toBeInserted);
                }

                userAuditScheduleUpdate.setUpdatedDate(new Date());
                userAuditScheduleUpdate.setUpdatedBy(userId);
                userAuditScheduleRepository.save(userAuditScheduleUpdate);
                result.put("status", 200);
                result.put("response", " UserAuditSchedule Updated Successfully");
            } else {
                result.put("status", 302);
                result.put("response", "Unable to Update UserAuditSchedule");
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in updateUserAuditSchedule for UserAuditSchedule : {} and exception : {} ",
                    userAuditScheduleWrapper.toString(), e.getMessage());
            log.trace("Exception in updateUserAuditSchedule for UserAuditSchedule : {} and trace : {} ",
                    userAuditScheduleWrapper.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;

    }

    public JSONObject getUserAuditScheduleById(Integer id) {
        log.info(this.getClass().getName() + " :- findUserAuditScheduleById()");
        JSONObject result = new JSONObject();
        try {
            UserAuditSchedule userAuditSchedule = userAuditScheduleRepository.findById(id).get();
            if (userAuditSchedule != null) {
                result.put("status", 200);
                result.put("response", userAuditSchedule);
            } else {
                result.put("status", 302);
                result.put("response", "UserAuditSchedule Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findUserAuditScheduleById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findUserAuditScheduleById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getAllUserAuditSchedule() {
        log.info(this.getClass().getName() + " :- findAllUserAuditSchedule()");
        JSONObject result = new JSONObject();
        try {
            List<UserAuditSchedule> userAuditSchedule = userAuditScheduleRepository.findAll();
            if (userAuditSchedule != null) {
                result.put("status", 200);
                result.put("response", userAuditSchedule);
            } else {
                result.put("status", 302);
                result.put("response", "UserAuditSchedule Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllUserAuditSchedule for id : {} and exception : {} ", e.getMessage());
            log.trace("Exception in findAllUserAuditSchedule for id : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject deleteUserAuditSchedule(Integer userAuditScheduleId) {
        log.info(this.getClass().getName() + " :- deleteUserAuditSchedule()", userAuditScheduleId);
        JSONObject result = new JSONObject();
        try {
            UserAuditSchedule getUserAuditSchedule = userAuditScheduleRepository.findById(userAuditScheduleId).orElse(null);
            if (getUserAuditSchedule != null) {
                List<ScheduleSite> scheduleSite = scheduleSiteRepository.findByUserAuditSchedule(getUserAuditSchedule);
                if (scheduleSite != null && !scheduleSite.isEmpty()) {
                    scheduleSiteRepository.deleteAll(scheduleSite);
                }

                userAuditScheduleRepository.delete(getUserAuditSchedule);
                result.put("status", 200);
                result.put("response", "UserAuditSchedule deleted sucessfully");
            } else {
                result.put("status", 302);
                result.put("response", "UserAuditSchedule Not found");
            }
        } catch (Exception e) {
            log.error("Exception in deleteUserAuditSchedule for id : {} and exception : {} ", e.getMessage());
            log.trace("Exception in deleteUserAuditSchedule for id : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getAllUserAuditSchedulePageable(int page, int size) {
        log.info(this.getClass().getName() + " :- getAllUserAuditSchedulePageable()", page, size);

        JSONObject result = new JSONObject();
        try {
            Pageable paging = PageRequest.of(page, size);
            Page<UserAuditSchedule> pages = userAuditScheduleRepository.findAll(paging);

            if (pages != null && !pages.isEmpty()) {

                result.put("content", pages.getContent());
                result.put("totalPages", pages.getTotalPages());
                result.put("totalElements", pages.getTotalElements());
                result.put("numberOfElements", pages.getNumberOfElements());
                result.put("size", pages.getSize());
                result.put("number", pages.getNumber());

                result.put("status", 200);
                result.put("response", result);

            } else {
                result.put("status", 302);
                result.put("response", "UserAuditSchedule Not found");
            }

        } catch (Exception e) {

            log.error("Exception in getAllUserAuditSchedulePageable() userAuditSchedule : {}, Exception : {}", page,
                    size, e.getMessage());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject createUserAuditScheduleWithScheduleSite(UserAuditScheduleWrapper userAuditScheduleWrapper,
                                                              int userId) {
        log.info(this.getClass().getName() + " :- createUserAuditScheduleWithScheduleSite()", userAuditScheduleWrapper,
                userId);

        JSONObject result = new JSONObject();
        try {
            if (userAuditScheduleWrapper == null) {
                result.put("status", 302);
                result.put("response", "Invalid Request");
                return result;
            }
            if (userAuditScheduleWrapper.getTemplateId() == null) {
                result.put("status", 302);
                result.put("response", "template is required");
                return result;
            }

            if (userAuditScheduleWrapper.getUsersId() == null) {
                result.put("status", 302);
                result.put("response", "user is required");
                return result;
            }
            if (userAuditScheduleWrapper.getSiteList().isEmpty()) {
                result.put("status", 302);
                result.put("response", "site is required");
                return result;
            }
            if(userAuditScheduleWrapper.getVisitType()==null && userAuditScheduleWrapper.getVisitType().isEmpty()){
                result.put("status", 302);
                result.put("response", "Visit Type is required.");
                return result;
            }
            if(userAuditScheduleWrapper.getNoOfVisit()==null){
                result.put("status", 302);
                result.put("response", "No. of visit is required.");
                return result;
            }
            if(userAuditScheduleWrapper.getStartDate()==null){
                result.put("status", 302);
                result.put("response", "Visit start date is required.");
                return result;
            }
            if(userAuditScheduleWrapper.getEndDate()==null){
                result.put("status", 302);
                result.put("response", "Visit end date is required.");
                return result;
            }

                if(userAuditScheduleWrapper.getVisitType().equalsIgnoreCase(String.valueOf(EnumUtils.visitType.MONTHLY))||
                   userAuditScheduleWrapper.getVisitType().equalsIgnoreCase(String.valueOf(EnumUtils.visitType.FORTNIGHTLY))){

                    if(userAuditScheduleWrapper.getNoOfVisit() != 1){
                        result.put("status", 302);
                        result.put("response", "No. of visit for monthly or fornightly visit type should be 1.");
                        return result;
                    }
                }if(userAuditScheduleWrapper.getVisitType().equalsIgnoreCase(String.valueOf(EnumUtils.visitType.WEEKLY))){
                    if(userAuditScheduleWrapper.getNoOfVisit() != 1 && userAuditScheduleWrapper.getNoOfVisit() != 2 && userAuditScheduleWrapper.getNoOfVisit() != 4 && userAuditScheduleWrapper.getNoOfVisit() != 6){
                        result.put("status", 302);
                        result.put("response", "No. of visit for weekly visit should be any from 1,2,4,6");
                        return result;
                    }
                }
            String startDate = Utils.getStringFromString(userAuditScheduleWrapper.getStartDate());
            String endDate = Utils.getStringFromString(userAuditScheduleWrapper.getEndDate());
            Date startDate1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startDate);
            Date endDate1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endDate);
            if(!startDate1.before(endDate1) && (!startDate1.after(new Date()) || !startDate1.equals(new Date()))){
                    result.put("status", 302);
                    result.put("response", "Please select correct start date");
                    return result;
                }
            Date date = new Date();
            UserAuditSchedule userAuditSchedule = new UserAuditSchedule();
            if (userAuditScheduleWrapper.getTemplateId() != null) {
                Template template = templateRepository.findById(userAuditScheduleWrapper.getTemplateId()).get();
                userAuditSchedule.setTemplate(template);
            }
            if (userAuditScheduleWrapper.getUsersId() != null) {
                Users users = usersRepository.findById(userAuditScheduleWrapper.getUsersId()).get();
                userAuditSchedule.setUser(users);
            }
            userAuditSchedule.setCreatedBy(userId);
            userAuditSchedule.setUpdatedBy(userId);
            userAuditSchedule.setCreatedDate(date);
            userAuditSchedule.setUpdatedDate(date);
            UserAuditSchedule savedUserAuditSchedule = userAuditScheduleRepository.save(userAuditSchedule);
            List<ScheduleSite> tobeInsert = new ArrayList<>();
            if (savedUserAuditSchedule != null) {
                for (Site site : userAuditScheduleWrapper.getSiteList()) {
                    ScheduleSite scheduleSite = new ScheduleSite();
                    scheduleSite.setUserAuditSchedule(savedUserAuditSchedule);
                    scheduleSite.setSite(site);
                    scheduleSite.setVisitType(EnumUtils.visitType.valueOf(userAuditScheduleWrapper.getVisitType()));
                    scheduleSite.setNoOfVisit(userAuditScheduleWrapper.getNoOfVisit());
                    scheduleSite.setStartDate(startDate1);
                    scheduleSite.setEndDate(endDate1);
                    tobeInsert.add(scheduleSite);

                }

                List<ScheduleSite> scheduleSites = scheduleSiteRepository.saveAll(tobeInsert);
                if (scheduleSites != null && !scheduleSites.isEmpty()) {
                    result.put("status", 200);
                    result.put("response", "User Audit scheduled created successfully");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in createUserAuditScheduleWithScheduleSite() userAuditSchedule : {} , userId : {}, Exception : {}",
                    userAuditScheduleWrapper.toString(), userId, e.getMessage());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllUserAuditSchedule() {
        log.info(this.getClass().getName() + " :- findAllUserAuditSchedule()");
        JSONObject response = new JSONObject();
        JSONArray array = new JSONArray();
        try {
            List<Object[]> getUserAuditSchedule = userAuditScheduleRepository.findAllUserAuditSchedule();
            if (getUserAuditSchedule != null) {
                for (Object[] obj : getUserAuditSchedule) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("userAuditScheduleId", obj[0]);
                    jsonObject.put("userId", obj[1]);
                    jsonObject.put("userName", obj[2]);
                    jsonObject.put("emailId", obj[3]);
                    jsonObject.put("templateId", obj[4]);
                    jsonObject.put("templateName", obj[5]);
                    array.add(jsonObject);

                }
                response.put("status", 200);
                response.put("message", "SUCCESS");
                response.put("response", array);
            } else {
                response.put("status", 302);
                response.put("message", "No Audit Schedule");
                response.put("response", "No Audit Schedule");
            }

        } catch (Exception e) {
            log.error("Exception in findAllUserAuditSchedule() userAuditSchedule Exception : {}", e.getMessage());
            response.put("status", 500);
            response.put("message", "Internal Server Error");
            response.put("response", "Internal Server Error");
        }
        return response;
    }

    public JSONObject bulkDeleteScheduleSite(List<ScheduleSite> scheduleSites) {
        log.info(this.getClass().getName() + " :- bulkDeleteScheduleSite()", scheduleSites);
        JSONObject result = new JSONObject();
        try {
            List<ScheduleSite> tobeDeleted = new ArrayList<>();
            if (scheduleSites != null && !scheduleSites.isEmpty()) {
                for (ScheduleSite site : scheduleSites) {
                    ScheduleSite scheduleSite = scheduleSiteRepository.findScheduleSiteById(site.getScheduleSiteId());
                    if (scheduleSite != null) {
                        tobeDeleted.add(scheduleSite);
                    }
                }
                if (tobeDeleted != null && !tobeDeleted.isEmpty()) {
                    scheduleSiteRepository.deleteInBatch(tobeDeleted);
                    result.put("status", 200);
                    result.put("response", "ScheduleSite deleted sucessfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Nothing to Delete");
                }

            } else {
                result.put("status", 302);
                result.put("response", "invalid request");
                return result;
            }
        } catch (Exception e) {
            log.error("Exception in bulkDeleteScheduleSite for id : {} and exception : {} ", scheduleSites, e.getMessage());
            log.trace("Exception in bulkDeleteScheduleSite for id : {} and trace : {} ", scheduleSites, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getScheduleDetails(Integer id) {
        JSONObject result = new JSONObject();
        try {
            List<Object[]> userAuditSchedule = userAuditScheduleRepository.findByUserAuditSchedule(id);
            if (userAuditSchedule != null && !userAuditSchedule.isEmpty()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("userAuditScheduleId", userAuditSchedule.get(0)[0]);
                jsonObject.put("userId", userAuditSchedule.get(0)[1]);
                jsonObject.put("userName", userAuditSchedule.get(0)[2]);
                jsonObject.put("emailId", userAuditSchedule.get(0)[3]);
                jsonObject.put("templateId", userAuditSchedule.get(0)[4]);
                jsonObject.put("templateName", userAuditSchedule.get(0)[5]);

                List<Object[]> getScheduleSite = scheduleSiteRepository.FindScheduleSiteByUserAuditSchedule(id);
                List<JSONObject> array = new ArrayList<>();
                if (getScheduleSite != null) {
                    for (Object[] obj : getScheduleSite) {
                        JSONObject site = new JSONObject();
                        site.put("scheduleSiteId", obj[0]);
                        site.put("siteId", obj[1]);
                        site.put("siteName", obj[2]);
                        site.put("siteCode", obj[3]);
                        site.put("state", obj[4]);
                        site.put("city", obj[5]);
                        site.put("address", obj[6]);
                        site.put("pincode", obj[7]);
                        array.add(site);
                    }
                }
                jsonObject.put("scheduleSiteList", array);
                result.put("status", 200);
                result.put("response", jsonObject);

            } else {
                result.put("status", 302);
                result.put("response", "Schedule Details not found");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject getListOfUserScheduled() {
        log.info(this.getClass().getName() + " :- getListOfUserScheduled()");
        JSONObject response = new JSONObject();
        try{
            JSONArray jsonArray = new JSONArray();
            List<Object[]> userList = userAuditScheduleRepository.getListOfUserScheduled();
            if (userList != null && userList.size() > 0) {
                for (Object[] obj : userList) {
                    JSONObject object = new JSONObject();
                    object.put("userId", obj[0]);
                    object.put("username", obj[1]);
                    object.put("emailId", obj[2]);
                    object.put("firstName", obj[3]);
                    object.put("lastName", obj[4]);
                    jsonArray.add(object);
                }
                response.put("status",200);
                response.put("message","SUCCESS");
                response.put("response",jsonArray);
            }
        }
        catch(Exception e){
            e.printStackTrace();
            log.error("Exception in getListOfUserScheduled() , exception : {} ", e.getMessage());
            response.put("status", 500);
            response.put("response", "Internal Server Error");
        }
        return response;
    }
    private String getCellValue(Cell cell) {
        return new DataFormatter().formatCellValue(cell);
    }

    public JSONObject bulkUploadForAuditScheduling(InputStream inputStream) {
        log.info("Bulk Upload for Audit Scheduling");
        JSONObject result = new JSONObject();
        try {
           Map<String,Users> userMap = new HashMap<>();
            Map<String,Site> siteMap = new HashMap<>();
            Map<String,Template> templateMap = new HashMap<>();
            List<Users> userList = usersRepository.findAll();
            if (userList != null) {
                 userMap = userList.stream().collect(
                        Collectors.toMap(Users::getEmailId, Users::getClassObject));
            }
            List<Site> siteList = siteRepository.findAll();
            if (siteList != null) {
                siteMap = siteList.stream().collect(
                        Collectors.toMap(Site::getSiteCode, Site::getClassObject));
            }
            List<Template> templateList = templateRepository.findAll();
            if (templateList != null) {
                templateMap = templateList.stream().collect(
                        Collectors.toMap(Template::getTemplateName, Template::getClassObject));
            }
                List<UserAuditSchedule> tobeInsertUserAuditSchedule = new ArrayList<>();
                List<Object[]> userAuditScheduleFromExcel = new ArrayList<>();

            Workbook wb = WorkbookFactory.create(inputStream);
            Sheet sheet = wb.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = (Row) rowIterator.next();
                Object[] obj = new Object[7];

                if (row.getRowNum() > 0 && !getCellValue(row.getCell(0)).equals("")) {
                    obj[0] = getCellValue(row.getCell(0));
                    obj[1] = getCellValue(row.getCell(1));
                    obj[2] = getCellValue(row.getCell(2));
//                    obj[3] = row.getCell(3).getDateCellValue();
//                    obj[4] = row.getCell(4).getDateCellValue();
                    obj[3] = getCellValue(row.getCell(3));
                    obj[4] = getCellValue(row.getCell(4));
                    obj[5] = getCellValue(row.getCell(5));
                    obj[6] = getCellValue(row.getCell(6));
                    userAuditScheduleFromExcel.add(obj);
                }
            }
            JSONArray jsonArray = new JSONArray();
            for (Object[] obj : userAuditScheduleFromExcel) {
                String email = String.valueOf(obj[0]);
                String template = String.valueOf(obj[1]);
                String siteCode = String.valueOf(obj[2]);
                String startDate = String.valueOf(obj[3]);
                String endDate = String.valueOf(obj[4]);
                Integer noOfVisit = Integer.parseInt(String.valueOf(obj[5]));
                String visitType = String.valueOf(obj[6]);

                Users user = userMap.get(email);
                if (user == null) {
                    JSONObject jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                    jsonObject.put("message", "User not found for this email id.");
                    jsonArray.add(jsonObject);
                    continue;
                }

                Template template1 = templateMap.get(template);
                if (template1 == null) {
                    JSONObject jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                    jsonObject.put("message", "Template not found.");
                    jsonArray.add(jsonObject);
                    continue;

                }

                Site site = siteMap.get(siteCode);
                if (site == null) {
                    JSONObject jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                    jsonObject.put("message", "Site not found.");
                    jsonArray.add(jsonObject);
                    continue;

                }
                if (EnumUtils.visitType.MONTHLY.name().equals(visitType) || EnumUtils.visitType.FORTNIGHTLY.name().equals(visitType)) {
                    if (noOfVisit != 1) {
                        JSONObject  jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                        jsonObject.put("message", "No. of visit for this visit type should be one.");
                        jsonArray.add(jsonObject);
                        continue;

                    }
                }
                if (EnumUtils.visitType.WEEKLY.name().equals(visitType)) {
                    if (noOfVisit != 1 && noOfVisit != 2 && noOfVisit != 4 && noOfVisit != 6) {
                        JSONObject jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                        jsonObject.put("message", "No. of visit for this visit type should be any of 1,2,4,6");
                        jsonArray.add(jsonObject);
                        continue;

                    }
                }

                startDate = Utils.getStringFromString(startDate);
                endDate = Utils.getStringFromString(endDate);
                DateFormat formatTo = new SimpleDateFormat("yyyy-MM-dd");
//                DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
//                Date date1 = (Date) formatter.parse(startDate);
//                Date date2 = (Date) formatter.parse(endDate);
//                String stDate1 = formatTo.format(date1);
//                Date startDate1 = formatTo.parse(stDate1);
//                String edDate1 = formatTo.format(date2);
//                Date endDate1 = formatTo.parse(edDate1);
                Date startDate1 = null;
                Date endDate1 = null;
                try{
                  startDate1 = formatTo.parse(startDate);
                  endDate1 = formatTo.parse(endDate);
                if (!startDate1.before(endDate1) && (!startDate1.after(new Date()) || !startDate1.equals(new Date()))) {
                    JSONObject jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                    jsonObject.put("message", "Invalid start date");
                    jsonArray.add(jsonObject);
                    continue;
                }
                }catch (Exception e){
                    e.printStackTrace();
                    JSONObject jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                    jsonObject.put("message", "Invalid date format should be yyyy-MM-dd in Text type");
                    jsonArray.add(jsonObject);
                    continue;
                }
                    UserAuditSchedule userAuditSchedule = null;
//                    userAuditSchedule = userAuditScheduleRepository.findUserAuditSchedule(user.getUserId(), template1.getTemplateId(), site.getSiteId(), visitType, startDate1, endDate1);
                    List<Object[]> scheduleSiteList = scheduleSiteRepository.checkScheduledSites(user.getUserId(), template1.getTemplateId(), site.getSiteId(), visitType, startDate, endDate, noOfVisit);
                    if (scheduleSiteList != null && !scheduleSiteList.isEmpty()) {
                        JSONObject  jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, false);
                        jsonObject.put("message", "Audit is already scheduled for this user with same data.");
                        jsonArray.add(jsonObject);
                        continue;

                    }

                        userAuditSchedule = new UserAuditSchedule();
                        userAuditSchedule.setUser(user);
                        userAuditSchedule.setTemplate(template1);
                        userAuditSchedule.setCreatedDate(new Date());
                        userAuditSchedule.setUpdatedDate(new Date());
                        userAuditSchedule.setCreatedBy(1);
                        userAuditSchedule.setUpdatedBy(1);
//
                        UserAuditSchedule created = userAuditScheduleRepository.save(userAuditSchedule);
                        ScheduleSite scheduleSite = new ScheduleSite();
                        scheduleSite.setSite(site);
                        scheduleSite.setUserAuditSchedule(created);
                        scheduleSite.setVisitType(EnumUtils.visitType.valueOf(visitType));
                        scheduleSite.setNoOfVisit(noOfVisit);
                        scheduleSite.setStartDate(startDate1);
                        scheduleSite.setEndDate(endDate1);
                        scheduleSiteRepository.save(scheduleSite);
                        tobeInsertUserAuditSchedule.add(created);
                JSONObject  jsonObject = getJsonObject(email, template, siteCode, startDate, endDate, noOfVisit, visitType, true);
                jsonObject.put("message", "SUCCESS");
                jsonArray.add(jsonObject);

            }
            if (tobeInsertUserAuditSchedule.size() > 0 && !tobeInsertUserAuditSchedule.isEmpty()) {
                result.put("status", 200);
                result.put("message", "Bulk Upload for User Schedule Site Successfully.");
                result.put("response", (jsonArray));
            } else {
                result.put("status", 304);
                result.put("message", "Bulk Upload failed.");
                result.put("response", jsonArray);
            }
            userMap.remove(userList);
            siteMap.remove(siteList);
            templateMap.remove(templateList);
        }
        catch (Exception e) {
            e.printStackTrace();
            log.error("Exception occur in bulkUploadForAuditScheduling(): {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    private JSONObject getJsonObject(String email, String template, String siteCode, String startDate, String endDate, Integer noOfVisit, String visitType, boolean isSuccess) {
        JSONObject jsonObject;
        jsonObject = new JSONObject();
        jsonObject.put("email", email);
        jsonObject.put("template", template);
        jsonObject.put("siteCode", siteCode);
        jsonObject.put("startDate", startDate);
        jsonObject.put("endDate", endDate);
        jsonObject.put("noOfVisit", noOfVisit);
        jsonObject.put("visitType", visitType);
        jsonObject.put("isSuccess", isSuccess);
        return jsonObject;
    }

	public String getScheduledAuditReportForAdmin() {
		log.info("getScheduledAuditReportForAdmin()");
		String filePath = appConfig.getProperty("app.excelDir");
		String filePathStatic = "ScheduledAuditReportForAdmin" + "//";
		String excelFilePath = filePath + filePathStatic;
		File directory = new File(excelFilePath);
		if(!directory.exists()) {
			directory.mkdirs();
		}
		 SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
		 String fileName = "Scheduled_Audit_Report_" + df.format(new Date());
		 String excelFileName =  fileName + ".xlsx";
		 File file = new File(excelFilePath + "//" + excelFileName);
		 try(SXSSFWorkbook workbook = new SXSSFWorkbook()) {
			 Sheet weekly = workbook.createSheet("Weekly");
			 Sheet fortnightly = workbook.createSheet("Fortnightly");
			 Sheet monthly = workbook.createSheet("Monthly");
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			 SimpleDateFormat excelDf = new SimpleDateFormat("dd-MMM");
             List<Date> sixDaysList = Utils.getSixWeekDates();
			 ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Site Code","Auditor", 
                     excelDf.format(sixDaysList.get(0)),
                     excelDf.format(sixDaysList.get(1)),
                     excelDf.format(sixDaysList.get(2)),
                     excelDf.format(sixDaysList.get(3)),
                     excelDf.format(sixDaysList.get(4)),
                     excelDf.format(sixDaysList.get(5)),
                     excelDf.format(sixDaysList.get(6)),
					 "week5_Total_assigned","week5_completed",
                     excelDf.format(sixDaysList.get(7)),
                     excelDf.format(sixDaysList.get(8)),
                     excelDf.format(sixDaysList.get(9)),
                     excelDf.format(sixDaysList.get(10)),
                     excelDf.format(sixDaysList.get(11)),
                     excelDf.format(sixDaysList.get(12)),
                     excelDf.format(sixDaysList.get(13)),
					 "week4_Total_assigned","week4_completed",
					 excelDf.format(sixDaysList.get(14)),
					 excelDf.format(sixDaysList.get(15)),
					 excelDf.format(sixDaysList.get(16)),
					 excelDf.format(sixDaysList.get(17)),
					 excelDf.format(sixDaysList.get(18)),
					 excelDf.format(sixDaysList.get(19)),
					 excelDf.format(sixDaysList.get(20)),
					 "week3_Total_assigned","week3_completed",
					 excelDf.format(sixDaysList.get(21)),
					 excelDf.format(sixDaysList.get(22)),
					 excelDf.format(sixDaysList.get(23)),
					 excelDf.format(sixDaysList.get(24)),
					 excelDf.format(sixDaysList.get(25)),
					 excelDf.format(sixDaysList.get(26)),
					 excelDf.format(sixDaysList.get(27)),
					 "week2_Total_assigned","week2_completed",
					 excelDf.format(sixDaysList.get(28)),
					 excelDf.format(sixDaysList.get(29)),
					 excelDf.format(sixDaysList.get(30)),
					 excelDf.format(sixDaysList.get(31)),
					 excelDf.format(sixDaysList.get(32)),
					 excelDf.format(sixDaysList.get(33)),
					 excelDf.format(sixDaysList.get(34)),
					 "week1_Total_assigned","week1_completed",
					 excelDf.format(sixDaysList.get(35)),
					 excelDf.format(sixDaysList.get(36)),
					 excelDf.format(sixDaysList.get(37)),
					 excelDf.format(sixDaysList.get(38)),
					 excelDf.format(sixDaysList.get(39)),
					 excelDf.format(sixDaysList.get(40)),
					 excelDf.format(sixDaysList.get(41)),
	                 "week_current_Total_assigned","week_current_completed","total_assigned","completed"));
	        CellStyle cellStyle = ExcelUtils.createCellStyle(weekly, 0);
	        ExcelUtils.createAndWriteRow(weekly, headerList, 0, cellStyle, true, workbook);
	        int rowCount = 1;
	        List<String> receipentsList1 = new ArrayList<>();
	        String receipentsList[] = null;
	        try {
	        	List<Object[]> objects = userAuditScheduleRepository.callGetWeeklyScheduleReport();
//				cellStyle = ExcelUtils.createCellStyle(weekly, ++rowCount);
				for(Object[] object : objects) {
					ArrayList<String> rowData = new ArrayList<>();
//					rowData.add(object[0] + "");
					rowData.add(object[1] + "");
//					rowData.add(object[2] + "");
					rowData.add(object[3] + "");
//					rowData.add(object[4] + "");
					rowData.add(object[5] + "");
					rowData.add(object[6] + "");
					rowData.add(object[7] + "");
					rowData.add(object[8] + "");
					rowData.add(object[9] + "");
					rowData.add(object[10] + "");
					rowData.add(object[11] + "");
					rowData.add(object[12] + "");
					rowData.add(object[13] + "");
					rowData.add(object[14] + "");
					rowData.add(object[15] + "");
					rowData.add(object[16] + "");
					rowData.add(object[17] + "");
					rowData.add(object[18] + "");
					rowData.add(object[19] + "");
					rowData.add(object[20] + "");
					rowData.add(object[21] + "");
					rowData.add(object[22] + "");
					rowData.add(object[23] + "");
					rowData.add(object[24] + "");
					rowData.add(object[25] + "");
					rowData.add(object[26] + "");
					rowData.add(object[27] + "");
					rowData.add(object[28] + "");
					rowData.add(object[29] + "");
					rowData.add(object[30] + "");
					rowData.add(object[31] + "");
					rowData.add(object[32] + "");
					rowData.add(object[33] + "");
					rowData.add(object[34] + "");
					rowData.add(object[35] + "");
					rowData.add(object[36] + "");
					rowData.add(object[37] + "");
					rowData.add(object[38] + "");
					rowData.add(object[39] + "");
					rowData.add(object[40] + "");
					rowData.add(object[41] + "");
					rowData.add(object[42] + "");
					rowData.add(object[43] + "");
					rowData.add(object[44] + "");
					rowData.add(object[45] + "");
					rowData.add(object[46] + "");
					rowData.add(object[47] + "");
					rowData.add(object[48] + "");
					rowData.add(object[49] + "");
					rowData.add(object[50] + "");
					rowData.add(object[51] + "");
					rowData.add(object[52] + "");
					rowData.add(object[53] + "");
					rowData.add(object[54] + "");
					rowData.add(object[55] + "");
					rowData.add(object[56] + "");
					rowData.add(object[57] + "");
					rowData.add(object[58] + "");
					rowData.add(object[59] + "");
					rowData.add(object[60] + "");
	                ExcelUtils.createAndWriteRow(weekly, rowData, rowCount++, cellStyle, false, workbook);
				}
			} catch (Exception e) {
				log.error("Exception in writing sheet ", e);
				return null;
			}

	        // Create Fortnightly sheet code
	        Calendar cto = new GregorianCalendar();
	    	cto.setTime(new Date());
	    	SimpleDateFormat sdf1 = new SimpleDateFormat("MMM-YYYY");
	    	cto.add(Calendar.MONTH, 0);
	    	Date currMonth = cto.getTime();
	        String currentsMonth = sdf1.format(currMonth);
	    	cto.add(Calendar.MONTH, -1);
	    	 Date perviousMonths = cto.getTime();
	    	 String perivousMonth = sdf1.format(perviousMonths);
	    	 Date date = new Date();
		        SimpleDateFormat formatter = new SimpleDateFormat("dd");
		        String str = formatter.format(date);
		        Integer todate = Integer.parseInt(str);
		        if(todate <= 15) {
		        	ExcelUtils.mergeCellWithoutColor(fortnightly, currentsMonth, 0, 0, 2, 4, 0);
		 	        ExcelUtils.mergeCellWithoutColor(fortnightly, perivousMonth, 0, 0, 5, 10, 0);
		         } else {
		        	 ExcelUtils.mergeCellWithoutColor(fortnightly, currentsMonth, 0, 0, 2, 7, 0);
				     ExcelUtils.mergeCellWithoutColor(fortnightly, perivousMonth, 0, 0, 8, 10, 0);
		         }
	        ExcelUtils.mergeCellWithoutColor(fortnightly, "Current Fortnight", 1, 1, 2, 4, 1);
	        ExcelUtils.mergeCellWithoutColor(fortnightly, "Fortnight 1", 1, 1, 5, 7, 1);
	        ExcelUtils.mergeCellWithoutColor(fortnightly, "Fortnight 2", 1, 1, 8, 10, 1);
	        ArrayList<String> headerList1 = new ArrayList<>(Arrays.asList("Site Code", "Auditor", "Status", "Assigned Audit", "Weekly Completed Total", "Status",
	                 "Assigned Audit", "Weekly Completed Total","Status" ,"Assigned Audit", "Weekly Completed Total"));
	        CellStyle cellStyle1 = ExcelUtils.createCellStyle(fortnightly, 2);
	        ExcelUtils.createAndWriteRow(fortnightly, headerList1, 2, cellStyle1, true, workbook);
	        int rowCounts = 3;
	        try {
				List<Object[]> objects = userAuditScheduleRepository.callGetFornightlyScheduleReport();
//				cellStyle = ExcelUtils.createCellStyle(weekly, ++rowCounts);
				for(Object[] object : objects) {
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(object[1] + "");
					rowData.add(object[3] + "");
					rowData.add(String.valueOf(object[6]).equals("1") ? "Yes" : "No");
					rowData.add(object[5] + "");
					rowData.add(object[6] + "");
					rowData.add(String.valueOf(object[8]).equals("1") ? "Yes" : "No");
					rowData.add(object[7] + "");
					rowData.add(object[8] + "");
					rowData.add(String.valueOf(object[10]).equals("1") ? "Yes" : "No");
					rowData.add(object[9] + "");
					rowData.add(object[10] + "");
	                ExcelUtils.createAndWriteRow(fortnightly, rowData, rowCounts++, cellStyle, false, workbook);
				}
			} catch (Exception e) {
				log.error("Exception in writing sheet ", e);
				return null;
			}

	       // Create Monthly sheet code
	        Calendar cto1 = new GregorianCalendar();
	    	cto1.setTime(new Date());
	    	SimpleDateFormat sdf2 = new SimpleDateFormat("MMM-YYYY");
	    	cto1.add(Calendar.MONTH, 0);
	    	Date currMonth1 = cto1.getTime();
	        String currentsMonth1 = sdf2.format(currMonth1);
	        cto1.add(Calendar.MONTH, -1);
	    	 Date perviousMonths1 = cto1.getTime();
	    	 String perivousMonth1 = sdf2.format(perviousMonths1);

	        ExcelUtils.mergeCellWithoutColor(monthly, "Monthly", 0, 0, 2, 7, 0);
	        ExcelUtils.mergeCellWithoutColor(monthly, perivousMonth1, 1, 1, 2, 4, 1);
	        ExcelUtils.mergeCellWithoutColor(monthly, currentsMonth1, 1, 1, 5, 7, 1);
	        ArrayList<String> headerList2 = new ArrayList<>(Arrays.asList("Site Code", "Auditor", "Status", "Assigned Audit", "Weekly Completed Total", 
	        		"Status","Assigned Audit", "Weekly Completed Total"));
		        CellStyle cellStyle2 = ExcelUtils.createCellStyle(monthly, 2);
		        ExcelUtils.createAndWriteRow(monthly, headerList2, 2, cellStyle2, true, workbook);
		        int rowCounts1 = 3;
		        try {
		        	List<Object[]> monthlyList = userAuditScheduleRepository.callGetMonthlyScheduleReport();
//					cellStyle = ExcelUtils.createCellStyle(monthly, ++rowCounts1);
					for(Object[] object : monthlyList) {
						ArrayList<String> rowData = new ArrayList<>();
                         rowData.add(object[1] + "");
                         rowData.add(object[3] + "");
                         rowData.add(String.valueOf(object[6]).equals("1") ? "Yes" : "No");
                         rowData.add(object[5] + "");
                         rowData.add(object[6] + "");
                         rowData.add(String.valueOf(object[8]).equals("1") ? "Yes" : "No");
                         rowData.add(object[7] + "");
                         rowData.add(object[8] + "");
		                ExcelUtils.createAndWriteRow(monthly, rowData, rowCounts1++, cellStyle, false, workbook);
				}
				} catch (Exception e) {
					log.error("Exception in writing sheet ", e);
					return null;
				}

	        try (FileOutputStream outputStream = new FileOutputStream(excelFilePath + "//" + excelFileName)){
	        	workbook.write(outputStream);
	        	outputStream.close();
			} catch (Exception e) {
				log.error("Exception in writing getScheduledAuditReportForAdmin() ", e);
			}
//	        for Prod
//	        receipentsList1.add("hemantj@epsho.electronicpay.in");
//	        receipentsList1.add("nitin.arondekar@epsho.electronicpay.in");
	       
//	        For uat
//	        receipentsList1.add("raksha@infmoniez.com");
//	        receipentsList1.add("rahul@infmoniez.com");
//	        receipentsList1.add("aditya_lessener@yahoo.com");
//	        receipentsList1.add("aditya@infominez.com");
//	        receipentsList1.add("harshit@infominez.com");
	        
            receipentsList = receipentsList1.toArray(new String[receipentsList1.size()]);
	        LocalDate currentdate = LocalDate.now();
	        Month currentMonth = currentdate.getMonth();
	        String subject = "Scheduled Audit Report - "+currentMonth;
	        Path path = Paths.get(excelFilePath + "//" + excelFileName);
	        mailService.sendingAttachmentMailWithRediffV2(receipentsList, subject, "Scheduled Audit Report", true, path.toString(), excelFileName);
	        return excelFilePath + "//" + excelFileName;
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			log.error("Exception in writing Audit Admin excel ", e);
			return null;
		}
	}

	public String getUserScheduledAuditReportForUsers() {
		log.info("getUserScheduledAuditReportForUsers()");
		String filePath = appConfig.getProperty("app.excelDir");
		String filePathStatic = "ScheduledAuditReportForUsers" + "//";
		String excelFilePath = filePath + filePathStatic;
		File directory = new File(excelFilePath);
		if(!directory.exists()) {
			directory.mkdirs();
		}
		 SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
		 String fileName = "Scheduled_Audit_Report_For_Users" + df.format(new Date());
		 String excelFileName =  fileName + ".xlsx";
		 File file = new File(excelFilePath + "//" + excelFileName);
		 try(SXSSFWorkbook workbook = new SXSSFWorkbook()){
			 Sheet sheet = workbook.createSheet("Scheduled Audit Report For Users");
			 ExcelUtils.createHeader(workbook, sheet, "EPS", 0, 1, 0, 10, 0);
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			 String summaryString = sdf.format(new Date());
			 ExcelUtils.historyTypeInfoRow(workbook, sheet, "Scheduled Audit For Users" + summaryString, 2, 2,
					 0, 10, 2);
			 ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Id", "First Name", "Last Name", "User Name", "Phone Number", "Email Id",
	                 "SSO Username", "User Type","Created On" , "Updated On", "Mailing Email"));
	        CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 3);
	        ExcelUtils.createAndWriteRow(sheet, headerList, 3, cellStyle, true, workbook);

	        int rowCount = 2;
	        List<String> receipentsList1 =new ArrayList<>();
	        String receipentsList[] = null;
	        try {
	        	List<Users> userslist = usersRepository.findAll();
	        	for(Users users : userslist) {
				cellStyle = ExcelUtils.createCellStyle(sheet, ++rowCount);
				    Users userV1 = usersRepository.findById(users.getUserId()).get();
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(userV1.getUserId() + "");
                    rowData.add(userV1.getFirstName());
                    rowData.add(userV1.getLastName());
                    rowData.add(userV1.getUserName());
                    rowData.add(userV1.getPhoneNumber());
                    rowData.add(userV1.getEmailId());
                    rowData.add(userV1.getSsoUsername());
                    rowData.add(userV1.getUserType());
                    rowData.add(sdf.format(userV1.getCreatedDate()));
                    rowData.add(sdf.format(userV1.getLastUpdatedDate()));
                    rowData.add(userV1.getMailingEmail());
                   ExcelUtils.createAndWriteRow(sheet, rowData, ++rowCount, cellStyle, false, null);
                   receipentsList1.add(userV1.getMailingEmail());
	        	}
			} catch (Exception e) {
				log.error("Exception in writing sheet ", e);
				return null;
			}
	        try  (FileOutputStream outputStream = new FileOutputStream(excelFilePath + "//" + excelFileName)){
				workbook.write(outputStream);
			} catch (Exception e) {
				log.error("Exception in writing getScheduledAuditReportForUsers() ", e);
			}
	        receipentsList = receipentsList1.toArray(new String[receipentsList1.size()]);
	        System.out.println("receipentsList" + receipentsList);
	        LocalDate currentdate = LocalDate.now();
	        Month currentMonth = currentdate.getMonth();
	        String subject = "Scheduled Audit Report For Users - "+currentMonth;
	        Path path = Paths.get(excelFilePath + "//" + excelFileName);
	        mailService.sendingAttachmentMailWithRediff(receipentsList, subject, "", true, path.toString(), excelFileName);
	        return excelFilePath + "//" + excelFileName;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in writing Audit Users excel ", e);
		return null;
	}
	}

	public ByteArrayInputStream getScheduledAuditReportForAdminV2() {
		log.info("getScheduledAuditReportForAdminV2()");
		String filePath = appConfig.getProperty("app.excelDir");
		String filePathStatic = "ScheduledAuditReportForAdmin" + "//";
		String excelFilePath = filePath + filePathStatic;
		File directory = new File(excelFilePath);
		if(!directory.exists()) {
			directory.mkdirs();
		}
		 SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
		 String fileName = "Scheduled_Audit_Report_" + df.format(new Date());
		 String excelFileName =  fileName + ".xlsx";
		 File file = new File(excelFilePath + "//" + excelFileName);
		 try(SXSSFWorkbook workbook = new SXSSFWorkbook()) {
			 Sheet weekly = workbook.createSheet("Weekly");
			 Sheet fortnightly = workbook.createSheet("Fortnightly");
			 Sheet monthly = workbook.createSheet("Monthly");
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			 SimpleDateFormat excelDf = new SimpleDateFormat("dd-MMM");
             List<Date> sixDaysList = Utils.getSixWeekDates();
			 ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Site Code","Auditor", 
                     excelDf.format(sixDaysList.get(0)),
                     excelDf.format(sixDaysList.get(1)),
                     excelDf.format(sixDaysList.get(2)),
                     excelDf.format(sixDaysList.get(3)),
                     excelDf.format(sixDaysList.get(4)),
                     excelDf.format(sixDaysList.get(5)),
                     excelDf.format(sixDaysList.get(6)),
					 "week5_Total_assigned","week5_completed",
                     excelDf.format(sixDaysList.get(7)),
                     excelDf.format(sixDaysList.get(8)),
                     excelDf.format(sixDaysList.get(9)),
                     excelDf.format(sixDaysList.get(10)),
                     excelDf.format(sixDaysList.get(11)),
                     excelDf.format(sixDaysList.get(12)),
                     excelDf.format(sixDaysList.get(13)),
					 "week4_Total_assigned","week4_completed",
					 excelDf.format(sixDaysList.get(14)),
					 excelDf.format(sixDaysList.get(15)),
					 excelDf.format(sixDaysList.get(16)),
					 excelDf.format(sixDaysList.get(17)),
					 excelDf.format(sixDaysList.get(18)),
					 excelDf.format(sixDaysList.get(19)),
					 excelDf.format(sixDaysList.get(20)),
					 "week3_Total_assigned","week3_completed",
					 excelDf.format(sixDaysList.get(21)),
					 excelDf.format(sixDaysList.get(22)),
					 excelDf.format(sixDaysList.get(23)),
					 excelDf.format(sixDaysList.get(24)),
					 excelDf.format(sixDaysList.get(25)),
					 excelDf.format(sixDaysList.get(26)),
					 excelDf.format(sixDaysList.get(27)),
					 "week2_Total_assigned","week2_completed",
					 excelDf.format(sixDaysList.get(28)),
					 excelDf.format(sixDaysList.get(29)),
					 excelDf.format(sixDaysList.get(30)),
					 excelDf.format(sixDaysList.get(31)),
					 excelDf.format(sixDaysList.get(32)),
					 excelDf.format(sixDaysList.get(33)),
					 excelDf.format(sixDaysList.get(34)),
					 "week1_Total_assigned","week1_completed",
					 excelDf.format(sixDaysList.get(35)),
					 excelDf.format(sixDaysList.get(36)),
					 excelDf.format(sixDaysList.get(37)),
					 excelDf.format(sixDaysList.get(38)),
					 excelDf.format(sixDaysList.get(39)),
					 excelDf.format(sixDaysList.get(40)),
					 excelDf.format(sixDaysList.get(41)),
	                 "week_current_Total_assigned","week_current_completed","total_assigned","completed"));
	        CellStyle cellStyle = ExcelUtils.createCellStyle(weekly, 0);
	        ExcelUtils.createAndWriteRow(weekly, headerList, 0, cellStyle, true, workbook);
	        int rowCount = 1;
	        List<String> receipentsList1 = new ArrayList<>();
	        String receipentsList[] = null;
	        try {
	        	List<Object[]> objects = userAuditScheduleRepository.callGetWeeklyScheduleReport();
//				cellStyle = ExcelUtils.createCellStyle(weekly, ++rowCount);
				for(Object[] object : objects) {
					ArrayList<String> rowData = new ArrayList<>();
//					rowData.add(object[0] + "");
					rowData.add(object[1] + "");
//					rowData.add(object[2] + "");
					rowData.add(object[3] + "");
//					rowData.add(object[4] + "");
					rowData.add(object[5] + "");
					rowData.add(object[6] + "");
					rowData.add(object[7] + "");
					rowData.add(object[8] + "");
					rowData.add(object[9] + "");
					rowData.add(object[10] + "");
					rowData.add(object[11] + "");
					rowData.add(object[12] + "");
					rowData.add(object[13] + "");
					rowData.add(object[14] + "");
					rowData.add(object[15] + "");
					rowData.add(object[16] + "");
					rowData.add(object[17] + "");
					rowData.add(object[18] + "");
					rowData.add(object[19] + "");
					rowData.add(object[20] + "");
					rowData.add(object[21] + "");
					rowData.add(object[22] + "");
					rowData.add(object[23] + "");
					rowData.add(object[24] + "");
					rowData.add(object[25] + "");
					rowData.add(object[26] + "");
					rowData.add(object[27] + "");
					rowData.add(object[28] + "");
					rowData.add(object[29] + "");
					rowData.add(object[30] + "");
					rowData.add(object[31] + "");
					rowData.add(object[32] + "");
					rowData.add(object[33] + "");
					rowData.add(object[34] + "");
					rowData.add(object[35] + "");
					rowData.add(object[36] + "");
					rowData.add(object[37] + "");
					rowData.add(object[38] + "");
					rowData.add(object[39] + "");
					rowData.add(object[40] + "");
					rowData.add(object[41] + "");
					rowData.add(object[42] + "");
					rowData.add(object[43] + "");
					rowData.add(object[44] + "");
					rowData.add(object[45] + "");
					rowData.add(object[46] + "");
					rowData.add(object[47] + "");
					rowData.add(object[48] + "");
					rowData.add(object[49] + "");
					rowData.add(object[50] + "");
					rowData.add(object[51] + "");
					rowData.add(object[52] + "");
					rowData.add(object[53] + "");
					rowData.add(object[54] + "");
					rowData.add(object[55] + "");
					rowData.add(object[56] + "");
					rowData.add(object[57] + "");
					rowData.add(object[58] + "");
					rowData.add(object[59] + "");
					rowData.add(object[60] + "");
	                ExcelUtils.createAndWriteRow(weekly, rowData, rowCount++, cellStyle, false, workbook);
				}
			} catch (Exception e) {
				log.error("Exception in writing sheet ", e);
				return null;
			}

	        // Create Fortnightly sheet code
	        Calendar cto = new GregorianCalendar();
	    	cto.setTime(new Date());
	    	SimpleDateFormat sdf1 = new SimpleDateFormat("MMM-YYYY");
	    	cto.add(Calendar.MONTH, 0);
	    	Date currMonth = cto.getTime();
	        String currentsMonth = sdf1.format(currMonth);
	    	cto.add(Calendar.MONTH, -1);
	    	 Date perviousMonths = cto.getTime();
	    	 String perivousMonth = sdf1.format(perviousMonths);
	    	 Date date = new Date();
		        SimpleDateFormat formatter = new SimpleDateFormat("dd");
		        String str = formatter.format(date);
		        Integer todate = Integer.parseInt(str);
		        if(todate <= 15) {
		        	ExcelUtils.mergeCellWithoutColor(fortnightly, currentsMonth, 0, 0, 2, 4, 0);
		 	        ExcelUtils.mergeCellWithoutColor(fortnightly, perivousMonth, 0, 0, 5, 10, 0);
		         } else {
		        	 ExcelUtils.mergeCellWithoutColor(fortnightly, currentsMonth, 0, 0, 2, 7, 0);
				     ExcelUtils.mergeCellWithoutColor(fortnightly, perivousMonth, 0, 0, 8, 10, 0);
		         }
	        ExcelUtils.mergeCellWithoutColor(fortnightly, "Current Fortnight", 1, 1, 2, 4, 1);
	        ExcelUtils.mergeCellWithoutColor(fortnightly, "Fortnight 1", 1, 1, 5, 7, 1);
	        ExcelUtils.mergeCellWithoutColor(fortnightly, "Fortnight 2", 1, 1, 8, 10, 1);
	        ArrayList<String> headerList1 = new ArrayList<>(Arrays.asList("Site Code", "Auditor", "Status", "Assigned Audit", "Weekly Completed Total", "Status",
	                 "Assigned Audit", "Weekly Completed Total","Status" ,"Assigned Audit", "Weekly Completed Total"));
	        CellStyle cellStyle1 = ExcelUtils.createCellStyle(fortnightly, 2);
	        ExcelUtils.createAndWriteRow(fortnightly, headerList1, 2, cellStyle1, true, workbook);
	        int rowCounts = 3;
	        try {
				List<Object[]> objects = userAuditScheduleRepository.callGetFornightlyScheduleReport();
//				cellStyle = ExcelUtils.createCellStyle(weekly, ++rowCounts);
				for(Object[] object : objects) {
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(object[1] + "");
					rowData.add(object[3] + "");
					rowData.add(String.valueOf(object[6]).equals("1") ? "Yes" : "No");
					rowData.add(object[5] + "");
					rowData.add(object[6] + "");
					rowData.add(String.valueOf(object[8]).equals("1") ? "Yes" : "No");
					rowData.add(object[7] + "");
					rowData.add(object[8] + "");
					rowData.add(String.valueOf(object[10]).equals("1") ? "Yes" : "No");
					rowData.add(object[9] + "");
					rowData.add(object[10] + "");
	                ExcelUtils.createAndWriteRow(fortnightly, rowData, rowCounts++, cellStyle, false, workbook);
				}
			} catch (Exception e) {
				log.error("Exception in writing sheet ", e);
				return null;
			}

	       // Create Monthly sheet code
	        Calendar cto1 = new GregorianCalendar();
	    	cto1.setTime(new Date());
	    	SimpleDateFormat sdf2 = new SimpleDateFormat("MMM-YYYY");
	    	cto1.add(Calendar.MONTH, 0);
	    	Date currMonth1 = cto1.getTime();
	        String currentsMonth1 = sdf2.format(currMonth1);
	        cto1.add(Calendar.MONTH, -1);
	    	 Date perviousMonths1 = cto1.getTime();
	    	 String perivousMonth1 = sdf2.format(perviousMonths1);

	        ExcelUtils.mergeCellWithoutColor(monthly, "Monthly", 0, 0, 2, 7, 0);
	        ExcelUtils.mergeCellWithoutColor(monthly, perivousMonth1, 1, 1, 2, 4, 1);
	        ExcelUtils.mergeCellWithoutColor(monthly, currentsMonth1, 1, 1, 5, 7, 1);
	        ArrayList<String> headerList2 = new ArrayList<>(Arrays.asList("Site Code", "Auditor", "Status", "Assigned Audit", "Weekly Completed Total", 
	        		"Status","Assigned Audit", "Weekly Completed Total"));
		        CellStyle cellStyle2 = ExcelUtils.createCellStyle(monthly, 2);
		        ExcelUtils.createAndWriteRow(monthly, headerList2, 2, cellStyle2, true, workbook);
		        int rowCounts1 = 3;
		        try {
		        	List<Object[]> monthlyList = userAuditScheduleRepository.callGetMonthlyScheduleReport();
//					cellStyle = ExcelUtils.createCellStyle(monthly, ++rowCounts1);
					for(Object[] object : monthlyList) {
						ArrayList<String> rowData = new ArrayList<>();
                         rowData.add(object[1] + "");
                         rowData.add(object[3] + "");
                         rowData.add(String.valueOf(object[6]).equals("1") ? "Yes" : "No");
                         rowData.add(object[5] + "");
                         rowData.add(object[6] + "");
                         rowData.add(String.valueOf(object[8]).equals("1") ? "Yes" : "No");
                         rowData.add(object[7] + "");
                         rowData.add(object[8] + "");
		                ExcelUtils.createAndWriteRow(monthly, rowData, rowCounts1++, cellStyle, false, workbook);
				  }
				} catch (Exception e) {
					log.error("Exception in writing sheet ", e);
					return null;
				}
		        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		        workbook.write(outputStream);
		        return new ByteArrayInputStream(outputStream.toByteArray());
		 }catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			log.error("Exception in writing Audit Admin excel V2 ", e);
			return null;
		}
	}

	public String getScheduledAuditReportForAdminEmail() {
		log.info("getScheduledAuditReportForAdminEmail()");
		String filePath = appConfig.getProperty("app.excelDir");
		String filePathStatic = "ScheduledAuditReportForAdmin" + "//";
		String excelFilePath = filePath + filePathStatic;
		File directory = new File(excelFilePath);
		if(!directory.exists()) {
			directory.mkdirs();
		}
		 SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
		 String fileName = "Scheduled_Audit_Report_" + df.format(new Date());
		 String excelFileName =  fileName + ".xlsx";
		 File file = new File(excelFilePath + "//" + excelFileName);
		 try(SXSSFWorkbook workbook = new SXSSFWorkbook()) {
			 Sheet weekly = workbook.createSheet("Weekly");
			 Sheet fortnightly = workbook.createSheet("Fortnightly");
			 Sheet monthly = workbook.createSheet("Monthly");
			 ArrayList<String> headerList = new ArrayList<>(Arrays.asList("Name","Completed","Pending","Total"));
	        CellStyle cellStyle = ExcelUtils.createCellStyle(weekly, 0);
	        ExcelUtils.createAndWriteRow(weekly, headerList, 0, cellStyle, true, workbook);
	        int rowCount = 1;
	        List<String> receipentsList1 = new ArrayList<>();
	        String receipentsList[] = null;
	        try {
	        	List<Object[]> objects = userAuditScheduleRepository.callGetWeeklyScheduleReportForMail();
				for(Object[] object : objects) {
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(object[0] + "");
					Integer pending = Integer.parseInt(String.valueOf(object[2])) - Integer.parseInt(String.valueOf(object[3]));
					rowData.add(object[3] + "");
					rowData.add(pending + "");
					rowData.add(object[2] + "");
	                ExcelUtils.createAndWriteRow(weekly, rowData, rowCount++, cellStyle, false, workbook);
				}
			} catch (Exception e) {
				log.error("Exception in writing sheet ", e);
				return null;
			}

	        // Create Fortnightly sheet code
	        ArrayList<String> headerList1 = new ArrayList<>(Arrays.asList("Name", "Completed", "Pending", "Total"));
	        CellStyle cellStyle1 = ExcelUtils.createCellStyle(fortnightly, 0);
	        ExcelUtils.createAndWriteRow(fortnightly, headerList1, 0, cellStyle1, true, workbook);
	        int rowCounts = 1;
	        try {
				List<Object[]> objects = userAuditScheduleRepository.callGetFornightlyScheduleReportForMail();
				for(Object[] object : objects) {
					ArrayList<String> rowData = new ArrayList<>();
					rowData.add(object[0] + "");
					Integer pending = Integer.parseInt(String.valueOf(object[2])) - Integer.parseInt(String.valueOf(object[3]));
					rowData.add(object[3] + "");
					rowData.add(pending + "");
					rowData.add(object[2] + "");
	                ExcelUtils.createAndWriteRow(fortnightly, rowData, rowCounts++, cellStyle, false, workbook);
				}
			} catch (Exception e) {
				log.error("Exception in writing sheet ", e);
				return null;
			}

	       // Create Monthly sheet code
	        ArrayList<String> headerList2 = new ArrayList<>(Arrays.asList("Name", "Completed", "Pending", "Total"));
		        CellStyle cellStyle2 = ExcelUtils.createCellStyle(monthly, 0);
		        ExcelUtils.createAndWriteRow(monthly, headerList2, 0, cellStyle2, true, workbook);
		        int rowCounts1 = 1;
		        try {
		        	List<Object[]> monthlyList = userAuditScheduleRepository.callGetMonthlyScheduleReportForMail();
					for(Object[] object : monthlyList) {
						ArrayList<String> rowData = new ArrayList<>();
                         rowData.add(object[0] + "");
                         Integer pending = Integer.parseInt(String.valueOf(object[2])) - Integer.parseInt(String.valueOf(object[3]));
     					rowData.add(object[3] + "");
     					rowData.add(pending + "");
     					rowData.add(object[2] + "");
		                ExcelUtils.createAndWriteRow(monthly, rowData, rowCounts1++, cellStyle, false, workbook);
				}
				} catch (Exception e) {
					log.error("Exception in writing sheet ", e);
					return null;
				}

	        try (FileOutputStream outputStream = new FileOutputStream(excelFilePath + "//" + excelFileName)){
	        	workbook.write(outputStream);
	        	outputStream.close();
			} catch (Exception e) {
				log.error("Exception in writing getScheduledAuditReportForAdmin() ", e);
			}
//	        for Prod
//	        receipentsList1.add("hemantj@epsho.electronicpay.in");
//	        receipentsList1.add("nitin.arondekar@epsho.electronicpay.in");
//	        receipentsList1.add("dinesh.retrekar@electronicpay.in");
//	        receipentsList1.add("amarnath@electronicpay.in");
//	        receipentsList1.add("sai@electronicpay.in");
//	        receipentsList1.add("srinath.c@electronicpay.in");
//	        receipentsList1.add("vishal.sharma@electronicpay.in");
//	        receipentsList1.add("vaibhavk@electronicpay.in");
//	        receipentsList1.add("pradeep@electronicpay.in");

	       
//	        For uat
//	        receipentsList1.add("raksha@infmoniez.com");
//	        receipentsList1.add("rahul@infmoniez.com");
//	        receipentsList1.add("aditya_lessener@yahoo.com");
//	        receipentsList1.add("aditya@infominez.com");
//	        receipentsList1.add("harshit@infominez.com");
	        receipentsList1.add("aishwarya.prabhu@electronicpay.in");
	        receipentsList1.add("saisagar.parab@electronicpay.in");
	        receipentsList1.add("vrunda.sherikar@electronicpay.in");
//	        receipentsList1.add("raksha@infominez.com");
//	        receipentsList1.add("deepika@infominez.com");
//	        receipentsList1.add("aditya.shukla.1193@gmail.com");
	        
            receipentsList = receipentsList1.toArray(new String[receipentsList1.size()]);
	        LocalDate currentdate = LocalDate.now();
	        Month currentMonth = currentdate.getMonth();
	        String subject = "Scheduled Audit Report - "+currentMonth;
	        Path path = Paths.get(excelFilePath + "//" + excelFileName);
	        mailService.sendingAttachmentMailWithRediffV2(receipentsList, subject, "Scheduled Audit Report", true, path.toString(), excelFileName);
	        return excelFilePath + "//" + excelFileName;
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			log.error("Exception in writing Audit Admin excel ", e);
			return null;
		}
		
	}
	
	public String getScheduledQRReport(AuditReport auditReport) {
        ResultSet rs = null;
//        PreparedStatement ps = null;
        CallableStatement ps = null;
        Connection conn = null;
        List<String> headers = new ArrayList<>();
        List<List<String>> data = new ArrayList<>();
        try {
            conn = ConnPool.getInstance().getConnection();
            String fromDate = FileUtils.getStringFromString(auditReport.getFromDate());
            String toDate = FileUtils.getStringFromString(auditReport.getToDate());
            String SQL = "{ call  getReportQR(?, ?) }";
            System.out.println("fromDate : " + fromDate + " toDate: " + toDate +  " sql :" + SQL);

            ps = conn.prepareCall(SQL);
            ps.setString(1, fromDate);
            ps.setString(2, toDate);

            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            for (int i = 1; i <= columnCount; i++) {
                String name = rsmd.getColumnName(i);
                headers.add(name);
            }

            while (rs.next()) {
                List<String> object = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    object.add(rs.getString(i));
                }
                data.add(object);
            }
        } catch (SQLException e) {
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
            throw e;

        } catch (Throwable e) {
            e.printStackTrace();
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return createAuditReportExcel(headers, data);
        }
    }
	
	public String createAuditReportExcel(List<String> headers, List<List<String>> data) {
        log.info(" createAuditReportExcel excel");
        
        String filePath = appConfig.getProperty("app.excelDir");
        String filePathStatic = "QRReport" + "//";
		String excelFilePath = filePath + filePathStatic;
		File directory = new File(excelFilePath);
		if(!directory.exists()) {
			directory.mkdirs();
		}
		 SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
		 String fileName = "QR_Report_" + df.format(new Date());
		 String excelFileName =  fileName + ".xlsx";
		 File file = new File(excelFilePath + "//" + excelFileName);
        
        try (SXSSFWorkbook workbook = new SXSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("audit_Report");
            ArrayList<String> headerList = (ArrayList<String>) headers;
            CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 2);
            ExcelUtils.createAndWriteRowWithColor(sheet, headerList, 0, cellStyle, true, workbook,
                    IndexedColors.BLACK.getIndex(), IndexedColors.WHITE.getIndex());
            int rowCount = 1;
            try {
                cellStyle = ExcelUtils.createCellStyle(sheet, rowCount);
                for (List<String> object : data) {
                    ArrayList<String> rowData = new ArrayList<>();
                    for (String s : object) {
                        rowData.add(s);
                    }
                    ExcelUtils.createAndWriteRow(sheet, rowData, rowCount++, cellStyle, false, null);
                }
            } catch (Exception e) {
                log.error("Exception in writing sheet ", e);
                return null;
            }
            
            try (FileOutputStream outputStream = new FileOutputStream(excelFilePath + "//" + excelFileName)){
	        	workbook.write(outputStream);
	        	outputStream.close();
			} catch (Exception e) {
				log.error("Exception in writing getScheduledAuditReportForAdmin() ", e);
			}
            List<String> receipentsList1 = new ArrayList<>();
	        String receipentsList[] = null;
	        receipentsList1.add("rahul@infominez.com");
	        receipentsList1.add("aditya@infominez.com");
	        receipentsList1.add("nagendra@infominez.com");
	        receipentsList1.add("hemantj@electronicpay.in");
	        receipentsList1.add("rajendra@electronicpay.in");
	        receipentsList1.add("vrunda.sherikar@electronicpay.in");
	        receipentsList1.add("rohit@electronicpay.in");
	        receipentsList1.add("vinodj@electronicpay.in");
	        receipentsList1.add("krupa.namshikar@electronicpay.in");
	        receipentsList1.add("mamata.amkar@electronicpay.in");
	        receipentsList1.add("rajendra@electronicpay.in");
	        
            receipentsList = receipentsList1.toArray(new String[receipentsList1.size()]);
	        LocalDate currentdate = LocalDate.now();
	        Month currentMonth = currentdate.getMonth();
	        String subject = "Scheduled QR Report - "+currentMonth;
	        Path path = Paths.get(excelFilePath + "//" + excelFileName);
	        mailService.sendingAttachmentMailWithRediff(receipentsList, subject, "Scheduled QR Report", true, path.toString(), excelFileName);
            
	        return excelFilePath + "//" + excelFileName;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing createAuditReportExcel excel ", e);
            return null;
        }
    }
}



