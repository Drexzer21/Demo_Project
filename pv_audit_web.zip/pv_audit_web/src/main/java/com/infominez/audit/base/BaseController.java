package com.infominez.audit.base;

import com.infominez.audit.entity.Users;
import com.infominez.audit.security.TokenProvider;
import com.infominez.audit.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletRequest;

public abstract class BaseController {

    @Autowired
    private UsersService userService;

    @Autowired
    private TokenProvider tokenProvider;

    public Users getUser(HttpServletRequest request){
        try{
        String token = request.getHeader("Authorization").substring("Bearer".length()).trim();
        String username = tokenProvider.getUsernameByAccessToken(token);
        if (username != null){
            return userService.findUserByName(username);
        }else{
            return null;
        }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
