package com.infominez.audit.service;

import com.infominez.audit.entity.AuditType;
import com.infominez.audit.repo.AuditTypeRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class AuditTypeService {

    private final AuditTypeRepository auditTypeRepository;

    public JSONObject createAuditType(AuditType auditType) {
        JSONObject baseResponse = new JSONObject();
       try {
           List<AuditType> list = auditTypeRepository.findByAuditType(auditType.getAuditType());
           if (list != null && !list.isEmpty()){
               baseResponse.put("status", 302);
               baseResponse.put("response", "Object Type Already exist");
           }else{
           Date date = new Date();
           auditType.setCreatedBy(1);
           auditType.setUpdatedBy(1);
           auditType.setCreatedDate(date);
           auditType.setLastUpdatedDate(date);

           baseResponse.put("status", 200);
           baseResponse.put("response", auditTypeRepository.save(auditType));
           }
       }catch (Exception e){
           baseResponse.put("status", 500);
           baseResponse.put("response", "Internal Server Error");
       }
        return baseResponse;
    }

    public JSONObject updateAuditType(AuditType auditType) {
        log.info(this.getClass().getName() + " :- updateAuditType()");
        JSONObject baseResponse = new JSONObject();
        try {
            List<AuditType> list = auditTypeRepository.findByAuditType(auditType.getAuditType());
            if (list != null && !list.isEmpty() && auditType.getAuditTypeId() != list.get(0).getAuditTypeId()){
                baseResponse.put("status", 302);
                baseResponse.put("response", "Object Type Already exist");
            }else{
            Date date = new Date();
            AuditType getAuditType = auditTypeRepository.findById(auditType.getAuditTypeId()).get();
            if (auditType.getAuditType() != null && !auditType.getAuditType().isEmpty()) {
                getAuditType.setAuditType(auditType.getAuditType());
            }
            auditType.setLastUpdatedDate(date);
            baseResponse.put("status", 200);
            baseResponse.put("response", auditTypeRepository.save(getAuditType));
            }
        } catch (Exception e) {
            baseResponse.put("status", 500);
            baseResponse.put("response", "Internal Server Error");
        }
        return baseResponse;
    }

    public JSONObject findAuditTypeById(Integer auditTypeId) {
        log.info(this.getClass().getName() + " :- findAuditTypeById()");
        JSONObject jsonObject=new JSONObject();
        try{
            AuditType auditType = auditTypeRepository.findById(auditTypeId).get();
            if(auditType !=null&& !jsonObject.isEmpty()){
                jsonObject.put("status", 200);
                jsonObject.put("response", auditType);
            }
            else{
                jsonObject.put("status", 302);
                jsonObject.put("response", "No Object Found");
            }
        }catch (Exception e) {
            jsonObject.put("status", 500);
            jsonObject.put("response", "Internal Server Error");
        }
        return jsonObject;
    }

    public JSONObject findAllAuditType() {
        JSONObject result = new JSONObject();
        try {
            List<AuditType> list = auditTypeRepository.findAll();
            if (list != null && !list.isEmpty()){
                result.put("status", 200);
                result.put("response", list);
            }else{
                result.put("status", 302);
                result.put("response", "No Object Found");
            }
        } catch (Exception e) {
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public List<AuditType> findAllForTest(){
        return auditTypeRepository.findAll();
    }
}
