package com.infominez.audit.service;

import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.Question;
import com.infominez.audit.entity.Template;
import com.infominez.audit.repo.PageRepository;
import com.infominez.audit.repo.QuestionRepository;
import com.infominez.audit.repo.TemplateRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@Slf4j
@AllArgsConstructor
public class PageService {

    private final PageRepository pageRepository;
    private final TemplateRepository templateRepository;
    private final QuestionRepository questionRepository;

    public JSONObject createPage(Page page) {
        log.info(this.getClass().getName() + " :- createPage()");
        JSONObject result = new JSONObject();
        try {
            List<Page> list = pageRepository.findByPageNameAndTemplate(page.getPageName(), page.getTemplate());
            if (list != null && !list.isEmpty() && page.getPageId() != list.get(0).getPageId()) {
                result.put("status", 302);
                result.put("response", "Page already Exist with Page Name : " + page.getPageName() + " and TemplateID : " + page.getTemplate().getTemplateId());
            } else {
            	Page duplicateSequence = pageRepository.findByTemplateAndSequence(page.getTemplate(), page.getSequence());
                if (duplicateSequence != null) {
                	result.put("status", 302);
                    result.put("response", "Sequence already exist with template");
                    return result;
                }
                Date date = new Date();
                page.setCreatedBy(1); // todo change when login is implemented
                page.setUpdatedBy(1); // todo change when login is implemented
                page.setCreatedDate(date);
                page.setLastUpdatedDate(date);
                Page createdPage = pageRepository.save(page);
                if (createdPage != null) {
                    result.put("status", 200);
                    result.put("response", "Page Added Successfully");
                }

                else {
                    result.put("status", 302);
                    result.put("response", "Unable to add Page");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in createPage for Page : {} and exception : {} ", page.toString(), e.getMessage());
            log.trace("Exception in createPage for Page : {} and trace : {} ", page.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject updatePage(Page page) {
        log.info(this.getClass().getName() + " :- updatePage()");
        JSONObject result = new JSONObject();
        try {
            List<Page> list = pageRepository.findByPageNameAndTemplate(page.getPageName(), page.getTemplate());
            if (list != null && !list.isEmpty() && !page.getPageId().equals(list.get(0).getPageId())) {
                result.put("status", 302);
                result.put("response", "Page already Exist with Page Name : " + page.getPageName() + " and TemplateID : " + page.getTemplate().getTemplateId());
            } else {
            	Page duplicateSequence = pageRepository.findByTemplateAndSequence(page.getTemplate(), page.getSequence());
                if (duplicateSequence != null && !page.getPageId().equals(duplicateSequence.getPageId())) {
                	result.put("status", 302);
                    result.put("response", "Sequence already exist with template");
                    return result;
                }
                Page pageToUpdate = pageRepository.findById(page.getPageId()).get();
                if (pageToUpdate != null) {
                    if (page.getPageName() != null && !page.getPageName().trim().isEmpty()) {
                        pageToUpdate.setPageName(page.getPageName().trim());
                    }
                    if (page.getTemplate() != null) {
                        pageToUpdate.setTemplate(page.getTemplate());
                    }
                    if (page.getSequence() != null) {
                        pageToUpdate.setSequence(page.getSequence());
                    }
                    if (page.getPageDesc() != null) {
                        pageToUpdate.setPageDesc(page.getPageDesc());
                    }


                    pageToUpdate.setLastUpdatedDate(new Date());
                    pageRepository.save(pageToUpdate);
                    result.put("status", 200);
                    result.put("response", "Page Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update Page");
                }
            }
        } catch (Exception e) {

            log.error("Exception in updatePage for Page : {} and exception : {} ", page.toString(), e.getMessage());
            log.trace("Exception in updatePage for Page : {} and trace : {} ", page.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findPageById(Integer id) {
        log.info(this.getClass().getName() + " :- findPageById()");
        JSONObject result = new JSONObject();
        try {
            Page page = pageRepository.findById(id).get();
            if (page != null) {
                result.put("status", 200);
                result.put("response", page);
            } else {
                result.put("status", 302);
                result.put("response", "Page Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findPageById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findPageById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findAllPage() {
        log.info(this.getClass().getName() + " :- findAllPage()");
        JSONObject result = new JSONObject();
        try {
            List<Page> page = pageRepository.findAll();
            if (page != null) {
                result.put("status", 200);
                result.put("response", page);
            } else {
                result.put("status", 302);
                result.put("response", "Page Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllPage for Page: {} and exception : {} ", e.getMessage());
            log.trace("Exception in findAllPage for Page : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


    public JSONObject findPagesByTemplateId(Integer templateId) {

        log.info(this.getClass().getName() + " :- findPagesByTemplateId()");
        JSONObject result = new JSONObject();
        try {
            Template template = templateRepository.findById(templateId).get();
            List<Page> page = pageRepository.findByTemplate(template);
            if (page != null) {
                result.put("status", 200);
                result.put("response", page);
            } else {
                result.put("status", 302);
                result.put("response", "Page Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findPagesByTemplateId for id : {} and exception : {} ", templateId, e.getMessage());
            log.trace("Exception in findPagesByTemplateId for id : {} and trace : {} ", templateId, e.getStackTrace());

            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllPageList() {
        log.info(this.getClass().getName() + " :- findAllTPageList()");
        JSONObject result = new JSONObject();
        try {
            List<Page> pageList = pageRepository.findAll();
            JSONArray newList = new JSONArray();
            for (Page page : pageList) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("page", page);
                List<Question> questions = questionRepository.findByPage(page);
                jsonObject.put("noOfQuestions", questions.size());
                newList.add(jsonObject);
            }
            if (newList != null && !newList.isEmpty()) {
                result.put("status", 200);
                result.put("response", newList);
            } else {
                result.put("status", 302);
                result.put("response", "No Page found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllTPageList  exception : {} ", e.getMessage());
            log.trace("Exception in findAllTPageList  trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }
}
