package com.infominez.audit.security;

import com.infominez.audit.entity.Users;
import com.infominez.audit.service.UsersService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Collections;


/**
 * @author AYUSH PARTANI
 *
 */
@Component
public class AppUserDetailService implements UserDetailsService{
	
	 private final UsersService userService;

	  public AppUserDetailService(UsersService userService) {
	    this.userService = userService;
	  }

	  @Override
	  public final UserDetails loadUserByUsername(String username)
	      throws UsernameNotFoundException {
	    final Users user = this.userService.lookup(username);
	    if (user == null) {
	      throw new UsernameNotFoundException("User '" + username + "' not found");
	    }

	    return org.springframework.security.core.userdetails.User.withUsername(username)
	        .password(user.getPassword()).authorities(Collections.emptyList())
	        .accountExpired(false).accountLocked(false).credentialsExpired(false)
	        .disabled(false).build();
	  }
	
	

}
