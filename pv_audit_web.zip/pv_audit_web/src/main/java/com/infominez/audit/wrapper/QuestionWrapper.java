package com.infominez.audit.wrapper;

import com.infominez.audit.entity.Page;
import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.utils.EnumUtils;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.util.List;

@Data
public class QuestionWrapper {
    private Integer questionId;
    private String question;
    private Page page;
    private QuestionType questionType;
    private String defaultValue;
    private Boolean isMadatory;
    private String dataType;
    private Integer captureImgStatus;
    private Integer sequence;
    private Integer parentId;
    private Integer influenceBy;
    private String influencerResponseValue;
    private Boolean isPrefilled;
    private String prefilledBy;
    private List<String> questionTypeOptionList;
    private Boolean isDerived;
    private Boolean isYesNo;
    private List<String> operator;
    private List<Integer> operands;

}
