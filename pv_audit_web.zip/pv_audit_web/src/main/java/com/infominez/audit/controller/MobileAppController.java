package com.infominez.audit.controller;

import com.google.gson.Gson;
import com.infominez.audit.base.BaseController;
import com.infominez.audit.entity.Users;
import com.infominez.audit.repo.UsersRepository;
import com.infominez.audit.service.MobileAppService;
import com.infominez.audit.wrapper.TicketResponseListWrapper;
import com.infominez.audit.wrapper.TicketResponseWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/mobileApp")
@AllArgsConstructor
@Slf4j
public class MobileAppController extends BaseController {
    private final UsersRepository usersRepository;

    private final MobileAppService mobileAppService;

    @PostMapping("/getDashboardData")
    public JSONObject getDashboardData(@RequestBody JSONObject request, HttpServletRequest httpRequest,
                                       HttpServletResponse httpResponse) {
        log.info(this.getClass().getName() + " :- getDashboardData() ");
        Users user = super.getUser(httpRequest);  // bypass
        return mobileAppService.getDashboardData(request, user);
//        return mobileAppService.getDashboardData(request, null);
    }

    @PostMapping("/getAtmForAudit")
    public JSONObject getAtmForAudit(@RequestBody JSONObject request, HttpServletRequest httpRequest,
                                     HttpServletResponse httpResponse) {
        log.info(this.getClass().getName() + " :- getAtmForAudit() ");
        Users user = super.getUser(httpRequest);
        return mobileAppService.getAtmForAudit(request,user);
    }

    @PostMapping("/getAuditQuestion")
    public JSONObject getAuditQuestion(@RequestBody JSONObject request) {
        log.info(this.getClass().getName() + " :- getAuditQuestion() ");
        return mobileAppService.getAuditQuestion(request);
    }

    @GetMapping("/getByTicketId")
    public JSONObject getByTicketId(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- getAuditQuestion() ");
        return mobileAppService.getByTicketId(null,ticketId);
    }

    @PostMapping("/getHomeData")
    public JSONObject getHomeData(@RequestBody JSONObject request,@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- getAuditQuestion() ");
        JSONObject result = new JSONObject();
        try{
            JSONArray response = new JSONArray();
            JSONObject temp = new JSONObject();
            temp.put("count", 500);
            temp.put("auditStatus", "PENDING");
            response.add(temp);
            temp = new JSONObject();
            temp.put("count", 200);
            temp.put("auditStatus", "ASSIGNED");
            response.add(temp);
            temp = new JSONObject();
            temp.put("count", 150);
            temp.put("auditStatus", "OVERDUE");
            response.add(temp);
            temp = new JSONObject();
            temp.put("count", 20);
            temp.put("auditStatus", "UPCOMING");
            response.add(temp);

            result.put("status", 200);
            result.put("response", response);

        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    @PostMapping("/createMultipleTicketResponse")
    public JSONObject create(@RequestBody TicketResponseListWrapper ticketResponseList) {
        log.info(this.getClass().getName() + " :- createMultipleTicketResponse() :  " + ticketResponseList.toString());
        return mobileAppService.createMultipleTicketResponse(ticketResponseList.getData());
    }


    @GetMapping("/getByTicketIdV2")
    public JSONObject getByTicketIdV2(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- getAuditQuestion() ");
        return mobileAppService.getByTicketIdV2(null,ticketId);
    }

    @GetMapping("/getByTicketIdV3")
    public JSONObject getByTicketIdV3(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- getAuditQuestion() ");
        return mobileAppService.getByTicketIdV3(ticketId);
    }

    @PostMapping("/getHomeDataV2")
    public JSONObject getHomeDataV2(@RequestBody JSONObject request, HttpServletRequest httpRequest,
                                    HttpServletResponse httpResponse) {
        log.info(this.getClass().getName() + " :- getHomeDataV2() ");
        JSONObject result = new JSONObject();
        try{
            Users user = super.getUser(httpRequest);  // by pass
            if (user != null){
                result = mobileAppService.getHomeData(user);
            }else{
                result.put("status", 401);
                result.put("response", "Unauthorized Access");
                return result;
            }

        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    @GetMapping("getOfflineData")
    public JSONObject getOfflineData(HttpServletRequest httpRequest,
                                     HttpServletResponse httpResponse){
        log.info(this.getClass().getName() + " :- getOfflineData() ");
        JSONObject result = new JSONObject();
        try{
            Users user = super.getUser(httpRequest);  // by pass
//            Users user = usersRepository.findById(9).orElse(null);  // by pass
            if (user != null){
                result = mobileAppService.getOfflineData(user);
            }else{
                result.put("status", 401);
                result.put("response", "Unauthorized Access");
            }
        }catch (Exception e){
            e.printStackTrace();
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    @GetMapping("/getPreviewData")
    public JSONObject getPreviewData(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- getPreviewData() ");
        return mobileAppService.getPreviewData(ticketId);
    }

//    @PostMapping("/updatePreviewResponse")
//    public JSONObject updatePreviewResponse(@RequestBody TicketResponseListWrapper ticketResponseList) {
//        log.info(this.getClass().getName() + " :- updatePreviewResponse() :  " + ticketResponseList.toString());
//        return mobileAppService.updatePreviewResponse(ticketResponseList.getData());
//    }

    @GetMapping( "/getPreviewDataByTicketId")
    public JSONObject getPreviewDataByTicketId(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- getPreviewDataByTicketId() ");
        return mobileAppService.getPreviewDataByTicketId(ticketId);
    }

    @PostMapping("/updatePreviewResponse")
    public JSONObject updatePreviewResponse(@RequestBody JSONObject ticketResponse) {
        log.info(this.getClass().getName() + " :- updatePreviewResponse() :  " + ticketResponse.toString());
        return mobileAppService.updatePreviewDataResponse(ticketResponse);
    }

    @PostMapping("/getDashboardDataScheduled")
    public JSONObject getDashboardDataScheduled(@RequestBody JSONObject request, HttpServletRequest httpRequest,
                                       HttpServletResponse httpResponse) {
        log.info(this.getClass().getName() + " :- getDashboardDataScheduled() ");
        Users user = super.getUser(httpRequest);  // bypass
        return mobileAppService.getDashboardDataScheduled(request, user);
//        return mobileAppService.getDashboardData(request, null);
    }

    @PostMapping("/submitParentQuestionResponse")
    public JSONObject submitParentQuestionResponse(@RequestBody TicketResponseWrapper ticketResponseWrapper) {
        log.info(" :- submitParentQuestionResponse() : {} " , ticketResponseWrapper);
        return mobileAppService.submitParentQuestionResponse(ticketResponseWrapper);
    }

    @GetMapping("/markUnmarkSiteForOffline")
    public JSONObject markUnmarkSiteForOffline(@QueryParam("ticketId") Integer ticketId, HttpServletRequest request,
                                               HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- markUnmarkSiteForOffline() ticketId : {}", ticketId);
        JSONObject result = new JSONObject();
        Users user = super.getUser(request);
        if (user == null) {
            result.put("status", 500);
            result.put("response", "Unauthorized Access");
            return result;
        }
        return mobileAppService.markUnmarkSiteForOffline(ticketId,user);
    }
}
