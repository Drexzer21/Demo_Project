package com.infominez.audit.wrapper;

import lombok.Data;

import java.util.List;

@Data
public class TicketResponseListWrapper {
    private List<TicketResponseWrapper> data;
}
