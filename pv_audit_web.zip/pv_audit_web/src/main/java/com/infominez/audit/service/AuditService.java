package com.infominez.audit.service;

import com.infominez.audit.AuditApplication;
import com.infominez.audit.entity.Audit;
import com.infominez.audit.entity.Site;
import com.infominez.audit.entity.Template;
import com.infominez.audit.repo.AuditRepository;
import com.infominez.audit.repo.TemplateRepository;
import com.infominez.audit.utils.ConnPool;
import com.infominez.audit.utils.ExcelUtils;
import com.infominez.audit.utils.FileUtils;
import com.infominez.audit.wrapper.AuditReport;

import com.infominez.audit.wrapper.CashMasterDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class AuditService {
    private final AuditRepository auditRepository;
    private final TemplateRepository templateRepository;

    public JSONObject createAudit(Audit audit) {
        log.info(this.getClass().getName() + " :- createAudit()");
        JSONObject result = new JSONObject();
        try {
            List<Audit> list = auditRepository.findByAuditNameAndTemplate(audit.getAuditName(), audit.getTemplate());
            if (list != null && !list.isEmpty()) {
                result.put("status", 302);
                result.put("response", "Audit already Exist with audit Name : " + audit.getAuditName() + " and TemplateId : " + audit.getTemplate().getTemplateId());
            } else {
                Date date = new Date();
                audit.setCreatedBy(1); // todo change when login is implemented
                audit.setUpdatedBy(1); // todo change when login is implemented
                audit.setCreatedDate(date);
                audit.setLastUpdatedDate(date);
                Audit createdAudit = auditRepository.save(audit);
                if (createdAudit != null) {
                    result.put("status", 200);
                    result.put("response", "Audit Added Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to add Audit");
                }
            }
        } catch (Exception e) {

            log.error("Exception in createAudit for Audit : {} and exception : {} ", audit.toString(), e.getMessage());
            log.trace("Exception in createAudit for Audit : {} and trace : {} ", audit.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject updateAudit(Audit audit) {
        log.info(this.getClass().getName() + " :- updateAudit()");
        JSONObject result = new JSONObject();
        try {
            List<Audit> list = auditRepository.findByAuditNameAndTemplate(audit.getAuditName(), audit.getTemplate());
            if (list != null && !list.isEmpty() && !list.get(0).getAuditId().equals(audit.getAuditId())) {
                result.put("status", 302);
                result.put("response", "Audit already Exist with audit Name : " + audit.getAuditName() + " and TemplateId : " + audit.getTemplate().getTemplateId());
            } else {
                Audit auditToUpdate = auditRepository.findById(audit.getAuditId()).get();
                if (auditToUpdate != null) {
                    if (audit.getAuditName() != null && !audit.getAuditName().trim().isEmpty()) {
                        auditToUpdate.setAuditName(audit.getAuditName().trim());
                    }
                    if (audit.getStartDate() != null) {
                        auditToUpdate.setStartDate(audit.getStartDate());
                    }
                    if (audit.getEndDate() != null) {
                        auditToUpdate.setEndDate(audit.getEndDate());
                    }
                    if (audit.getStatus() != null && !audit.getStatus().trim().isEmpty()) {
                        auditToUpdate.setStatus(audit.getStatus().trim());
                    }

                    if (audit.getTemplate() != null) {
                        auditToUpdate.setTemplate(audit.getTemplate());
                    }

                    auditToUpdate.setLastUpdatedDate(new Date());
                    auditRepository.save(auditToUpdate);
                    result.put("status", 200);
                    result.put("response", "Audit Updated Successfully");
                } else {
                    result.put("status", 302);
                    result.put("response", "Unable to Update Audit");
                }
            }
        } catch (Exception e) {

            log.error("Exception in updateAudit for Audit : {} and exception : {} ", audit.toString(), e.getMessage());
            log.trace("Exception in updateAudit for Audit : {} and trace : {} ", audit.toString(), e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;


    }

    public JSONObject findAuditById(Integer id) {
        log.info(this.getClass().getName() + " :- findAuditById()");
        JSONObject result = new JSONObject();
        try {
            Audit audit = auditRepository.findById(id).get();
            if (audit != null) {
                result.put("status", 200);
                result.put("response", audit);
            } else {
                result.put("status", 302);
                result.put("response", "Audit Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAuditById for id : {} and exception : {} ", id, e.getMessage());
            log.trace("Exception in findAuditById for id : {} and trace : {} ", id, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAllAudit() {
        log.info(this.getClass().getName() + " :- findAllAudit()");
        JSONObject result = new JSONObject();
        try {
            List<Audit> audit = auditRepository.findAll();
            if (audit != null) {
                result.put("status", 200);
                result.put("response", audit);
            } else {
                result.put("status", 302);
                result.put("response", "Audit Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAllAudit for id : {} and exception : {} ", e.getMessage());
            log.trace("Exception in findAllAudit for id : {} and trace : {} ", e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public JSONObject findAuditByTemplateId(Integer auditId) {
        log.info(this.getClass().getName() + " :- findAuditByTemplateId()");
        JSONObject result = new JSONObject();
        try {
            Template template = templateRepository.findById(auditId).get();
            List<Audit> auditList = auditRepository.findByTemplate(template);
            if (auditList != null) {
                result.put("status", 200);
                result.put("response", auditList);
            } else {
                result.put("status", 302);
                result.put("response", "Audit Not found");
            }

        } catch (Exception e) {

            log.error("Exception in findAuditByTemplateId for auditId : {} and exception : {} ", auditId, e.getMessage());
            log.trace("Exception in findAuditByTemplateId for auditId : {} and trace : {} ", auditId, e.getStackTrace());
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    public ByteArrayInputStream downloadAuditReport(AuditReport auditReport) {
        ResultSet rs = null;
//        PreparedStatement ps = null;
        CallableStatement ps = null;
        Connection conn = null;
        List<String> headers = new ArrayList<>();
        List<List<String>> data = new ArrayList<>();
        try {
            conn = ConnPool.getInstance().getConnection();
            String fromDate = FileUtils.getStringFromString(auditReport.getFromDate());
            String toDate = FileUtils.getStringFromString(auditReport.getToDate());
            String SQL = "{ call getReportDataByAuditId(?, ?, ?) }";

            System.out.println("fromDate : " + fromDate + " toDate: " + toDate + " auditId : " + auditReport.getAuditId() + " sql :" + SQL);

            ps = conn.prepareCall(SQL);
            ps.setInt(1, auditReport.getAuditId());
            ps.setString(2, fromDate);
            ps.setString(3, toDate);

            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            for (int i = 1; i <= columnCount; i++) {
                String name = rsmd.getColumnName(i);
                headers.add(name);
            }

            while (rs.next()) {
                List<String> object = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    object.add(rs.getString(i));
                }
                data.add(object);
            }
        } catch (SQLException e) {
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
            throw e;

        } catch (Throwable e) {
            e.printStackTrace();
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return createAuditReportExcel(headers, data);
        }

    }

    public ByteArrayInputStream createAuditReportExcel(List<String> headers, List<List<String>> data) {
        log.info(" createAuditReportExcel excel");
        try (SXSSFWorkbook workbook = new SXSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Audit_Report");
            ArrayList<String> headerList = (ArrayList<String>) headers;
            CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 2);
            ExcelUtils.createAndWriteRowWithColor(sheet, headerList, 0, cellStyle, true, workbook,
                    IndexedColors.BLACK.getIndex(), IndexedColors.WHITE.getIndex());
            int rowCount = 1;
            try {
                cellStyle = ExcelUtils.createCellStyle(sheet, rowCount);
                for (List<String> object : data) {
                    ArrayList<String> rowData = new ArrayList<>();
                    for (String s : object) {
                        rowData.add(s);
                    }
                    ExcelUtils.createAndWriteRow(sheet, rowData, rowCount++, cellStyle, false, null);
                }
            } catch (Exception e) {
                log.error("Exception in writing sheet ", e);
                return null;
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing createAuditReportExcel excel ", e);
            return null;
        }
    }

    public ByteArrayInputStream downloadCashAuditReport(AuditReport auditReport) {
        try {
            List<Object[]> objects = auditRepository.downloadCash(auditReport.getFromDate(), auditReport.getToDate());
            Map<Integer, List<CashMasterDTO>> map = new HashMap<>();
            if (objects != null) {
                List<CashMasterDTO> tempList = new ArrayList<>();
                objects.forEach(object -> {
                    CashMasterDTO cashMasterDTO = new CashMasterDTO();
                    cashMasterDTO.setTicketId(Integer.parseInt(String.valueOf(object[0])));
                    cashMasterDTO.setDate(String.valueOf(object[1]));
                    cashMasterDTO.setQuestionId(Integer.parseInt(String.valueOf(object[2])));
                    cashMasterDTO.setSiteId(Integer.parseInt(String.valueOf(object[3])));
                    cashMasterDTO.setResponse(String.valueOf(object[4]));
                    cashMasterDTO.setSequence(Integer.parseInt(String.valueOf(object[5])));
                    tempList.add(cashMasterDTO);
                });

                map = tempList.stream().collect(Collectors.groupingBy(CashMasterDTO::getTicketId)).entrySet().stream()
                        .filter(entry -> entry.getValue().size() > 1)
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
            }
            List<List<String>> rowData = new ArrayList<>();
            if (map.size() > 0) {

                Map<Integer, Site> siteMap = AuditApplication.siteMap.values().stream()
                        .collect(Collectors.toList()).stream().collect(
                                Collectors.toMap(Site::getSiteId, Site::getClassObject));
                map.forEach((ticketId, cashMasterDTO) -> {
                    rowData.add(getCashRowDataWithCalculation(ticketId, cashMasterDTO, siteMap));
                });
            }
            return createExcelCashReport(rowData);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in download cash");
            return null;
        }
    }

    private List<String> getCashRowDataWithCalculation(Integer ticketId, List<CashMasterDTO> cashMasterDTO, Map<Integer, Site> siteMap) {
        Map<Integer, CashMasterDTO> responseMap = cashMasterDTO.stream().collect(
                Collectors.toMap(CashMasterDTO::getQuestionId, CashMasterDTO::getClassObject));
        List<String> rowData = new ArrayList<>();
        Site site = siteMap.get(cashMasterDTO.get(0).getSiteId());
        rowData.add(cashMasterDTO.get(0).getDate()); // date of audit
        rowData.add(site.getSiteCode()); // sitecode
        rowData.add(site.getAssets()); // assets
        rowData.add("NA"); // bank names
        rowData.add(site.getSiteAddress()); // locations
        rowData.add(site.getCity()); // district
        rowData.add(site.getState()); // state
        rowData.add(cashMasterDTO.get(0).getDate()); // timeOfAUdit
        rowData.add(getStringValue(responseMap.get(456))); // Name of Auditor
        rowData.add(getStringValue(responseMap.get(457))); // Name of custodian 1
        rowData.add(getStringValue(responseMap.get(458))); // Name of custodian 2

        rowData.add((getIntegerValue(getStringValue(responseMap.get(449))) * 100) + ""); // PHYSICAL CASH - Starting cash 100
        rowData.add((getIntegerValue(getStringValue(responseMap.get(455))) * 200) + ""); // PHYSICAL CASH - Starting cash 200
        rowData.add((getIntegerValue(getStringValue(responseMap.get(464))) * 500) + ""); // PHYSICAL CASH - Starting cash 500
        rowData.add((getIntegerValue(getStringValue(responseMap.get(470))) * 2000) + ""); // PHYSICAL CASH - Starting cash 2000
        rowData.add((
                (getIntegerValue(getStringValue(responseMap.get(449))) * 100) +
                        (getIntegerValue(getStringValue(responseMap.get(455))) * 200) +
                        (getIntegerValue(getStringValue(responseMap.get(464))) * 500) +
                        (getIntegerValue(getStringValue(responseMap.get(470))) * 2000)) + ""); // PHYSICAL CASH - Starting cash TOTAL

        rowData.add((getIntegerValue(getStringValue(responseMap.get(477))) * 100) + ""); // ATM COUNTER - Starting cash	 100
        rowData.add((getIntegerValue(getStringValue(responseMap.get(484))) * 200) + ""); // ATM COUNTER - Starting cash 200
        rowData.add((getIntegerValue(getStringValue(responseMap.get(491))) * 500) + ""); // ATM COUNTER - Starting cash 500
        rowData.add((getIntegerValue(getStringValue(responseMap.get(498))) * 2000) + ""); // ATM COUNTER - Starting cash 2000
        rowData.add((
                (getIntegerValue(getStringValue(responseMap.get(477))) * 100) +
                        (getIntegerValue(getStringValue(responseMap.get(484))) * 200) +
                        (getIntegerValue(getStringValue(responseMap.get(491))) * 500) +
                        (getIntegerValue(getStringValue(responseMap.get(498))) * 2000)) + ""); // ATM COUNTER - Starting cash Total

        rowData.add((getIntegerValue(getStringValue(responseMap.get(505)))) + ""); // SWITCH COUNTER - Starting cash	 100
        rowData.add((getIntegerValue(getStringValue(responseMap.get(512)))) + ""); // SWITCH COUNTER - Starting cash 200
        rowData.add((getIntegerValue(getStringValue(responseMap.get(519)))) + ""); // SWITCH COUNTER - Starting cash 500
        rowData.add((getIntegerValue(getStringValue(responseMap.get(526)))) + ""); // SWITCH COUNTER - Starting cash 2000
        rowData.add((
                (getIntegerValue(getStringValue(responseMap.get(505)))) +
                        (getIntegerValue(getStringValue(responseMap.get(512)))) +
                        (getIntegerValue(getStringValue(responseMap.get(519)))) +
                        (getIntegerValue(getStringValue(responseMap.get(526))))) + ""); // SWITCH COUNTER - Starting cash Total

        Integer physicalTotal = (getIntegerValue(getStringValue(responseMap.get(449))) * 100) +
                (getIntegerValue(getStringValue(responseMap.get(455))) * 200) +
                (getIntegerValue(getStringValue(responseMap.get(464))) * 500) +
                (getIntegerValue(getStringValue(responseMap.get(470))) * 2000);

        Integer atmTotal = (getIntegerValue(getStringValue(responseMap.get(477))) * 100) +
                (getIntegerValue(getStringValue(responseMap.get(484))) * 200) +
                (getIntegerValue(getStringValue(responseMap.get(491))) * 500) +
                (getIntegerValue(getStringValue(responseMap.get(498))) * 2000);

        Integer switchTotal = (getIntegerValue(getStringValue(responseMap.get(505)))) +
                (getIntegerValue(getStringValue(responseMap.get(512)))) +
                (getIntegerValue(getStringValue(responseMap.get(519)))) +
                (getIntegerValue(getStringValue(responseMap.get(526))));

        Integer shortage = 0;
        if (atmTotal.equals(switchTotal)) {
            shortage = (switchTotal - physicalTotal);
        }


        rowData.add((shortage > 0 ? shortage : 0) + ""); //  calculate Shortage
        rowData.add((shortage < 0 ? (physicalTotal - switchTotal) : 0) + ""); //  calculate Overage
        if (physicalTotal.equals(atmTotal)) {
            rowData.add((atmTotal - switchTotal) + ""); // todo calculate Switch Difference
        } else {
            rowData.add((0) + "");
        }
        if (physicalTotal.equals(switchTotal)) {
            rowData.add((switchTotal - atmTotal) + "");
        } else {
            rowData.add((0) + "");

        } // todo calculate  Base Difference

        if ((getIntegerValue(getStringValue(responseMap.get(477))) * 100) == (getIntegerValue(getStringValue(responseMap.get(505))))) {
            Integer overage100 = ((getIntegerValue(getStringValue(responseMap.get(505)))) - (getIntegerValue(getStringValue(responseMap.get(449))) * 100));
            rowData.add((overage100 > 0 ? overage100 : 0) + ""); // todo calculate SHORTAGE	100
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(484))) * 200) == ((getIntegerValue(getStringValue(responseMap.get(512)))))) {
            Integer overage200 = ((getIntegerValue(getStringValue(responseMap.get(512)))) - (getIntegerValue(getStringValue(responseMap.get(455))) * 200));
            rowData.add((overage200 > 0 ? overage200 : 0) + ""); // todo calculate SHORTAGE	200
        } else {
            rowData.add((0) + "");

        }
        if ((getIntegerValue(getStringValue(responseMap.get(491))) * 500) == (getIntegerValue(getStringValue(responseMap.get(519))))) {
            Integer overage500 = ((getIntegerValue(getStringValue(responseMap.get(519)))) - (getIntegerValue(getStringValue(responseMap.get(464))) * 500));
            rowData.add((overage500 > 0 ? overage500 : 0) + ""); // todo calculate SHORTAGE	500
        } else {
            rowData.add((0) + "");
        }
        if ((getIntegerValue(getStringValue(responseMap.get(498))) * 2000) == (getIntegerValue(getStringValue(responseMap.get(526))))) {
            Integer overage2000 = ((getIntegerValue(getStringValue(responseMap.get(526)))) - (getIntegerValue(getStringValue(responseMap.get(470))) * 2000));
            rowData.add((overage2000 > 0 ? overage2000 : 0) + ""); // todo calculate SHORTAGE	2000
        } else {
            rowData.add((0) + "");
        }
        rowData.add((shortage > 0 ? shortage : 0) + ""); // todo calculate SHORTAGE	Total

        if ((getIntegerValue(getStringValue(responseMap.get(477))) * 100) == (getIntegerValue(getStringValue(responseMap.get(505))))) {
            Integer overage100 = ((getIntegerValue(getStringValue(responseMap.get(505)))) - (getIntegerValue(getStringValue(responseMap.get(449))) * 100));
            if (overage100 < 0) {
                rowData.add(((getIntegerValue(getStringValue(responseMap.get(449))) * 100) - (getIntegerValue(getStringValue(responseMap.get(505))))) + ""); // todo calculate OVERAGE	100
            } else {
                rowData.add((0) + "");
            }
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(484))) * 200) == ((getIntegerValue(getStringValue(responseMap.get(512)))))) {
            Integer overage200 = ((getIntegerValue(getStringValue(responseMap.get(512)))) - (getIntegerValue(getStringValue(responseMap.get(455))) * 200));
            if (overage200 < 0) {
                rowData.add(((getIntegerValue(getStringValue(responseMap.get(455))) * 200) - (getIntegerValue(getStringValue(responseMap.get(512))))) + ""); // todo calculate OVERAGE	200
            } else {
                rowData.add((0) + "");

            }
        } else {
            rowData.add((0) + "");

        }
        if ((getIntegerValue(getStringValue(responseMap.get(491))) * 500) == (getIntegerValue(getStringValue(responseMap.get(519))))) {
            Integer overage500 = ((getIntegerValue(getStringValue(responseMap.get(519)))) - (getIntegerValue(getStringValue(responseMap.get(464))) * 500));
            if (overage500 < 0) {
                rowData.add(((getIntegerValue(getStringValue(responseMap.get(464))) * 500) - (getIntegerValue(getStringValue(responseMap.get(519))))) + ""); // todo calculate SHORTAGE	500
            } else {
                rowData.add((0) + "");
            }
        } else {
            rowData.add((0) + "");
        }
        if ((getIntegerValue(getStringValue(responseMap.get(498))) * 2000) == (getIntegerValue(getStringValue(responseMap.get(526))))) {
            Integer overage2000 = ((getIntegerValue(getStringValue(responseMap.get(526)))) - (getIntegerValue(getStringValue(responseMap.get(470))) * 2000));
            if (overage2000 < 0) {
                rowData.add(((getIntegerValue(getStringValue(responseMap.get(470))) * 2000) - (getIntegerValue(getStringValue(responseMap.get(526))))) + ""); // todo calculate OVERAGE	2000
            } else {
                rowData.add((0) + "");
            }
        } else {
            rowData.add((0) + "");
        }
        rowData.add((shortage < 0 ? (physicalTotal - switchTotal) : 0) + ""); // todo calculate OVERAGE	Total

        if ((getIntegerValue(getStringValue(responseMap.get(505)))) == (getIntegerValue(getStringValue(responseMap.get(449))) * 100)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(505)))) - (getIntegerValue(getStringValue(responseMap.get(477))) * 100)) + ""); // todo calculate BASE  DIFFERENCE	100
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(512)))) == (getIntegerValue(getStringValue(responseMap.get(455))) * 200)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(512)))) - (getIntegerValue(getStringValue(responseMap.get(484))) * 200)) + ""); // todo calculate BASE  DIFFERENCE	200
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(519)))) == (getIntegerValue(getStringValue(responseMap.get(464))) * 500)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(519)))) - (getIntegerValue(getStringValue(responseMap.get(491))) * 500)) + ""); // todo calculate BASE  DIFFERENCE	500
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(526)))) == (getIntegerValue(getStringValue(responseMap.get(470))) * 2000)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(526)))) - (getIntegerValue(getStringValue(responseMap.get(498))) * 2000)) + ""); // todo calculate BASE  DIFFERENCE	2000
        } else {
            rowData.add((0) + "");
        }

        if (physicalTotal.equals(switchTotal)) {
            rowData.add((switchTotal - atmTotal) + "");
        } else {
            rowData.add((0) + "");

        }  // todo calculate BASE  DIFFERENCE	Total
/*      Logic
        if (physicalTotal.equals(atmTotal)) {
            rowData.add((atmTotal - switchTotal) + ""); // todo calculate Switch Difference
        }*/

        if ((getIntegerValue(getStringValue(responseMap.get(477))) * 100) == (getIntegerValue(getStringValue(responseMap.get(449))) * 100)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(477))) * 100) - (getIntegerValue(getStringValue(responseMap.get(505))))) + ""); // todo calculate Switch  DIFFERENCE	100
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(484))) * 200) == (getIntegerValue(getStringValue(responseMap.get(455))) * 200)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(484))) * 200) - (getIntegerValue(getStringValue(responseMap.get(512))))) + ""); // todo calculate Switch  DIFFERENCE	200
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(491))) * 500) == (getIntegerValue(getStringValue(responseMap.get(464))) * 500)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(491))) * 500) - (getIntegerValue(getStringValue(responseMap.get(519))))) + ""); // todo calculate Switch  DIFFERENCE	500
        } else {
            rowData.add((0) + "");
        }

        if ((getIntegerValue(getStringValue(responseMap.get(498))) * 2000) == (getIntegerValue(getStringValue(responseMap.get(470))) * 2000)) {
            rowData.add(((getIntegerValue(getStringValue(responseMap.get(498))) * 2000) - (getIntegerValue(getStringValue(responseMap.get(526))))) + ""); // todo calculate Switch  DIFFERENCE	2000
        } else {
            rowData.add((0) + "");
        }

        if (physicalTotal.equals(atmTotal)) {
            rowData.add((atmTotal - switchTotal) + "");
        } else {
            rowData.add((0) + "");

        }  // todo calculate Switch  DIFFERENCE	Total

        // ==========================================================================================
        rowData.add(getStringValue(responseMap.get(528))); // TORNED / MUTILATED NOTES 100
        rowData.add(getStringValue(responseMap.get(529))); // TORNED / MUTILATED NOTES 200
        rowData.add(getStringValue(responseMap.get(530))); // TORNED / MUTILATED NOTES 500
        rowData.add(getStringValue(responseMap.get(531))); // TORNED / MUTILATED NOTES 2000

        rowData.add((
                (getIntegerValue(getStringValue(responseMap.get(528))) * 100) +
                        (getIntegerValue(getStringValue(responseMap.get(529))) * 200) +
                        (getIntegerValue(getStringValue(responseMap.get(530))) * 500) +
                        (getIntegerValue(getStringValue(responseMap.get(531))) * 2000)) + "");  // TORNED / MUTILATED NOTES Total

        rowData.add(getStringValue(responseMap.get(607))); // Is the Gunman with Valid Gun License
        rowData.add(getStringValue(responseMap.get(608))); // S & G Activated or Not
        rowData.add(getStringValue(responseMap.get(609))); // S & G Serial No
        rowData.add(getStringValue(responseMap.get(610))); // Number of Cassettes in the ATM
        rowData.add(getStringValue(responseMap.get(611))); // Number of Faulty Cassettes
        rowData.add(getStringValue(responseMap.get(612))); // Cash Kept outside the Cassettes
        rowData.add(getStringValue(responseMap.get(613))); // ATM MACHINE GROUTING DONE OR NOT?

        rowData.add(getStringValue(responseMap.get(532))); // Remark
        rowData.add(getStringValue(responseMap.get(534))); // Base Difference Remark
        rowData.add(getStringValue(responseMap.get(533))); // Counter last cleared date
        return rowData;
    }

    public String getStringValue(CashMasterDTO cashMasterDTO) {
        if (cashMasterDTO != null) {
            return cashMasterDTO.getResponse();
        } else {
            return "";
        }
    }

    public Integer getIntegerValue(String sValue) {
        if (sValue == null || sValue.trim().isEmpty()) {
            return 0;
        } else {
            try {
                return Integer.parseInt(sValue);
            } catch (Exception e) {
                log.error("Exception in parsing Integer : {}", e.getMessage());
                return 0;
            }
        }
    }

    public ByteArrayInputStream createExcelCashReport(List<List<String>> data) {
        log.info(" createExcelCashReport excel");
        try (SXSSFWorkbook workbook = new SXSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("CashAuditMaster_REPORT");

            ExcelUtils.mergeCellWithColor(sheet, "", 0, 0, 0, 10, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());
            ExcelUtils.mergeCellWithColor(sheet, "PHYSICAL CASH - Starting cash", 0, 0, 11, 15, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());

            ExcelUtils.mergeCellWithColor(sheet, "ATM COUNTER - Starting cash", 0, 0, 16, 20, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());
            ExcelUtils.mergeCellWithColor(sheet, "SWITCH COUNTER - Starting cash", 0, 0, 21, 25, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());

            ExcelUtils.mergeCellWithColor(sheet, "", 0, 0, 26, 29, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());

            ExcelUtils.mergeCellWithColor(sheet, "SHORTAGE", 0, 0, 30, 34, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());
            ExcelUtils.mergeCellWithColor(sheet, "OVERAGE", 0, 0, 35, 39, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());
            ExcelUtils.mergeCellWithColor(sheet, "BASE DIFFERENCE", 0, 0, 40, 44, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());
            ExcelUtils.mergeCellWithColor(sheet, "SWITCH DIFFERENCE", 0, 0, 45, 49, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());
            ExcelUtils.mergeCellWithColor(sheet, "TORNED/MUTILATED NOTES", 0, 0, 50, 55, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());
            ExcelUtils.mergeCellWithColor(sheet, "", 0, 0, 56, 64, 0,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE.getIndex());

            ArrayList<String> headerList = new ArrayList<>(Arrays.asList("DATE OF AUDIT", "SITE CODE",
                    "ATM ID", "BANK NAME", "LOCATION", "District", "State", "TIME OF AUDIT", "NAME OF AUDITOR",
                    "NAME OF CUS-1", "NAME OF CUS-2", "100", "200", "500",
                    "2000", "Total(Rs)", "100", "200", "500", "2000", "Total(Rs)", "100", "200", "500",
                    "2000", "Total(Rs)", "Shortage", "Overage", "Switch Difference", "Base Difference", "100", "200", "500", "2000"
                    , "Total(Rs)", "100", "200", "500", "2000", "Total(Rs)", "100", "200", "500", "2000", "Total(Rs)", "100", "200", "500", "2000",
                    "Total(Rs)", "100", "200", "500", "2000",
                    "Total(Rs)", "Is the Gunman with Valid Gun License", "S & G Activated or Not", "S & G Serial No",
                    "Number of Cassettes in the ATM", "Number of Faulty Cassettes", "Cash Kept outside the Cassettes",
                    "ATM MACHINE GROUTING DONE OR NOT?", "Remark", "Base Difference Remark", "Counter last cleared date"));
            CellStyle cellStyle = ExcelUtils.createCellStyle(sheet, 1);
            ExcelUtils.createAndWriteRowWithColor(sheet, headerList, 1, cellStyle, true, workbook,
                    IndexedColors.WHITE.getIndex(), IndexedColors.BLUE1.getIndex());

            int rowCount = 2;
            try {
                cellStyle = ExcelUtils.createCellStyle(sheet, rowCount);
                for (List<String> object : data) {
                    ArrayList<String> rowData = new ArrayList<>();
                    for (String s : object) {
                        rowData.add(s);
                    }
                    ExcelUtils.createAndWriteRow(sheet, rowData, rowCount++, cellStyle, false, null);
                }
            } catch (Exception e) {
                log.error("Exception in writing sheet ", e);
                return null;
            }
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in writing create excel cash report excel ", e);
            return null;
        }
    }

    public JSONObject getShortageOverage(Integer ticketId) {
        JSONObject result = new JSONObject();
        try {
            List<Object[]> objects = auditRepository.getShortageOverage(ticketId);
            Map<Integer, List<CashMasterDTO>> map = new HashMap<>();

            List<CashMasterDTO> tempList = new ArrayList<>();

            if (objects != null) {
                objects.forEach(object -> {
                    CashMasterDTO cashMasterDTO = new CashMasterDTO();
                    cashMasterDTO.setTicketId(Integer.parseInt(String.valueOf(object[0])));
                    cashMasterDTO.setDate(String.valueOf(object[1]));
                    cashMasterDTO.setQuestionId(Integer.parseInt(String.valueOf(object[2])));
                    cashMasterDTO.setSiteId(Integer.parseInt(String.valueOf(object[3])));
                    cashMasterDTO.setResponse(String.valueOf(object[4]));
                    cashMasterDTO.setSequence(Integer.parseInt(String.valueOf(object[5])));
                    tempList.add(cashMasterDTO);
                });

            }

                Map<Integer, Site> siteMap = AuditApplication.siteMap.values().stream()
                        .collect(Collectors.toList()).stream().collect(
                                Collectors.toMap(Site::getSiteId, Site::getClassObject));

                 JSONObject response =   getCashRowDataWithCalculationV2(ticketId, tempList, siteMap);

            result.put("status", 200);
            result.put("response", response);
            result.put("message", "DONE");
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in getShortageOverage");
            return null;
        }
    }


    private JSONObject getCashRowDataWithCalculationV2(Integer ticketId, List<CashMasterDTO> cashMasterDTO, Map<Integer, Site> siteMap) {
        Map<Integer, CashMasterDTO> responseMap = cashMasterDTO.stream().collect(
                Collectors.toMap(CashMasterDTO::getQuestionId, CashMasterDTO::getClassObject));
        List<String> rowData = new ArrayList<>();
        Site site = siteMap.get(cashMasterDTO.get(0).getSiteId());

        Integer physicalTotal = (getIntegerValue(getStringValue(responseMap.get(449))) * 100) +
                (getIntegerValue(getStringValue(responseMap.get(455))) * 200) +
                (getIntegerValue(getStringValue(responseMap.get(464))) * 500) +
                (getIntegerValue(getStringValue(responseMap.get(470))) * 2000);

        Integer atmTotal = (getIntegerValue(getStringValue(responseMap.get(477))) * 100) +
                (getIntegerValue(getStringValue(responseMap.get(484))) * 200) +
                (getIntegerValue(getStringValue(responseMap.get(491))) * 500) +
                (getIntegerValue(getStringValue(responseMap.get(498))) * 2000);

        Integer switchTotal = (getIntegerValue(getStringValue(responseMap.get(505)))) +
                (getIntegerValue(getStringValue(responseMap.get(512)))) +
                (getIntegerValue(getStringValue(responseMap.get(519)))) +
                (getIntegerValue(getStringValue(responseMap.get(526))));

        Integer shortage = 0;
        if (atmTotal.equals(switchTotal)) {
            shortage = (switchTotal - physicalTotal);
        }
        JSONObject response = new JSONObject();
        response.put("shortage", (shortage > 0 ? shortage : 0) + "");
        response.put("overage", (shortage < 0 ? (physicalTotal - switchTotal) : 0) + "");


        return response;
    }

	public JSONObject getCashAuditResponse(Integer ticketId) {
		JSONObject result = new JSONObject();
        try {
            List<Object[]> objects = auditRepository.getShortageOverage(ticketId);
            Map<Integer, List<CashMasterDTO>> map = new HashMap<>();

            List<CashMasterDTO> tempList = new ArrayList<>();

            if (objects != null) {
                objects.forEach(object -> {
                    CashMasterDTO cashMasterDTO = new CashMasterDTO();
                    cashMasterDTO.setTicketId(Integer.parseInt(String.valueOf(object[0])));
                    cashMasterDTO.setDate(String.valueOf(object[1]));
                    cashMasterDTO.setQuestionId(Integer.parseInt(String.valueOf(object[2])));
                    cashMasterDTO.setSiteId(Integer.parseInt(String.valueOf(object[3])));
                    cashMasterDTO.setResponse(String.valueOf(object[4]));
                    cashMasterDTO.setSequence(Integer.parseInt(String.valueOf(object[5])));
                    tempList.add(cashMasterDTO);
                });

            }

                Map<Integer, Site> siteMap = AuditApplication.siteMap.values().stream()
                        .collect(Collectors.toList()).stream().collect(
                                Collectors.toMap(Site::getSiteId, Site::getClassObject));

                 JSONObject response = getCashAuditResponseWithCalculation(ticketId, tempList, siteMap);

            result.put("status", 200);
            result.put("response", response);
            result.put("message", "DONE");
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in getCashAuditResponse");
            return null;
        }
	}
	
	private JSONObject getCashAuditResponseWithCalculation(Integer ticketId, List<CashMasterDTO> cashMasterDTO, Map<Integer, Site> siteMap) {
        Map<Integer, CashMasterDTO> responseMap = cashMasterDTO.stream().collect(
                Collectors.toMap(CashMasterDTO::getQuestionId, CashMasterDTO::getClassObject));
        JSONObject jsonObject = new JSONObject();
        Site site = siteMap.get(cashMasterDTO.get(0).getSiteId());
        jsonObject.put("dateOfAudit", cashMasterDTO.get(0).getDate()); // date of audit
        jsonObject.put("siteCode", site.getSiteCode()); // sitecode
        jsonObject.put("atmId", site.getAssets()); // assets
        jsonObject.put("bankName", "NA"); // bank names
        jsonObject.put("location", site.getSiteAddress()); // locations
        jsonObject.put("district", site.getCity()); // district
        jsonObject.put("state", site.getState()); // state
        jsonObject.put("timeOfAudit", cashMasterDTO.get(0).getDate()); // timeOfAUdit
        jsonObject.put("nameOfAuditor", getStringValueV2(responseMap.get(456))); // Name of Auditor
        jsonObject.put("nameOfCus_1", getStringValueV2(responseMap.get(457))); // Name of custodian 1
        jsonObject.put("nameOfCus_2", getStringValueV2(responseMap.get(458))); // Name of custodian 2

        jsonObject.put("physicalCash_InCassette_100", (getIntegerValue(getStringValueV2(responseMap.get(445))) * 100) + ""); // PHYSICAL CASH - In Cassette 100
        jsonObject.put("physicalCash_InDivertTray_100", (getIntegerValue(getStringValueV2(responseMap.get(446))) * 100) + ""); // PHYSICAL CASH - In Divert Tray 100
        jsonObject.put("physicalCash_totalRemaining_100", (getIntegerValue(getStringValueV2(responseMap.get(447))) * 100) + ""); // PHYSICAL CASH - Total Remaining 100
        jsonObject.put("physicalCash_loadingDonebyCRADuringAudit_100", (getIntegerValue(getStringValueV2(responseMap.get(448))) * 100) + ""); // PHYSICAL CASH - loadingDonebyCRADuringAudit 100
        jsonObject.put("physicalCash_tomorrowStartingCash_100", (getIntegerValue(getStringValueV2(responseMap.get(449))) * 100) + ""); // PHYSICAL CASH - Tomorrow'S Starting cash 100
        
        jsonObject.put("physicalCash_InCassette_200", (getIntegerValue(getStringValueV2(responseMap.get(451))) * 200) + ""); // PHYSICAL CASH - In Cassette 200
        jsonObject.put("physicalCash_InDivertTray_200", (getIntegerValue(getStringValueV2(responseMap.get(452))) * 200) + ""); // PHYSICAL CASH - In Divert Tray 200
        jsonObject.put("physicalCash_totalRemaining_200", (getIntegerValue(getStringValueV2(responseMap.get(453))) * 200) + ""); // PHYSICAL CASH - Total Remaining 200
        jsonObject.put("physicalCash_loadingDonebyCRADuringAudit_200", (getIntegerValue(getStringValueV2(responseMap.get(454))) * 200) + ""); // PHYSICAL CASH - loadingDonebyCRADuringAudit 200
        jsonObject.put("physicalCash_tomorrowStartingCash_200", (getIntegerValue(getStringValueV2(responseMap.get(455))) * 200) + ""); // PHYSICAL CASH - Tomorrow'S Starting cash 200
        
        jsonObject.put("physicalCash_InCassette_500", (getIntegerValue(getStringValueV2(responseMap.get(460))) * 500) + ""); // PHYSICAL CASH - In Cassette 500
        jsonObject.put("physicalCash_InDivertTray_500", (getIntegerValue(getStringValueV2(responseMap.get(461))) * 500) + ""); // PHYSICAL CASH - In Divert Tray 500
        jsonObject.put("physicalCash_totalRemaining_500", (getIntegerValue(getStringValueV2(responseMap.get(462))) * 500) + ""); // PHYSICAL CASH - Total Remaining 500
        jsonObject.put("physicalCash_loadingDonebyCRADuringAudit_500", (getIntegerValue(getStringValueV2(responseMap.get(463))) * 500) + ""); // PHYSICAL CASH - loadingDonebyCRADuringAudit 500
        jsonObject.put("physicalCash_tomorrowStartingCash_500", (getIntegerValue(getStringValueV2(responseMap.get(464))) * 500) + ""); // PHYSICAL CASH - Tomorrow'S Starting cash 500
        
        jsonObject.put("physicalCash_InCassette_2000", (getIntegerValue(getStringValueV2(responseMap.get(466))) * 2000) + ""); // PHYSICAL CASH - In Cassette 2000
        jsonObject.put("physicalCash_InDivertTray_2000", (getIntegerValue(getStringValueV2(responseMap.get(467))) * 2000) + ""); // PHYSICAL CASH - In Divert Tray 2000
        jsonObject.put("physicalCash_totalRemaining_2000", (getIntegerValue(getStringValueV2(responseMap.get(468))) * 2000) + ""); // PHYSICAL CASH - Total Remaining 2000
        jsonObject.put("physicalCash_loadingDonebyCRADuringAudit_2000", (getIntegerValue(getStringValueV2(responseMap.get(469))) * 2000) + ""); // PHYSICAL CASH - loadingDonebyCRADuringAudit 2000
        jsonObject.put("physicalCash_tomorrowStartingCash_2000", (getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000) + ""); // PHYSICAL CASH - Tomorrow'S Starting cash 2000
        jsonObject.put("physicalCash_total_Rs", (
                (getIntegerValue(getStringValueV2(responseMap.get(449))) * 100) +
                        (getIntegerValue(getStringValueV2(responseMap.get(455))) * 200) +
                        (getIntegerValue(getStringValueV2(responseMap.get(464))) * 500) +
                        (getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000)) + ""); // PHYSICAL CASH - Starting cash TOTAL

        jsonObject.put("atmCounter_openingCount_100", (getIntegerValue(getStringValueV2(responseMap.get(472))) * 100) + ""); // ATM COUNTER - Opening Count	100
        jsonObject.put("atmCounter_notesDispensed_100", (getIntegerValue(getStringValueV2(responseMap.get(473))) * 100) + ""); // ATM COUNTER - Notes Dispensed	100
        jsonObject.put("atmCounter_notesInDivert_100", (getIntegerValue(getStringValueV2(responseMap.get(474))) * 100) + ""); // ATM COUNTER - Notes In Divert 100
        jsonObject.put("atmCounter_remainingCashCount_100", (getIntegerValue(getStringValueV2(responseMap.get(475))) * 100) + ""); // ATM COUNTER - Remaining Cash Count 100
        jsonObject.put("atmCounter_notesAddedToday_100", (getIntegerValue(getStringValueV2(responseMap.get(476))) * 100) + ""); // ATM COUNTER - Notes Added Today 100
        jsonObject.put("atmCounter_tomorrowStartingCash_100", (getIntegerValue(getStringValueV2(responseMap.get(477))) * 100) + ""); // ATM COUNTER - Tomorrow'S Starting cash 100
        
        jsonObject.put("atmCounter_openingCount_200", (getIntegerValue(getStringValueV2(responseMap.get(479))) * 200) + ""); // ATM COUNTER - Opening Count	200
        jsonObject.put("atmCounter_notesDispensed_200", (getIntegerValue(getStringValueV2(responseMap.get(480))) * 200) + ""); // ATM COUNTER - Notes Dispensed	200
        jsonObject.put("atmCounter_notesInDivert_200", (getIntegerValue(getStringValueV2(responseMap.get(481))) * 200) + ""); // ATM COUNTER - Notes In Divert 200
        jsonObject.put("atmCounter_remainingCashCount_200", (getIntegerValue(getStringValueV2(responseMap.get(482))) * 200) + ""); // ATM COUNTER - Remaining Cash Count 200
        jsonObject.put("atmCounter_notesAddedToday_200", (getIntegerValue(getStringValueV2(responseMap.get(483))) * 200) + ""); // ATM COUNTER - Notes Added Today 200
        jsonObject.put("atmCounter_tomorrowStartingCash_200", (getIntegerValue(getStringValueV2(responseMap.get(484))) * 200) + ""); // ATM COUNTER - Tomorrow'S Starting cash 200
        
        jsonObject.put("atmCounter_openingCount_500", (getIntegerValue(getStringValueV2(responseMap.get(486))) * 500) + ""); // ATM COUNTER - Opening Count	500
        jsonObject.put("atmCounter_notesDispensed_500", (getIntegerValue(getStringValueV2(responseMap.get(487))) * 500) + ""); // ATM COUNTER - Notes Dispensed	500
        jsonObject.put("atmCounter_notesInDivert_500", (getIntegerValue(getStringValueV2(responseMap.get(488))) * 500) + ""); // ATM COUNTER - Notes In Divert 500
        jsonObject.put("atmCounter_remainingCashCount_500", (getIntegerValue(getStringValueV2(responseMap.get(489))) * 500) + ""); // ATM COUNTER - Remaining Cash Count 500
        jsonObject.put("atmCounter_notesAddedToday_500", (getIntegerValue(getStringValueV2(responseMap.get(490))) * 500) + ""); // ATM COUNTER - Notes Added Today 500
        jsonObject.put("atmCounter_tomorrowStartingCash_500", (getIntegerValue(getStringValueV2(responseMap.get(491))) * 500) + ""); // ATM COUNTER - Tomorrow'S Starting cash 500
        
        jsonObject.put("atmCounter_openingCount_2000", (getIntegerValue(getStringValueV2(responseMap.get(493))) * 2000) + ""); // ATM COUNTER - Opening Count 2000
        jsonObject.put("atmCounter_notesDispensed_2000", (getIntegerValue(getStringValueV2(responseMap.get(494))) * 2000) + ""); // ATM COUNTER - Notes Dispensed 2000
        jsonObject.put("atmCounter_notesInDivert_2000", (getIntegerValue(getStringValueV2(responseMap.get(495))) * 2000) + ""); // ATM COUNTER - Notes In Divert 2000
        jsonObject.put("atmCounter_remainingCashCount_2000", (getIntegerValue(getStringValueV2(responseMap.get(496))) * 2000) + ""); // ATM COUNTER - Remaining Cash Count 2000
        jsonObject.put("atmCounter_notesAddedToday_2000", (getIntegerValue(getStringValueV2(responseMap.get(497))) * 2000) + ""); // ATM COUNTER - Notes Added Today 2000
        jsonObject.put("atmCounter_tomorrowStartingCash_2000", (getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000) + ""); // ATM COUNTER - Tomorrow'S Starting cash 2000
        jsonObject.put("atmCounter_total_Rs)", (
                (getIntegerValue(getStringValueV2(responseMap.get(477))) * 100) +
                        (getIntegerValue(getStringValueV2(responseMap.get(484))) * 200) +
                        (getIntegerValue(getStringValueV2(responseMap.get(491))) * 500) +
                        (getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000)) + ""); // ATM COUNTER - Starting cash Total

        jsonObject.put("switchCounter_startingCash_100", (getIntegerValue(getStringValueV2(responseMap.get(500)))) + ""); // SWITCH COUNTER - Starting cash 100
        jsonObject.put("switchCounter_cashDispensed_100", (getIntegerValue(getStringValueV2(responseMap.get(501)))) + ""); // SWITCH COUNTER - Cash Dispensed 100
        jsonObject.put("switchCounter_endCash_100", (getIntegerValue(getStringValueV2(responseMap.get(502)))) + ""); // SWITCH COUNTER - End Cash 100
        jsonObject.put("switchCounter_midCashDecrease_100", (getIntegerValue(getStringValueV2(responseMap.get(503)))) + ""); // SWITCH COUNTER - Mid Cash Decrease 100
        jsonObject.put("switchCounter_midCashIncrease_100", (getIntegerValue(getStringValueV2(responseMap.get(504)))) + ""); // SWITCH COUNTER - Mid Cash Increase 100
        jsonObject.put("switchCounter_tomorrowStartingCash_100", (getIntegerValue(getStringValueV2(responseMap.get(505)))) + ""); // SWITCH COUNTER - Tomorrow'S Starting cash 100
        
        jsonObject.put("switchCounter_startingCash_200", (getIntegerValue(getStringValueV2(responseMap.get(507)))) + ""); // SWITCH COUNTER - Starting cash 200
        jsonObject.put("switchCounter_cashDispensed_200", (getIntegerValue(getStringValueV2(responseMap.get(508)))) + ""); // SWITCH COUNTER - Cash Dispensed 200
        jsonObject.put("switchCounter_endCash_200", (getIntegerValue(getStringValueV2(responseMap.get(509)))) + ""); // SWITCH COUNTER - End Cash 200
        jsonObject.put("switchCounter_midCashDecrease_200", (getIntegerValue(getStringValueV2(responseMap.get(510)))) + ""); // SWITCH COUNTER - Mid Cash Decrease 200
        jsonObject.put("switchCounter_midCashIncrease_200", (getIntegerValue(getStringValueV2(responseMap.get(511)))) + ""); // SWITCH COUNTER - Mid Cash Increase 200
        jsonObject.put("switchCounter_tomorrowStartingCash_200", (getIntegerValue(getStringValueV2(responseMap.get(512)))) + ""); // SWITCH COUNTER - Tomorrow'S Starting cash 200
        
        jsonObject.put("switchCounter_startingCash_500", (getIntegerValue(getStringValueV2(responseMap.get(514)))) + ""); // SWITCH COUNTER - Starting cash 500
        jsonObject.put("switchCounter_cashDispensed_500", (getIntegerValue(getStringValueV2(responseMap.get(515)))) + ""); // SWITCH COUNTER - Cash Dispensed 500
        jsonObject.put("switchCounter_endCash_500", (getIntegerValue(getStringValueV2(responseMap.get(516)))) + ""); // SWITCH COUNTER - End Cash 500
        jsonObject.put("switchCounter_midCashDecrease_500", (getIntegerValue(getStringValueV2(responseMap.get(517)))) + ""); // SWITCH COUNTER - Mid Cash Decrease 500
        jsonObject.put("switchCounter_midCashIncrease_500", (getIntegerValue(getStringValueV2(responseMap.get(518)))) + ""); // SWITCH COUNTER - Mid Cash Increase 500
        jsonObject.put("switchCounter_tomorrowStartingCash_500", (getIntegerValue(getStringValueV2(responseMap.get(519)))) + ""); // SWITCH COUNTER - Tomorrow'S Starting cash 500
        
        jsonObject.put("switchCounter_startingCash_2000", (getIntegerValue(getStringValueV2(responseMap.get(521)))) + ""); // SWITCH COUNTER - Starting cash 2000
        jsonObject.put("switchCounter_cashDispensed_2000", (getIntegerValue(getStringValueV2(responseMap.get(522)))) + ""); // SWITCH COUNTER - Cash Dispensed 2000
        jsonObject.put("switchCounter_endCash_2000", (getIntegerValue(getStringValueV2(responseMap.get(523)))) + ""); // SWITCH COUNTER - End Cash 2000
        jsonObject.put("switchCounter_midCashDecrease_2000", (getIntegerValue(getStringValueV2(responseMap.get(524)))) + ""); // SWITCH COUNTER - Mid Cash Decrease 2000
        jsonObject.put("switchCounter_midCashIncrease_2000", (getIntegerValue(getStringValueV2(responseMap.get(525)))) + ""); // SWITCH COUNTER - Mid Cash Increase 2000
        jsonObject.put("switchCounter_tomorrowStartingCash_2000", (getIntegerValue(getStringValueV2(responseMap.get(526)))) + ""); // SWITCH COUNTER - Tomorrow'S Starting cash 2000
        jsonObject.put("switchCounter_total_Rs", (
                (getIntegerValue(getStringValueV2(responseMap.get(505)))) +
                        (getIntegerValue(getStringValueV2(responseMap.get(512)))) +
                        (getIntegerValue(getStringValueV2(responseMap.get(519)))) +
                        (getIntegerValue(getStringValueV2(responseMap.get(526))))) + ""); // SWITCH COUNTER - Starting cash Total

        Integer physicalTotal = (getIntegerValue(getStringValueV2(responseMap.get(449))) * 100) +
                (getIntegerValue(getStringValueV2(responseMap.get(455))) * 200) +
                (getIntegerValue(getStringValueV2(responseMap.get(464))) * 500) +
                (getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000);

        Integer atmTotal = (getIntegerValue(getStringValueV2(responseMap.get(477))) * 100) +
                (getIntegerValue(getStringValueV2(responseMap.get(484))) * 200) +
                (getIntegerValue(getStringValueV2(responseMap.get(491))) * 500) +
                (getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000);

        Integer switchTotal = (getIntegerValue(getStringValueV2(responseMap.get(505)))) +
                (getIntegerValue(getStringValueV2(responseMap.get(512)))) +
                (getIntegerValue(getStringValueV2(responseMap.get(519)))) +
                (getIntegerValue(getStringValueV2(responseMap.get(526))));

        Integer shortage = 0;
        if (atmTotal.equals(switchTotal)) {
            shortage = (switchTotal - physicalTotal);
        }

        jsonObject.put("shortage", (shortage > 0 ? shortage : 0) + ""); //  calculate Shortage
        jsonObject.put("overage", (shortage < 0 ? (physicalTotal - switchTotal) : 0) + ""); //  calculate Overage
        if (physicalTotal.equals(atmTotal)) {
            jsonObject.put("switchDifference", (atmTotal - switchTotal) + ""); // todo calculate Switch Difference
        } else {
            jsonObject.put("switchDifference", (0) + "");
        }
        if (physicalTotal.equals(switchTotal)) {
            jsonObject.put("baseDifference", (switchTotal - atmTotal) + "");
        } else {
            jsonObject.put("baseDifference", (0) + "");

        } // todo calculate  Base Difference

        if ((getIntegerValue(getStringValueV2(responseMap.get(477))) * 100) == (getIntegerValue(getStringValueV2(responseMap.get(505))))) {
            Integer overage100 = ((getIntegerValue(getStringValueV2(responseMap.get(505)))) - (getIntegerValue(getStringValueV2(responseMap.get(449))) * 100));
            jsonObject.put("shortage_100", (overage100 > 0 ? overage100 : 0) + ""); // todo calculate SHORTAGE	100
        } else {
            jsonObject.put("shortage_100", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(484))) * 200) == ((getIntegerValue(getStringValueV2(responseMap.get(512)))))) {
            Integer overage200 = ((getIntegerValue(getStringValueV2(responseMap.get(512)))) - (getIntegerValue(getStringValueV2(responseMap.get(455))) * 200));
            jsonObject.put("shortage_200", (overage200 > 0 ? overage200 : 0) + ""); // todo calculate SHORTAGE	200
        } else {
            jsonObject.put("shortage_200", (0) + "");

        }
        if ((getIntegerValue(getStringValueV2(responseMap.get(491))) * 500) == (getIntegerValue(getStringValueV2(responseMap.get(519))))) {
            Integer overage500 = ((getIntegerValue(getStringValueV2(responseMap.get(519)))) - (getIntegerValue(getStringValueV2(responseMap.get(464))) * 500));
            jsonObject.put("shortage_500", (overage500 > 0 ? overage500 : 0) + ""); // todo calculate SHORTAGE	500
        } else {
            jsonObject.put("shortage_500", (0) + "");
        }
        if ((getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000) == (getIntegerValue(getStringValueV2(responseMap.get(526))))) {
            Integer overage2000 = ((getIntegerValue(getStringValueV2(responseMap.get(526)))) - (getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000));
            jsonObject.put("shortage_2000", (overage2000 > 0 ? overage2000 : 0) + ""); // todo calculate SHORTAGE	2000
        } else {
            jsonObject.put("shortage_2000", (0) + "");
        }
        jsonObject.put("shortage_total_Rs", (shortage > 0 ? shortage : 0) + ""); // todo calculate SHORTAGE	Total

        if ((getIntegerValue(getStringValueV2(responseMap.get(477))) * 100) == (getIntegerValue(getStringValueV2(responseMap.get(505))))) {
            Integer overage100 = ((getIntegerValue(getStringValueV2(responseMap.get(505)))) - (getIntegerValue(getStringValueV2(responseMap.get(449))) * 100));
            if (overage100 < 0) {
                jsonObject.put("overage_100", ((getIntegerValue(getStringValueV2(responseMap.get(449))) * 100) - (getIntegerValue(getStringValueV2(responseMap.get(505))))) + ""); // todo calculate OVERAGE	100
            } else {
                jsonObject.put("overage_100", (0) + "");
            }
        } else {
            jsonObject.put("overage_100", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(484))) * 200) == ((getIntegerValue(getStringValueV2(responseMap.get(512)))))) {
            Integer overage200 = ((getIntegerValue(getStringValueV2(responseMap.get(512)))) - (getIntegerValue(getStringValueV2(responseMap.get(455))) * 200));
            if (overage200 < 0) {
                jsonObject.put("overage_200", ((getIntegerValue(getStringValueV2(responseMap.get(455))) * 200) - (getIntegerValue(getStringValueV2(responseMap.get(512))))) + ""); // todo calculate OVERAGE	200
            } else {
                jsonObject.put("overage_200", (0) + "");

            }
        } else {
            jsonObject.put("overage_200", (0) + "");

        }
        if ((getIntegerValue(getStringValueV2(responseMap.get(491))) * 500) == (getIntegerValue(getStringValueV2(responseMap.get(519))))) {
            Integer overage500 = ((getIntegerValue(getStringValueV2(responseMap.get(519)))) - (getIntegerValue(getStringValueV2(responseMap.get(464))) * 500));
            if (overage500 < 0) {
                jsonObject.put("overage_500", ((getIntegerValue(getStringValueV2(responseMap.get(464))) * 500) - (getIntegerValue(getStringValueV2(responseMap.get(519))))) + ""); // todo calculate SHORTAGE	500
            } else {
                jsonObject.put("overage_500", (0) + "");
            }
        } else {
            jsonObject.put("overage_500", (0) + "");
        }
        if ((getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000) == (getIntegerValue(getStringValueV2(responseMap.get(526))))) {
            Integer overage2000 = ((getIntegerValue(getStringValueV2(responseMap.get(526)))) - (getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000));
            if (overage2000 < 0) {
                jsonObject.put("overage_2000", ((getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000) - (getIntegerValue(getStringValueV2(responseMap.get(526))))) + ""); // todo calculate OVERAGE	2000
            } else {
                jsonObject.put("overage_2000", (0) + "");
            }
        } else {
            jsonObject.put("overage_2000", (0) + "");
        }
        jsonObject.put("overage_total_Rs", (shortage < 0 ? (physicalTotal - switchTotal) : 0) + ""); // todo calculate OVERAGE	Total
        

        if ((getIntegerValue(getStringValueV2(responseMap.get(505)))) == (getIntegerValue(getStringValueV2(responseMap.get(449))) * 100)) {
            jsonObject.put("baseDifference_100", ((getIntegerValue(getStringValueV2(responseMap.get(505)))) - (getIntegerValue(getStringValueV2(responseMap.get(477))) * 100)) + ""); // todo calculate BASE  DIFFERENCE	100
        } else {
            jsonObject.put("baseDifference_100", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(512)))) == (getIntegerValue(getStringValueV2(responseMap.get(455))) * 200)) {
            jsonObject.put("baseDifference_200", ((getIntegerValue(getStringValueV2(responseMap.get(512)))) - (getIntegerValue(getStringValueV2(responseMap.get(484))) * 200)) + ""); // todo calculate BASE  DIFFERENCE	200
        } else {
            jsonObject.put("baseDifference_200", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(519)))) == (getIntegerValue(getStringValueV2(responseMap.get(464))) * 500)) {
            jsonObject.put("baseDifference_500", ((getIntegerValue(getStringValueV2(responseMap.get(519)))) - (getIntegerValue(getStringValueV2(responseMap.get(491))) * 500)) + ""); // todo calculate BASE  DIFFERENCE	500
        } else {
            jsonObject.put("baseDifference_500", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(526)))) == (getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000)) {
            jsonObject.put("baseDifference_2000", ((getIntegerValue(getStringValueV2(responseMap.get(526)))) - (getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000)) + ""); // todo calculate BASE  DIFFERENCE	2000
        } else {
            jsonObject.put("baseDifference_2000", (0) + "");
        }

        if (physicalTotal.equals(switchTotal)) {
            jsonObject.put("baseDifference_total_Rs", (switchTotal - atmTotal) + "");
        } else {
            jsonObject.put("baseDifference_total_Rs", (0) + "");

        }  // todo calculate BASE  DIFFERENCE	Total
/*      Logic
        if (physicalTotal.equals(atmTotal)) {
            jsonObject.put("key", (atmTotal - switchTotal) + ""); // todo calculate Switch Difference
        }*/

        if ((getIntegerValue(getStringValueV2(responseMap.get(477))) * 100) == (getIntegerValue(getStringValueV2(responseMap.get(449))) * 100)) {
            jsonObject.put("switchDifference_100", ((getIntegerValue(getStringValueV2(responseMap.get(477))) * 100) - (getIntegerValue(getStringValueV2(responseMap.get(505))))) + ""); // todo calculate Switch  DIFFERENCE	100
        } else {
            jsonObject.put("switchDifference_100", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(484))) * 200) == (getIntegerValue(getStringValueV2(responseMap.get(455))) * 200)) {
            jsonObject.put("switchDifference_200", ((getIntegerValue(getStringValueV2(responseMap.get(484))) * 200) - (getIntegerValue(getStringValueV2(responseMap.get(512))))) + ""); // todo calculate Switch  DIFFERENCE	200
        } else {
            jsonObject.put("switchDifference_200", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(491))) * 500) == (getIntegerValue(getStringValueV2(responseMap.get(464))) * 500)) {
            jsonObject.put("switchDifference_500", ((getIntegerValue(getStringValueV2(responseMap.get(491))) * 500) - (getIntegerValue(getStringValueV2(responseMap.get(519))))) + ""); // todo calculate Switch  DIFFERENCE	500
        } else {
            jsonObject.put("switchDifference_500", (0) + "");
        }

        if ((getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000) == (getIntegerValue(getStringValueV2(responseMap.get(470))) * 2000)) {
            jsonObject.put("switchDifference_2000", ((getIntegerValue(getStringValueV2(responseMap.get(498))) * 2000) - (getIntegerValue(getStringValueV2(responseMap.get(526))))) + ""); // todo calculate Switch  DIFFERENCE	2000
        } else {
            jsonObject.put("switchDifference_2000", (0) + "");
        }

        if (physicalTotal.equals(atmTotal)) {
            jsonObject.put("switchDifference_total_Rs", (atmTotal - switchTotal) + "");
        } else {
            jsonObject.put("switchDifference_total_Rs", (0) + "");

        }  // todo calculate Switch  DIFFERENCE	Total

        // ==========================================================================================
        jsonObject.put("mutilatedNotes_100", getStringValueV2(responseMap.get(528))); // TORNED / MUTILATED NOTES 100
        jsonObject.put("mutilatedNotes_200", getStringValueV2(responseMap.get(529))); // TORNED / MUTILATED NOTES 200
        jsonObject.put("mutilatedNotes_500", getStringValueV2(responseMap.get(530))); // TORNED / MUTILATED NOTES 500
        jsonObject.put("mutilatedNotes_2000", getStringValueV2(responseMap.get(531))); // TORNED / MUTILATED NOTES 2000

        jsonObject.put("mutilatedNotes_total_Rs", (
                (getIntegerValue(getStringValueV2(responseMap.get(528))) * 100) +
                        (getIntegerValue(getStringValueV2(responseMap.get(529))) * 200) +
                        (getIntegerValue(getStringValueV2(responseMap.get(530))) * 500) +
                        (getIntegerValue(getStringValueV2(responseMap.get(531))) * 2000)) + "");  // TORNED / MUTILATED NOTES Total
        
        jsonObject.put("mutilatedNotes_100_amount", (getIntegerValue(getStringValueV2(responseMap.get(528))) * 100) + ""); // TORNED / MUTILATED NOTES 100 AMOUNT
        jsonObject.put("mutilatedNotes_200_amount", (getIntegerValue(getStringValueV2(responseMap.get(529))) * 200) + ""); // TORNED / MUTILATED NOTES 200 AMOUNT
        jsonObject.put("mutilatedNotes_500_amount", (getIntegerValue(getStringValueV2(responseMap.get(530))) * 500) + ""); // TORNED / MUTILATED NOTES 500 AMOUNT
        jsonObject.put("mutilatedNotes_2000_amount", (getIntegerValue(getStringValueV2(responseMap.get(531))) * 2000) + ""); // TORNED / MUTILATED NOTES 2000 AMOUNT
        
        jsonObject.put("mutilatedNotes_total_Rs_amount", (
                (getIntegerValue(getStringValueV2(responseMap.get(528))) * 100) +
                        (getIntegerValue(getStringValueV2(responseMap.get(529))) * 200) +
                        (getIntegerValue(getStringValueV2(responseMap.get(530))) * 500) +
                        (getIntegerValue(getStringValueV2(responseMap.get(531))) * 2000)) + "");  // TORNED / MUTILATED NOTES Total AMOUNT
        
        jsonObject.put("isTheGunmanwithValidGunLicense", getStringValueV2(responseMap.get(607))); // Is the Gunman with Valid Gun License
        jsonObject.put("S&GActivatedOrNot", getStringValueV2(responseMap.get(608))); // S & G Activated or Not
        jsonObject.put("S&GSerial No", getStringValueV2(responseMap.get(609))); // S & G Serial No
        jsonObject.put("numberOfCassettesInTheATM", getStringValueV2(responseMap.get(610))); // Number of Cassettes in the ATM
        jsonObject.put("numberOfFaultyCassettes", getStringValueV2(responseMap.get(611))); // Number of Faulty Cassettes
        jsonObject.put("cashKeptOutsideTheCassettes", getStringValueV2(responseMap.get(612))); // Cash Kept outside the Cassettes
        jsonObject.put("atmMachineGroutingDoneOrNot", getStringValueV2(responseMap.get(613))); // ATM MACHINE GROUTING DONE OR NOT?

        jsonObject.put("remark", getStringValueV2(responseMap.get(532))); // Remark
        jsonObject.put("baseDifferenceRemark", getStringValueV2(responseMap.get(534))); // Base Difference Remark
        jsonObject.put("counterLastClearedDate", getStringValueV2(responseMap.get(533))); // Counter last cleared date

        return jsonObject;
    }
	
	public String getStringValueV2(CashMasterDTO cashMasterDTO) {
        if (cashMasterDTO != null) {
            return cashMasterDTO.getResponse();
        } else {
            return String.valueOf(0);
        }
    }
	
	public ByteArrayInputStream downloadQRReport(AuditReport auditReport) {
        ResultSet rs = null;
//        PreparedStatement ps = null;
        CallableStatement ps = null;
        Connection conn = null;
        List<String> headers = new ArrayList<>();
        List<List<String>> data = new ArrayList<>();
        try {
            conn = ConnPool.getInstance().getConnection();
            String fromDate = FileUtils.getStringFromString(auditReport.getFromDate());
            String toDate = FileUtils.getStringFromString(auditReport.getToDate());
            String SQL = "{ call  getReportQR(?, ?) }";
            System.out.println("fromDate : " + fromDate + " toDate: " + toDate +  " sql :" + SQL);

            ps = conn.prepareCall(SQL);
            ps.setString(1, fromDate);
            ps.setString(2, toDate);

            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            for (int i = 1; i <= columnCount; i++) {
                String name = rsmd.getColumnName(i);
                headers.add(name);
            }

            while (rs.next()) {
                List<String> object = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    object.add(rs.getString(i));
                }
                data.add(object);
            }
        } catch (SQLException e) {
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
            throw e;

        } catch (Throwable e) {
            e.printStackTrace();
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return createAuditReportExcel(headers, data);
        }

    }

    public ByteArrayInputStream downloadAuditReportByTemplate(AuditReport auditReport) {
        ResultSet rs = null;
//        PreparedStatement ps = null;
        CallableStatement ps = null;
        Connection conn = null;
        List<String> headers = new ArrayList<>();
        List<List<String>> data = new ArrayList<>();
        try {
            conn = ConnPool.getInstance().getConnection();
            String fromDate = FileUtils.getStringFromString(auditReport.getFromDate());
            String toDate = FileUtils.getStringFromString(auditReport.getToDate());
            String SQL = "{ call getReportDataByTemplateId(?, ?, ?) }";

            System.out.println("fromDate : " + fromDate + " toDate: " + toDate + " templateId : " + auditReport.getTemplateId() + " sql :" + SQL);

            ps = conn.prepareCall(SQL);
            ps.setInt(1, auditReport.getTemplateId());
            ps.setString(2, fromDate);
            ps.setString(3, toDate);

            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            for (int i = 1; i <= columnCount; i++) {
                String name = rsmd.getColumnName(i);
                headers.add(name);
            }

            while (rs.next()) {
                List<String> object = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    object.add(rs.getString(i));
                }
                data.add(object);
            }
        } catch (SQLException e) {
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
            throw e;

        } catch (Throwable e) {
            e.printStackTrace();
            log.error("Exception in get result set for report : {}, Exception : {}", auditReport.toString(), e.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return createAuditReportExcel(headers, data);
        }

    }



}
