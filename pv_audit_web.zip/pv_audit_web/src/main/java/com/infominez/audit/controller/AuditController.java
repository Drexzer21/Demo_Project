package com.infominez.audit.controller;

import com.infominez.audit.entity.Audit;
import com.infominez.audit.service.AuditService;
import com.infominez.audit.wrapper.AuditReport;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.util.IOUtils;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;

@RestController
@RequestMapping("/audit")
@AllArgsConstructor
@Slf4j
public class AuditController {
    private final AuditService auditService;

    @PostMapping("/create")
    public JSONObject create(@RequestBody Audit audit) {
        log.info(this.getClass().getName() + " :- create() ");
        return auditService.createAudit(audit);
    }

    @PostMapping(  "/update")
    public JSONObject update(@RequestBody Audit audit) {
        log.info(this.getClass().getName() + " :- update() ");
        return auditService.updateAudit(audit);
    }

    @GetMapping(  "/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return auditService.findAuditById(id);
    }

    @GetMapping(  "/findAll")
    public JSONObject findAll(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAll() ");
        return auditService.findAllAudit();
    }

    @GetMapping( "/findAuditByTemplateId")
    public JSONObject findAuditByTemplateId(@QueryParam("templateId") Integer templateId) {
        log.info(this.getClass().getName() + " :- findAuditByAuditTypeId() ");
        return auditService.findAuditByTemplateId(templateId);
    }
    
    @PostMapping("/downloadAuditReport")
    public void downloadAuditReport(@RequestBody AuditReport auditReport, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info("downloadAuditReport()");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=Audit Report.xlsx");
        ByteArrayInputStream stream = auditService.downloadAuditReport(auditReport);
        IOUtils.copy(stream, response.getOutputStream());
    }
    @PostMapping("/downloadCashAuditReport")
    public void downloadCashAuditReport(@RequestBody AuditReport auditReport,HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info("downloadCashAuditMasterReport() : {}", auditReport.toString());
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=Cash Audit Report.xlsx");
        ByteArrayInputStream stream = auditService.downloadCashAuditReport(auditReport);
        IOUtils.copy(stream, response.getOutputStream());
    }

    @GetMapping("/downloadCashAuditReportV2")
    public void downloadCashAuditReportV2(HttpServletRequest request, HttpServletResponse response) throws IOException {
        AuditReport auditReport = new AuditReport();
        auditReport.setFromDate("2020-12-23 00:00:00");
        auditReport.setToDate("2020-12-23 23:00:00");
        log.info("downloadCashAuditMasterReport() : {}", auditReport.toString());
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=Cash Audit Report.xlsx");
        ByteArrayInputStream stream = auditService.downloadCashAuditReport(auditReport);
        IOUtils.copy(stream, response.getOutputStream());
    }

    @GetMapping("/getShortageOverage")
    public JSONObject getShortageOverage(@QueryParam("ticketId") Integer ticketId,HttpServletRequest request, HttpServletResponse response) {
    	log.info(this.getClass().getName() + " :- getShortageOverage() ticketId  {} : "+ ticketId);
        AuditReport auditReport = new AuditReport();
        auditReport.setFromDate("2020-12-23 00:00:00");
        auditReport.setToDate("2020-12-23 23:00:00");
        JSONObject resp = auditService.getShortageOverage(ticketId);
        return resp;
    }
    
    @GetMapping("/getCashAuditResponse")
    public JSONObject getCashAuditResponse(@QueryParam("ticketId") Integer ticketId,HttpServletRequest request, HttpServletResponse response) {
    	log.info(this.getClass().getName() + " :- getCashAuditResponse() ticketId  {} : "+ ticketId);
        JSONObject resp = auditService.getCashAuditResponse(ticketId);
        return resp;
    }
   
    @PostMapping("/downloadQRReport")
    public void downloadQRReport(@RequestBody AuditReport auditReport, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info("downloadQRReport()");
        response.setContentType("application/octet-stream");
		SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
		String fileName = "QR_Report_" + df.format(new Date()); 
        response.setHeader("Content-Disposition", "attachment; filename ="+ fileName +".xlsx");
        ByteArrayInputStream stream = auditService.downloadQRReport(auditReport);
        IOUtils.copy(stream, response.getOutputStream());
    }

    @PostMapping("/downloadAuditReportByTemplate")
    public void downloadAuditReportByTemplate(@RequestBody AuditReport auditReport, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info("downloadAuditReportByTemplate()");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=Audit_Report.xlsx");
        ByteArrayInputStream stream = auditService.downloadAuditReportByTemplate(auditReport);
        IOUtils.copy(stream, response.getOutputStream());
    }
}
