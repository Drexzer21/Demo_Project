package com.infominez.audit.security;

import com.infominez.audit.AppConfig;
import com.infominez.audit.repo.UsersRepository;
import com.infominez.audit.service.UsersService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.json.simple.JSONObject;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.Date;
import java.util.UUID;

/**
 * @author AYUSH PARTANI
 *
 */
@Component
public class TokenProvider {
	
	 private final String secretKey;

	  private final long tokenValidityInMilliseconds;

	  private final UserDetailsService userService;


	  public TokenProvider(AppConfig config, UserDetailsService userService) {
	    this.secretKey = Base64.getEncoder().encodeToString(config.getSecret().getBytes());
	    this.tokenValidityInMilliseconds = 1000 * config.getTokenValidityInSeconds();
	    this.userService = userService;
	  }

	  public String createToken(String username) {
	    Date now = new Date();
	    Date validity = new Date(now.getTime() + this.tokenValidityInMilliseconds);

	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("access_token", Jwts.builder().setId(UUID.randomUUID().toString()).setSubject(username)
	        .setIssuedAt(now).signWith(SignatureAlgorithm.HS512, this.secretKey)
	        .setExpiration(validity).compact());
	    jsonObject.put("username", username);
	    jsonObject.put("expires_in",this.tokenValidityInMilliseconds);
	    return jsonObject.toString();
	  }

	  public Authentication getAuthentication(String token) {
	    String username = Jwts.parser().setSigningKey(this.secretKey).parseClaimsJws(token)
	        .getBody().getSubject();
	    UserDetails userDetails = this.userService.loadUserByUsername(username);

	    return new UsernamePasswordAuthenticationToken(userDetails, "",
	        userDetails.getAuthorities());
	  }

	  public String getUsernameByAccessToken(String token) {
		  try {
			  return Jwts.parser().setSigningKey(this.secretKey).parseClaimsJws(token)
					  .getBody().getSubject();
		  } catch (Exception e) {
			  e.printStackTrace();
			  return null;
		  }
	  }

}
