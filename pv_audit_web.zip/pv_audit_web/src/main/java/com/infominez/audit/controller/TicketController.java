package com.infominez.audit.controller;


import com.infominez.audit.base.BaseController;
import com.infominez.audit.entity.Ticket;
import com.infominez.audit.entity.Users;
import com.infominez.audit.repo.TicketRepository;
import com.infominez.audit.repo.UsersRepository;
import com.infominez.audit.service.TicketService;
import com.infominez.audit.wrapper.TicketWrapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.util.IOUtils;
import org.json.simple.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/ticket")
@AllArgsConstructor
@Slf4j
public class TicketController extends BaseController {
    private final TicketService ticketService;
    private final TicketRepository ticketRepository;
    @PostMapping("/create")
    public JSONObject create(@RequestBody Ticket ticket) {
        log.info(this.getClass().getName() + " :- create() ");
        return ticketService.createTicket(ticket);
    }

    @PostMapping(  "/update")
    public JSONObject update(@RequestBody Ticket ticket) {
        log.info(this.getClass().getName() + " :- update() ");
        return ticketService.updateTicket(ticket);
    }

    @GetMapping(  "/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return ticketService.findTicketById(id);
    }

    @GetMapping(  "/findAll")
    public JSONObject findAll(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAll() ");
        return ticketService.findAllTicket();
    }


    @GetMapping( "/findTicketByAuditId")
    public JSONObject findTicketByAuditId(@QueryParam("auditId") Integer auditId) {
        log.info(this.getClass().getName() + " :- findTicketByAuditTypeId() ");
        return ticketService.findTicketByAuditId(auditId);
    }
    @GetMapping( "/findTicketByUsersId")
    public JSONObject findTicketByUsersId(@QueryParam("usersId") Integer usersId) {
        log.info(this.getClass().getName() + " :- findTicketByUsersId() ");
        return ticketService.findTicketByUsersId(usersId);
    }
    @GetMapping( "/findTicketBySiteId")
    public JSONObject findTicketBySiteId(@QueryParam("siteId") Integer siteId) {
        log.info(this.getClass().getName() + " :- findTicketBySiteId() ");
        return ticketService.findTicketBySiteId(siteId);
    }

    @GetMapping( "/findByStatus")
    public JSONObject findByStatus(@QueryParam("status") String status) {
        log.info(this.getClass().getName() + " :- findByStatus() ");
        return ticketService.findByStatus(status);
    }
    @PostMapping("/createMultipleObjectTicket")
    public JSONObject createMultipleObjectTicket(@RequestBody TicketWrapper ticket) {
        log.info(this.getClass().getName() + " :- createMultipleObjectTicket() ");
        return ticketService.createMultipleObjectTicket(ticket);
    }

    @GetMapping( "/getAdminDashboardData")
    public JSONObject getAdminDashboardData(HttpServletRequest httpRequest,
                                            HttpServletResponse httpResponse) {
        log.info(this.getClass().getName() + " :- getAdminDashboardData() ");
        return ticketService.getAdminDashboardData();
    }

    @PostMapping("/bulkAssignAudit")
    public JSONObject bulkAssignAudit(@RequestPart("file") MultipartFile file, HttpServletRequest request, HttpServletResponse response)throws IOException {
        log.info(this.getClass().getName() + " :- bulkUploadAtmMaster() ");
        InputStream inputStream =  new BufferedInputStream(file.getInputStream());
        Users user = super.getUser(request);  // bypass
        return ticketService.bulkAssignAudit(inputStream, user);
    }

    @GetMapping("/findAllV2")
    public JSONObject findAllV2(@QueryParam("page") int page,
                                @QueryParam("size") int size, HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAllV2() ");
        return ticketService.findAllTicketPaginated(page, size);
    }

    @GetMapping("/searchTicket")
    public JSONObject searchTicket(@QueryParam("searchTerm") String searchTerm,HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- searchTicket()  : {}", searchTerm);
        return ticketService.searchTicket(searchTerm);
    }

    @GetMapping("/EncodeFileToBase64Binary")
    public JSONObject EncodeFileToBase64Binary(@QueryParam("path") String path, HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- EncodeFileToBase64Binary()  : {}", path);
        return ticketService.EncodeFileToBase64Binary(path);
    }

    @GetMapping("/downloadTicket")
    public void downloadTicket( HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info("downloadTicket()");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=AssignedAudit.xlsx");
        ByteArrayInputStream stream = ticketService.downloadTicket();
        IOUtils.copy(stream, response.getOutputStream());
    }

    @GetMapping( "/deleteTicket")
    public JSONObject deleteTicket(@QueryParam("ticketId") Integer ticketId) {
        log.info(this.getClass().getName() + " :- DeleteTicket() ");
        return ticketService.deleteTicket(ticketId);
    }

    @GetMapping(path = "/image/{id}", produces = "image/png")
    public BufferedImage image(@PathVariable String id) {
        log.info("Requested picture >> " + id + " <<");
        try{
            id = id.replaceAll("_8821_","/");
            return ticketService.getBufferedImage("/" + id);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @GetMapping("/createAdhocTicket")
    public JSONObject createAdhocTicket(@QueryParam("ticketId") Integer ticketId,HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- createAdhocTicket() ticketId:{}",ticketId);
        Users user = super.getUser(request);
        JSONObject result = new JSONObject();
        if (user == null){
            result.put("status", 500);
            result.put("response", "Unauthorized Access");
        }
        return ticketService.createAdhocTicket(ticketId);
    }

    @GetMapping("/downloadTicketByFilter")

    public void downloadTicketByFilter(@QueryParam("fromDate")String fromDate,@QueryParam("toDate")String toDate,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws IOException {
        log.info("downloadTicket()");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=AssignedAudit.xlsx");
        ByteArrayInputStream stream = ticketService.downloadTicketByFilter(fromDate,toDate);
        IOUtils.copy(stream, response.getOutputStream());
    }
    @GetMapping("/findAllV2ByFilter")
    public JSONObject findAllV2ByFilter(@QueryParam("page") int page,
                                        @QueryParam("size") int size,@QueryParam("fromDate") String fromDate,
                                        @QueryParam("toDate") String toDate, HttpServletRequest request
            , HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAllV2() ");
        return ticketService.findAllTicketPaginatedByFilter(page, size,fromDate,toDate);
    }
    @GetMapping("/downloadTicketByFilterScheduled")
    public void downloadTicketByFilterScheduled(@QueryParam("fromDate")String fromDate,
    		                                    @QueryParam("toDate")String toDate,
                                                @QueryParam("userId")Integer userId,
                                                @QueryParam("siteId")Integer siteId,
                                                @QueryParam("type")String type,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws IOException {
        log.info("downloadTicket()");
        response.setContentType("application/octet-stream");
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        response.setHeader("Content-Disposition",
                "attachment; filename=Scheduled_Audit_Report_" + df.format(new Date()) + ".xlsx");
        ByteArrayInputStream stream = ticketService.downloadTicketByFilterScheduled(fromDate,toDate,userId,siteId,type);
        IOUtils.copy(stream, response.getOutputStream());
    }
    @GetMapping("/findAllV2ByFilterScheduled")
    public JSONObject findAllV2ByFilterScheduled(@QueryParam("page") int page,
                                                 @QueryParam("size") int size,
                                                 @QueryParam("fromDate") String fromDate,
                                                 @QueryParam("toDate") String toDate,
                                                 @QueryParam("userId") Integer userId,
                                                 @QueryParam("siteCode") String siteCode,
                                                 @QueryParam("type") String type
            ,HttpServletRequest request
            , HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAllV2() ");
        return ticketService.findAllTicketPaginatedByFilterScheduled(page, size,fromDate,toDate,userId,siteCode,type);
    }
    @GetMapping("/searchTicketScheduled")
    public JSONObject searchTicketScheduled(@QueryParam("searchTerm") String searchTerm,HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- searchTicketScheduled()  : {}", searchTerm);
        return ticketService.searchTicketScheduled(searchTerm);
    }

    @GetMapping( "/changeAuditorForScheduledTicket")
    public JSONObject changeAuditorForScheduledTicket(@QueryParam("ticketId") Integer ticketId,
                                                      @QueryParam("userId") Integer userId,HttpServletRequest request,
                                                      HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- changeAuditorForScheduledTicket() ");
        JSONObject  result = new JSONObject();
        Users user = super.getUser(request);
        if (user == null){
            result.put("status", 500);
            result.put("response", "Unauthorized Access");
            return result;
        }
        return ticketService.changeAuditorForScheduledTicket(ticketId,userId);
    }



}
