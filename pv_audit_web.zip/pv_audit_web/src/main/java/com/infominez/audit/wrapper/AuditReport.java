package com.infominez.audit.wrapper;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class AuditReport {
	Integer auditId;
	String fromDate;
	String toDate;
	Integer templateId; //by template
}
