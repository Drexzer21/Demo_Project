package com.infominez.audit.utils;

public class EnumUtils {

    public enum OPERATOR {
        ADD("ADD"),
        SUBTRACT("SUBTRACT"),
        DIVIDE("DIVIDE"),
        MULTIPLY("MULTIPLY");

        @SuppressWarnings("unused")
        private final String value;

        private OPERATOR(String value) {
            this.value = value;
        }
    }
    public enum visitType {
        MONTHLY("MONTHLY"),
        FORTNIGHTLY("FORTNIGHTLY"),
        WEEKLY("WEEKLY");

        private final String value;

        private visitType(String value) {
            this.value = value;
        }
    }
}
