package com.infominez.audit.repo;

import com.infominez.audit.entity.AuditType;
import com.infominez.audit.entity.Template;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TemplateRepository extends JpaRepository<Template,Integer> {
    List<Template> findByAuditType(AuditType auditType);

    List<Template> findByTemplateNameAndAuditType(String templateName, AuditType auditType);
    Template findByTemplateName(String templateName);

}
