package com.infominez.audit.controller;

import com.infominez.audit.entity.QuestionType;
import com.infominez.audit.entity.QuestionTypeOption;
import com.infominez.audit.service.QuestionTypeOptionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;

@RestController
@RequestMapping("/questionTypeOption")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class QuestionTypeOptionController {
    private final QuestionTypeOptionService questionTypeOptionService;

    @PostMapping( "/createQuestionTypeOption")
    public JSONObject createQuestionTypeOption(@RequestBody QuestionTypeOption questionTypeOption){
        return questionTypeOptionService.createQuestionTypeOption(questionTypeOption);
    }

    @PostMapping( "/updateQuestionTypeOption")
    public JSONObject updateQuestionTypeOption(@RequestBody QuestionTypeOption questionTypeOption){
        return questionTypeOptionService.updateQuestionTypeOption(questionTypeOption);
    }


    @GetMapping( "/findByQuestionTypeOptionId/{id}")
    public JSONObject findByQuestionTypeOptionId(@PathVariable("id") Integer questionTypeOptionId, HttpServletRequest request,
                                                 HttpServletResponse response){
        return questionTypeOptionService.findQuestionTypeOptionById(questionTypeOptionId);
    }

    @GetMapping( "/findAllQuestionTypeOption")
    public JSONObject findAllQuestionTypeOption(){
        return questionTypeOptionService.findAllQuestionTypeOption();
    }

    @GetMapping( "/findByQuestionType")
    public JSONObject findByQuestionType(@QueryParam("questionTypeId") Integer questionTypeId){
        return questionTypeOptionService.findByQuestionType(questionTypeId);
    }

    @GetMapping( "/findByQuestion")
    public JSONObject findByQuestion(@QueryParam("questionId") Integer questionId){
        return questionTypeOptionService.findByQuestion(questionId);
    }




}
