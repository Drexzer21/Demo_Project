package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.infominez.audit.utils.EnumUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "schedule_site")
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = false)
@Proxy(lazy = false)

public class ScheduleSite implements Serializable {
    private static final Long serialVersionUID = 1L;


    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "schedule_site_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer scheduleSiteId;

    @JoinColumn(name = "user_audit_schedule_id")
    @ManyToOne(fetch = FetchType.LAZY)
    private UserAuditSchedule userAuditSchedule;

    @JoinColumn(name = "site_id")
    @ManyToOne(fetch = FetchType.LAZY)
    private Site site;

    @Column(name = "visit_type")
    @Enumerated(EnumType.STRING)
    private EnumUtils.visitType visitType;

    @Column(name = "no_of_visit")
    private Integer noOfVisit;

    @Basic(optional = false)
    @Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;

    @Basic(optional = false)
    @Column(name = "end_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;



}
