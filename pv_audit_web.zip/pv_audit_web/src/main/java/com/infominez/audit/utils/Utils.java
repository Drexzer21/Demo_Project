package com.infominez.audit.utils;

import lombok.extern.slf4j.Slf4j;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.*;

@Slf4j

public class Utils {

    public static String getStringFromString(String s) {
        if (s != null) {
            if (s.trim().length() > 0) {
                return s.trim();
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

//    public static void main(String[] args) {
//        Calendar cTo = Calendar.getInstance();
//        cTo.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
//        cTo.add(Calendar.DATE, 7);
//        Date toDate = cTo.getTime();
//
//        cTo.add(Calendar.DATE, -41);
//        Date fromDate = cTo.getTime();
//        System.out.println("fromDate : " + fromDate);
//        System.out.println("toDate : " + toDate);
//        List<Date> dateList = getDaysBetweenDates(fromDate, toDate);
//    }
    public static void main(String[] args) {
//    	Calendar cto = new GregorianCalendar();
//    	cto.setTime(new Date());
//    	SimpleDateFormat sdf = new SimpleDateFormat("MMM YYYY");
//    	cto.add(Calendar.MONTH, 0);
//    	Date toDate = cto.getTime();
//
//    	System.out.println(toDate);   // NOW
//    	cto.add(Calendar.MONTH, -1);
//    	 Date fromDate = cto.getTime();
//    	System.out.println(sdf.format(fromDate));
    	Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd");
         String str = formatter.format(date);
         Integer todate = Integer.parseInt(str);
         if(todate <= 15) {
        	 System.out.println("Yes");
         } else {
        	 System.out.println("No");
         }
	}

    public static List<Date> getSixWeekDates(){
        Calendar cTo = Calendar.getInstance();
        cTo.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        cTo.add(Calendar.DATE, 7);
        Date toDate = cTo.getTime();

        cTo.add(Calendar.DATE, -42);
        Date fromDate = cTo.getTime();
        System.out.println("fromDate : " + fromDate);
        System.out.println("toDate : " + toDate);
        return getDaysBetweenDates(fromDate, toDate);
    }

    public static List<Date> getDaysBetweenDates(Date startdate, Date enddate)
    {
        List<Date> dates = new ArrayList<>();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);

        while (calendar.getTime().before(enddate))
        {
            Date result = calendar.getTime();
            dates.add(result);
            calendar.add(Calendar.DATE, 1);
        }
        return dates;
    }
}
