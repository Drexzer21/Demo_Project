package com.infominez.audit.controller;

import com.infominez.audit.entity.Site;
import com.infominez.audit.service.SiteService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

@RestController
@RequestMapping("/site")
@AllArgsConstructor
@Slf4j
public class SiteController {
    private final SiteService siteService;

    @PostMapping("/create")
    public JSONObject create(@RequestBody Site site) {
        log.info(this.getClass().getName() + " :- create() ");
        return siteService.createSite(site);
    }

    @GetMapping("/getAllState")
    public JSONObject getAllState(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- getAllState() ");
        return siteService.getAllState();
    }

    @GetMapping("/getAllCity")
    public JSONObject getAllCity(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- getAllCity() ");
        return siteService.getAllCity();
    }

    @PostMapping("/bulkUploadSite")
    public JSONObject bulkUploadSite(@RequestPart("file") MultipartFile file, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info(this.getClass().getName() + " :-  bulkUploadSite() ");
        InputStream inputStream = new BufferedInputStream(file.getInputStream());
        return siteService.bulkUploadSite(inputStream);
    }

    @PostMapping("/getSiteWithFilters")
    public JSONObject getSiteWithFilters(@RequestBody JSONObject jsonObject, HttpServletRequest request,
                                         HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- getSiteWithFilters() : {}", jsonObject.toString());
        return siteService.getSiteWithFilters(jsonObject);
    }

    @PostMapping("/getSiteWithFiltersForSchedule")
    public JSONObject getSiteWithFiltersForSchedule(@RequestBody JSONObject jsonObject, HttpServletRequest request,
                                         HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- getSiteWithFiltersForSchedule() : {}", jsonObject.toString());
        return siteService.getSiteWithFiltersForSchedule(jsonObject);
    }

    @GetMapping("/getAllSite")
    public JSONObject getAllSites(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- getAllSites() ");
        return siteService.getAllSites();
    }
}

