package com.infominez.audit.repo;

import com.infominez.audit.entity.ScheduleSite;
import com.infominez.audit.entity.UserAuditSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.List;

public interface ScheduleSiteRepository extends JpaRepository<ScheduleSite, Integer>{

	List<ScheduleSite> findByUserAuditSchedule(UserAuditSchedule userAuditSchedule);
	  @Query(value ="select ss.schedule_site_id , s.site_id, s.site_name,s.site_code,s.state,s.city,s.site_address,s.pincode from schedule_site  ss"
		      +  " inner join site s on ss.site_id = s.site_id"
		     +  "  where user_audit_schedule_id =:userAuditScheduleId ", nativeQuery = true)
	  List<Object[]>FindScheduleSiteByUserAuditSchedule (Integer userAuditScheduleId);

	  @Query(value ="SELECT * FROM audit.schedule_site where schedule_site_id=:scheduleSiteId", nativeQuery = true)
	  ScheduleSite findScheduleSiteById(Integer scheduleSiteId);

	@Query(value ="select distinct(s.site_id),s.site_name,s.site_code,s.state,s.city,s.pincode,s.site_address from schedule_site ss " +
			"inner join site s on s.site_id = ss.site_id " +
			"inner join user_audit_schedule us on us.user_audit_schedule_id =  ss.user_audit_schedule_id " +
			"inner join users u on u.user_id = us.user_id " +
			"where u.user_id = :userId", nativeQuery = true)
	List<Object[]> getListOfScheduledSiteByUser(Integer userId);

//	@Query(value ="select s.schedule_site_id from  schedule_site s  " +
//			" inner join user_audit_schedule us   on s.user_audit_schedule_id = us.user_audit_schedule_id  " +
//			"inner join users u on u.user_id = us.user_id  " +
//			"inner join template t on t.template_id = us.template_id  " +
//			"where u.user_id=:userId and t.template_id=:templateId and s.site_id=:siteId and s.visit_type=:visitType  " +
//			"and s.start_date=:startDate and s.end_date=:endDate " +
//			"and s.no_of_visit = :noOfVisit", nativeQuery = true)
//    List<Object[]> checkScheduledSites(Integer userId, Integer templateId, Integer siteId, String visitType, String startDate, String endDate, Integer noOfVisit);

	@Query(value = "call CheckScheduledSites(:startDate, :endDate, :userId, :templateId, :siteId, :noOfVisit, :visitType)", nativeQuery = true)
	List<Object[]> checkScheduledSites(Integer userId, Integer templateId, Integer siteId, String visitType, String startDate, String endDate, Integer noOfVisit);

    @Query(value = "select u.user_id, u.email_id, t.template_name, s.site_code, ss.start_date, ss.end_date, ss.no_of_visit, "
    		+ "ss.visit_type, uas.created_date as uploadDate  from schedule_site ss "
    		+ "inner join user_audit_schedule uas on uas.user_audit_schedule_id = ss.user_audit_schedule_id "
    		+ "inner join site s on s.site_id = ss.site_id "
    		+ "inner join users u on u.user_id = uas.user_id "
    		+ "inner join template t on t.template_id = uas.template_id "
    		+ "where(u.user_id = :userId or :userId IS NULL) and "
    		+ "(s.site_code = :sitecode or :sitecode IS NULL) and "
    		+ "(ss.start_date >= :FromDate or :FromDate IS NULL) and "
    		+ "(ss.end_date <= :ToDate or :ToDate IS NULL) and "
    		+ "(uas.created_date = :AssignedDate or :AssignedDate IS NULL)", nativeQuery = true)
    List<Object[]> getAduitSchedulingDate(Date FromDate, Date ToDate, String AssignedDate, Integer userId,
			String sitecode);

}

