package com.infominez.audit.wrapper;

import com.infominez.audit.entity.Site;
import lombok.Data;
import lombok.ToString;


@Data
@ToString
public class CashMasterDTO {
    private Integer ticketId;
    private String date;
    private Integer questionId;
    private Integer siteId;
    private String response;
    private Integer sequence;

    public CashMasterDTO getClassObject(){
        return this;
    }
}
