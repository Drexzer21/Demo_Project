package com.infominez.audit.utils;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConnPool {
    private static ConnPool instance = null;
    private List<Connection> connlist = new ArrayList<>();
    private List<Connection> usedconnlist = new ArrayList<>();
    private final List<Connection> availableconnlist = new ArrayList<>();

//    linode
    private String jdbcUrl = "jdbc:mysql://172.104.50.53:3306/audit_prod?autoReconnect=true&useSSL=false&useUnicode=true&characterEncoding=UTF-8";

    // PROD
//    private String jdbcUrl = "jdbc:mysql://127.0.0.1:3306/audit?autoReconnect=true&useSSL=false&useUnicode=true&characterEncoding=UTF-8";

    private String user = "sa";
    private String password = "P@ssword1";


    public ConnPool() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e1) {
            e1.printStackTrace();
        }
        int minConnections = 10;
        for (int i = 0; i < minConnections; i++) {
            try {
                Connection conn = createConnection();
                connlist.add(conn);
                availableconnlist.add(conn);

            } catch (SQLException e) {

                e.printStackTrace();
            }
        }
    }

    public static ConnPool getInstance() {
        if (instance == null) {
            instance = new ConnPool();
        }
        return instance;
    }

    public Connection getConnection() {
        if (availableconnlist.size() > 0) {
            Connection conn = availableconnlist.remove(0);
            usedconnlist.add(conn);
            return conn;
        }
        int maxConnections = 100;
        if (connlist.size() < maxConnections) {

            try {
                Connection conn = DriverManager.getConnection(jdbcUrl, user, password);
                connlist.add(conn);
                usedconnlist.add(conn);
                return conn;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            synchronized (availableconnlist) {
                try {
                    availableconnlist.wait(20000);
                    if (availableconnlist.size() > 0) {
                        Connection conn = createConnection();
                        connlist.add(conn);
                        usedconnlist.add(conn);
                        return conn;
                    }
                } catch (InterruptedException | SQLException e) {

                    e.printStackTrace();
                }
            }
        }

        return null;
    }

    private Connection createConnection() throws SQLException {

        Connection conn = DriverManager.getConnection(jdbcUrl, user, password);

        conn.setAutoCommit(true);

        return conn;
    }

    public void returnConnection(Connection conn) {
        usedconnlist.remove(conn);
        if (testConnection(conn)) {
            availableconnlist.add(conn);
        } else {
            connlist.remove(conn);
            try {
                conn = createConnection();
                connlist.add(conn);
                availableconnlist.add(conn);
            } catch (SQLException e) {

                e.printStackTrace();
            }
        }

        synchronized (availableconnlist) {
            availableconnlist.notify();
        }
    }

    private boolean testConnection(Connection conn) {
        boolean answer = false;
        try {
            ResultSet resRaws;

            PreparedStatement testSql = conn.prepareStatement("SELECT 1;");
            resRaws = testSql.executeQuery();

            String res = null;
            while (resRaws.next()) {
                res = resRaws.getString(1);
            }

            if (res != null) {
                answer = true;
            }

            resRaws.close();

            testSql.close();

        } catch (Throwable t) {
            t.printStackTrace();
            answer = false;
        }

        return answer;
    }

    public static void main(String[] args) {

    }

}
