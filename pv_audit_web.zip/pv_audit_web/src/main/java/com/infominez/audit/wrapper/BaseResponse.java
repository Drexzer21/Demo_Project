/**
 * 
 */
package com.infominez.audit.wrapper;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class BaseResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private Boolean status;
	
	private Object response;
}
