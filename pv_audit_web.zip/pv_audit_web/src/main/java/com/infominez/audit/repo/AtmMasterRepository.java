package com.infominez.audit.repo;

import com.infominez.audit.entity.AtmMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AtmMasterRepository extends JpaRepository<AtmMaster,Integer> {

    @Query(value = "select distinct(bank) from atm_master",
            nativeQuery = true)
    List<Object> GetAllBanks();

    @Query(value = "select distinct(vendor) from atm_master",
            nativeQuery = true)
    List<Object> GetAllVendor();

    @Query(value = "select distinct(atm_brand) from atm_master",
            nativeQuery = true)
    List<Object> GetAllAtmBrand();

    @Query(value = "select distinct(atm_type) from atm_master",
            nativeQuery = true)
    List<Object> GetAllAtmType();
//    @Query("SELECT a from AtmMaster a where a.bank like %:bank% AND a.vendor like %:vendor% AND a.atmBrand like %:atmBrand AND a.atmType like %:atmType% ")
    @Query("SELECT a from AtmMaster a where (a.bank =:bank OR :bank IS NULL) AND (a.vendor =:vendor OR :vendor IS NULL) AND (a.atmBrand =:atmBrand OR :atmBrand IS NULL) AND (a.atmType =:atmType OR :atmType IS NULL) ")
    List<AtmMaster> findByBankAndVendorAndAtmBrandAndAtmType(String bank,String vendor,String atmBrand,String atmType);

    List<AtmMaster> findByBankOrVendorOrAtmBrandOrAtmType(String bank,String vendor,String atmBrand,String atmType);

    List<AtmMaster> findByAtmId(String atmId);










}
