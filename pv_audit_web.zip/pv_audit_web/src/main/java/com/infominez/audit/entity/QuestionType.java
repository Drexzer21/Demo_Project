package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "question_type" )
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = false)
@Proxy(lazy = false)
public class QuestionType implements Serializable {

    private static final Long serialVersionUID = 1L;

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "question_type_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer questionTypeId;

    @Basic(optional = false)
    @Column(name = "type")
    private String questionType;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "created_by")
    private Integer createdBy;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "updated_by")
    private Integer updatedBy;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "created_date")
    private Date createdDate;

    @JsonIgnore
    @Basic(optional = false)
    @Column(name = "last_updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDate;

    @Basic(optional = false)
    @Column(name = "is_option")
    private Boolean isOption;

    public QuestionType(Integer questionTypeId,String questionType,Integer createdBy,Integer updatedBy,Date createdDate,Date lastUpdatedDate,Boolean isOption) {
    this.questionTypeId=questionTypeId;
    this.questionType=questionType;
    this.createdBy=createdBy;
    this.updatedBy=updatedBy;
    this.createdDate=createdDate;
    this.lastUpdatedDate=lastUpdatedDate;
    this.isOption=isOption;


    }
}
