package com.infominez.audit.controller;

import com.infominez.audit.entity.AuditType;
import com.infominez.audit.service.AuditTypeService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auditType")
@CrossOrigin(origins = "*", maxAge = 3600)
@AllArgsConstructor
@Slf4j
public class AuditTypeController {

    private final AuditTypeService auditTypeService;

    @RequestMapping( value = "/**", method = RequestMethod.OPTIONS)
    public ResponseEntity handle() {
        return new ResponseEntity(HttpStatus.OK);
    }

    @PostMapping("/createAuditType")
    public JSONObject createAuditType(@RequestBody AuditType auditType) {
        return auditTypeService.createAuditType(auditType);

    }

    @PostMapping("/updateAuditType")
    public JSONObject updateAuditType(@RequestBody AuditType auditType){
        log.info(this.getClass().getName() + " :-updateAuditType()");
        return auditTypeService.updateAuditType(auditType);
    }

    @GetMapping("/getAllAuditType")
    public JSONObject findAllAuditType(){
        return auditTypeService.findAllAuditType();
    }

    @GetMapping("/getAuditTypeById/{id}")
    public JSONObject findAuditTypeById(@PathVariable("id") Integer auditTypeid) {
        log.info(this.getClass().getName() + " :- findAuditTypeById");
        return auditTypeService.findAuditTypeById(auditTypeid);
    }
}
