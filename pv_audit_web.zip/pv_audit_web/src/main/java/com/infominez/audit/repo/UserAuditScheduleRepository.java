package com.infominez.audit.repo;

import com.infominez.audit.entity.UserAuditSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.List;

public interface UserAuditScheduleRepository extends JpaRepository <UserAuditSchedule, Integer>{
	@Query(value = "call getWeeklyScheduleReport()",
	        nativeQuery = true) 
	List<Object[]> callGetWeeklyScheduleReport();

	@Query(value ="select uas.user_audit_schedule_id,uas.user_id, u.username, u.email_id, uas.template_id, t.template_name from user_audit_schedule  uas "
		       + " inner join users u on u.user_id = uas.user_id "
		       + "  inner join template t on t.template_id = uas.template_id ", nativeQuery = true)
	  List<Object[]> findAllUserAuditSchedule();

	  @Query(value ="select uas.user_audit_schedule_id,uas.user_id, u.username, u.email_id, uas.template_id, t.template_name from user_audit_schedule  uas "
		       + " inner join users u on u.user_id = uas.user_id "
		       + "  inner join template t on t.template_id = uas.template_id where uas.user_audit_schedule_id = :id ", nativeQuery = true)
	  List<Object[]> findByUserAuditSchedule(Integer id);


	  @Query(value ="select distinct(u.user_id),u.username,u.email_id,u.first_name,u.last_name from user_audit_schedule ua\n" +
			"inner join users u on u.user_id =  ua.user_id", nativeQuery = true)
	List<Object[]> getListOfUserScheduled();

	@Query(value ="select * from user_audit_schedule us " +
			"inner join users u on u.user_id = us.user_id " +
			"inner join template t on t.template_id = us.template_id " +
			"inner join schedule_site s on s.user_audit_schedule_id = us.user_audit_schedule_id " +
			"where u.user_id=:userId and t.template_id=:templateId and s.site_id=:siteId and s.visit_type=:visitType " +
			"and s.start_date=:startDate and s.end_date=:endDate", nativeQuery = true)
	UserAuditSchedule findUserAuditSchedule(Integer userId, Integer templateId, Integer siteId, String visitType, Date startDate,Date endDate);

	@Query(value = "call getFornightlyScheduleReport()",
	        nativeQuery = true) 
	List<Object[]> callGetFornightlyScheduleReport();

	@Query(value = "call getMonthlySchedulerReport()",
			nativeQuery = true)
	List<Object[]> callGetMonthlyScheduleReport();

	@Query(value = "call getWeeklyScheduleReportForMail()",
			nativeQuery = true)
	List<Object[]> callGetWeeklyScheduleReportForMail();

	@Query(value = "call getFornightlyScheduleReportForEmail()",
			nativeQuery = true)
	List<Object[]> callGetFornightlyScheduleReportForMail();

	@Query(value = "call getMonthlySchedulerReportForEmail()",
			nativeQuery = true)
	List<Object[]> callGetMonthlyScheduleReportForMail();

	@Query(value ="call getWeeklyScheduleReportByDate(:fromDate, :toDate)", nativeQuery = true)
	List<Object[]> callGetWeeklyScheduleReportByDate(String fromDate, String toDate);
	
	@Query(value = "call getFortnightlySchedulerReportByDate(:fromDate, :toDate)", nativeQuery = true)
	List<Object[]> callGetFortnightlyScheduleReportByDate(String fromDate, String toDate);

	@Query(value = "call getMonthlySchedulerReportByDate(:fromDate, :toDate)", nativeQuery = true)
	List<Object[]> callGetMonthlyScheduleReportByDate(String fromDate, String toDate);
}
