package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;

@Entity
@Table(name = "page_image_response" )
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

@Proxy(lazy = false)
public class PageImageResponse implements Serializable {
    private static final Long serialVersionUID = 1L;
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "page_image_response_id" , columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer PageImageResponseId;

    @JoinColumn(name = "page_id")
    @ManyToOne(fetch = FetchType.LAZY)
    @Basic(optional = false)
    private Page page;

    @JoinColumn(name = "ticket_id")
    @ManyToOne(fetch = FetchType.LAZY)
    @Basic(optional = false)
    private Ticket ticket;

    @Basic(optional = false)
    @Column(name = "image_path")
    private String imagePath;

}
