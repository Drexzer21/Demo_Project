package com.infominez.audit.controller;

import com.infominez.audit.entity.AtmMaster;
import com.infominez.audit.service.AtmMasterService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

@RestController
@RequestMapping("/atmMaster")
@AllArgsConstructor
@Slf4j
public class AtmMasterController {
    private final AtmMasterService atmMasterService;

    @PostMapping("/create")
    public JSONObject create(@RequestBody AtmMaster atmMaster) {
        log.info(this.getClass().getName() + " :- create() ");
        return atmMasterService.createAtmMaster(atmMaster);
    }

    @PostMapping("/update")
    public JSONObject update(@RequestBody AtmMaster atmMaster) {
        log.info(this.getClass().getName() + " :- update() ");
        return atmMasterService.updateAtmMaster(atmMaster);
    }

    @GetMapping("/findById/{id}")
    public JSONObject findById(@PathVariable("id") Integer id) {
        log.info(this.getClass().getName() + " :- findById() ");
        return atmMasterService.findAtmMasterById(id);
    }

    @GetMapping("/findAll")
    public JSONObject findAll(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- findAll() ");
        return atmMasterService.findAllAtmMaster();
    }

    @GetMapping("/GetAllBanks")
    public JSONObject GetAllBanks(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- GetAllBanks() ");
        return atmMasterService.GetAllBanks();
    }

    @GetMapping("/GetAllVendor")
    public JSONObject GetAllVendor(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- GetAllVendor() ");
        return atmMasterService.GetAllVendor();
    }

    @GetMapping("/GetAllAtmBrand")
    public JSONObject GetAllAtmBrand(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- GetAllAtmBrand() ");
        return atmMasterService.GetAllAtmBrand();
    }

    @GetMapping("/GetAllAtmType")
    public JSONObject GetAllAtmType(HttpServletRequest request, HttpServletResponse response) {
        log.info(this.getClass().getName() + " :- GetAllAtmType() ");
        return atmMasterService.GetAllAtmType();
    }

    @PostMapping("/GetAtmMasterByBankAndVendorAndAtmBrandAndAtmType")
    public JSONObject GetAtmMasterByBankAndVendorAndAtmBrandAndAtmType(@RequestBody JSONObject jsonObject, HttpServletRequest request,
                                                                       HttpServletResponse response) {
        JSONObject result = new JSONObject();
        log.info(this.getClass().getName() + " :- GetAtmMasterByBankAndVendorAndAtmBrandAndAtmType() : {}", jsonObject.toString());
        try {
            String bank = jsonObject.get("bank") != null ? String.valueOf(jsonObject.get("bank")) : null;
            String vendor = jsonObject.get("vendor") != null ? String.valueOf(jsonObject.get("vendor")) : null;
            String atmBrand = jsonObject.get("atmBrand") != null ? String.valueOf(jsonObject.get("atmBrand")) : null;
            String atmType = jsonObject.get("atmType") != null ? String.valueOf(jsonObject.get("atmType")) : null;
            result = atmMasterService.GetAtmMasterByBankAndVendorAndAtmBrandAndAtmType(bank, vendor, atmBrand, atmType);
        } catch (Exception e) {
            result.put("status", 500);
            result.put("response", "Something Went Wrong");
        }
        return result;
    }
    @PostMapping("/bulkUploadAtmMaster")
    public JSONObject bulkUploadAtmMaster(@RequestPart("file") MultipartFile file,HttpServletRequest request, HttpServletResponse response)throws IOException {
        log.info(this.getClass().getName() + " :- bulkUploadAtmMaster() ");
        InputStream inputStream =  new BufferedInputStream(file.getInputStream());
        return atmMasterService.bulkUploadAtmMaster(inputStream);
    }

}
