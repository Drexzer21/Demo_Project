package com.infominez.audit.utils;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import ch.qos.logback.core.pattern.color.BlueCompositeConverter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ExcelUtils {

    public static void createAndWriteCell(Sheet sheet, Row row, int cellNumber, CellStyle cellStyle, String cellText) {
        Cell ticketNumber = row.createCell(cellNumber);
        ticketNumber.setCellStyle(cellStyle);
        if (null != cellText)
            ticketNumber.setCellValue(cellText);
    }

    public static CellStyle createCellStyle(Sheet sheet, int rowCount) {
        CellStyle cellStyle = null;
        if (rowCount == 8) {
            sheet.setColumnWidth(0, 8000);
            cellStyle = sheet.getWorkbook().createCellStyle();
            cellStyle.setWrapText(true);
            Font font = sheet.getWorkbook().createFont();
            font.setFontHeightInPoints((short) 10);
            font.setBold(true);
            cellStyle.setFont(font);
        } else {
            sheet.setColumnWidth(0, 2500);
            cellStyle = sheet.getWorkbook().createCellStyle();
        }
        return cellStyle;
    }

    public static void createAndWriteRow(Sheet sheet, ArrayList<String> rowData, int rowCount, CellStyle cellStyle,
                                         boolean isHeader, SXSSFWorkbook workbook) {
        Row row = sheet.createRow(rowCount);
        row.setHeight((short)400);
        if (isHeader) {
            cellStyle.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
            Font font = workbook.createFont();
            cellStyle.setFont(font);
            font.setBold(true);
        }
        for (int i = 0; i < rowData.size(); i++) {
            createAndWriteCell(sheet, row, i, cellStyle, rowData.get(i));
        }
    }

    public static void createHeader(Workbook wb,Sheet sheet, String headerText, int startRowIndex, int endRowIndex,
                                    int startColumnIndex, int endColumnIndex, int rowCount) {

        Row row = sheet.createRow(rowCount);
        row.setHeight((short) 600);
        CellStyle cellStyle = sheet.getWorkbook().createCellStyle();

        cellStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());
        cellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        cellStyle.setWrapText(true);
        Font font = sheet.getWorkbook().createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 16);
        font.setColor(HSSFColor.HSSFColorPredefined.BLUE.getIndex());
        cellStyle.setFont(font);

        Cell ticketNumber = row.createCell(0);
        if (null != headerText)
            ticketNumber.setCellValue(headerText);
        ticketNumber.setCellStyle(cellStyle);

        CellRangeAddress address = new CellRangeAddress(startRowIndex, endRowIndex, startColumnIndex, endColumnIndex);
        sheet.addMergedRegion(address);

    }

    public static void historyTypeInfoRow(Workbook wb,Sheet sheet, String infoText, int startRow, int endRow, int startColumn,
                                          int endColumn, int rowCount) {

        Row  row = sheet.createRow(rowCount);
        row.setHeight((short)400);

        CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
        cellStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.WHITE.getIndex());
        cellStyle.setWrapText(true);
        Font font = sheet.getWorkbook().createFont();
        font.setFontHeightInPoints((short) 12);
        font.setColor(HSSFColor.HSSFColorPredefined.BLUE.getIndex());
        cellStyle.setFont(font);

        Cell ticketNumber = row.createCell(0);
        ticketNumber.setCellStyle(cellStyle);
        if (null != infoText)
            ticketNumber.setCellValue(infoText);

        CellRangeAddress address=new CellRangeAddress(startRow, endRow, startColumn, endColumn);
        sheet.addMergedRegion(address);
    }
    
    public static void createAndWriteRowWithColor(Sheet sheet, ArrayList<String> rowData, int rowCount,
			CellStyle cellStyle, boolean isHeader, SXSSFWorkbook workbook, short colorIndexFont,
			short colorIndexBackGround) {
		Row row = sheet.createRow(rowCount);
		row.setHeight((short) 1500);
		if (isHeader) {
			cellStyle.setFillForegroundColor(colorIndexBackGround);
			cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			cellStyle.setBorderBottom(BorderStyle.THIN);
			cellStyle.setBorderTop(BorderStyle.THIN);
			cellStyle.setBorderRight(BorderStyle.THIN);
			cellStyle.setBorderLeft(BorderStyle.THIN);
			cellStyle.setWrapText(true);
			Font font = workbook.createFont();
			font.setColor(colorIndexFont);
			font.setFontHeightInPoints((short) 12);
			font.setFontName("Calibri");
			font.setBold(true);
			cellStyle.setFont(font);
			
		}
		for (int i = 0; i < rowData.size(); i++) {
			createAndWriteCell(sheet, row, i, cellStyle, rowData.get(i));
		}
	}

    public static void createHeaderWithColor(Workbook wb, Sheet sheet, String headerText, int startRowIndex,
			int endRowIndex, int startColumnIndex, int endColumnIndex, int rowCount, short colorIndexFont,
			short colorIndexBackGround) {

		Row row = sheet.createRow(rowCount);
		row.setHeight((short) 500);
		CellStyle cellStyle = sheet.getWorkbook().createCellStyle();

//        cellStyle.setFillForegroundColor(colorIndexBackGround);
//        cellStyle.setFillBackgroundColor(colorIndexBackGround);
		cellStyle.setFillForegroundColor(colorIndexBackGround);
		// and solid fill pattern produces solid grey cell fill
		cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		cellStyle.setWrapText(true);
		Font font = sheet.getWorkbook().createFont();
		font.setBold(true);
		font.setFontHeightInPoints((short) 15);
		font.setColor(colorIndexFont);
		font.setFontName("Calibri");
		cellStyle.setFont(font);
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

		Cell ticketNumber = row.createCell(0);
		if (null != headerText)
			ticketNumber.setCellValue(headerText);
		ticketNumber.setCellStyle(cellStyle);

		CellRangeAddress address = new CellRangeAddress(startRowIndex, endRowIndex, startColumnIndex, endColumnIndex);
		sheet.addMergedRegion(address);
	}
    public static void createHeaderWithColorAndCell(Workbook wb, Sheet sheet, String headerText, int startRowIndex,
			int endRowIndex, int startColumnIndex, int endColumnIndex, int rowCount,int cellNo, short colorIndexFont,
			short colorIndexBackGround) {

		Row row = sheet.createRow(rowCount);
		row.setHeight((short) 500);
		CellStyle cellStyle = sheet.getWorkbook().createCellStyle();

//        cellStyle.setFillForegroundColor(colorIndexBackGround);
//        cellStyle.setFillBackgroundColor(colorIndexBackGround);
		cellStyle.setFillForegroundColor(colorIndexBackGround);
		// and solid fill pattern produces solid grey cell fill
		cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		cellStyle.setWrapText(true);
		Font font = sheet.getWorkbook().createFont();
		font.setBold(true);
		font.setFontHeightInPoints((short) 15);
		font.setColor(colorIndexFont);
		font.setFontName("Calibri");
		cellStyle.setFont(font);
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

		Cell ticketNumber = row.createCell(cellNo);
		if (null != headerText)
			ticketNumber.setCellValue(headerText);
		ticketNumber.setCellStyle(cellStyle);

		CellRangeAddress address = new CellRangeAddress(startRowIndex, endRowIndex, startColumnIndex, endColumnIndex);
		sheet.addMergedRegion(address);
	}
    
    public static void createHeaderWithColorAndAlignment(Workbook wb, Sheet sheet, String headerText, int startRowIndex,
			int endRowIndex, int startColumnIndex, int endColumnIndex, int rowCount, short colorIndexFont,
			short colorIndexBackGround) {

		Row row = sheet.createRow(rowCount);
		row.setHeight((short) 600);
		CellStyle cellStyle = sheet.getWorkbook().createCellStyle();

//        cellStyle.setFillForegroundColor(colorIndexBackGround);
//        cellStyle.setFillBackgroundColor(colorIndexBackGround);
		cellStyle.setFillForegroundColor(colorIndexBackGround);
		// and solid fill pattern produces solid grey cell fill
		cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		cellStyle.setWrapText(true);
		Font font = sheet.getWorkbook().createFont();
		font.setBold(true);
		font.setFontHeightInPoints((short) 15);
		font.setColor(colorIndexFont);
		font.setFontName("Calibri");
		cellStyle.setFont(font);
		//cellStyle.setAlignment(HorizontalAlignment.CENTER);
		cellStyle.setAlignment(HorizontalAlignment.RIGHT);
		cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

		Cell ticketNumber = row.createCell(0);
		if (null != headerText)
			ticketNumber.setCellValue(headerText);
		ticketNumber.setCellStyle(cellStyle);

		CellRangeAddress address = new CellRangeAddress(startRowIndex, endRowIndex, startColumnIndex, endColumnIndex);
		sheet.addMergedRegion(address);
	}
    public static void mergeCells(Workbook wb, Sheet sheet, int startRowIndex, int endRowIndex, int startColumnIndex,
			int endColumnIndex) {
		CellRangeAddress address = new CellRangeAddress(startRowIndex, endRowIndex, startColumnIndex, endColumnIndex);
		sheet.addMergedRegion(address);

	}
    
	  public static void createHeaderWithColorWithoutColumnMerge(Workbook wb,Sheet
	  sheet, String headerText, int columnIndex, int rowCount, short
	  colorIndexFont, short colorIndexBackGround ) {
	  
	  Row row = sheet.createRow(rowCount); row.setHeight((short) 600); CellStyle
	  cellStyle = sheet.getWorkbook().createCellStyle();
	  cellStyle.setFillForegroundColor(colorIndexBackGround);
	  cellStyle.setFillBackgroundColor(colorIndexBackGround);
	  cellStyle.setFillForegroundColor(colorIndexBackGround); // and solid fill
	  //pattern produces solid grey cell fill
	  cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	  cellStyle.setWrapText(true); Font font = sheet.getWorkbook().createFont();
	  font.setBold(true); font.setFontHeightInPoints((short) 15);
	  font.setColor(colorIndexFont); font.setFontName("Calibri");
	  cellStyle.setFont(font); cellStyle.setAlignment(HorizontalAlignment.CENTER);
	  cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
	  
	  Cell ticketNumber = row.createCell(3); if (null != headerText)
	  ticketNumber.setCellValue(headerText); ticketNumber.setCellStyle(cellStyle);
	  
	  
	  }

	public static void mergeCellWithColor(Sheet sheet, String headerText, int startRowIndex,
														 int endRowIndex, int startColumnIndex, int endColumnIndex, int rowCount, short colorIndexFont,
														 short colorIndexBackGround) {

		Row row = sheet.getRow(rowCount);
		if (row == null){
			row = sheet.createRow(rowCount);
		}
		row.setHeight((short) 600);
		CellStyle cellStyle = sheet.getWorkbook().createCellStyle();

		cellStyle.setFillForegroundColor(colorIndexBackGround);
		cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		cellStyle.setWrapText(true);
		Font font = sheet.getWorkbook().createFont();
		font.setBold(true);
		font.setFontHeightInPoints((short) 12);
		font.setColor(colorIndexFont);
		font.setFontName("Calibri");
		cellStyle.setFont(font);
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
		cellStyle.setBorderBottom(BorderStyle.THIN);
		cellStyle.setBorderTop(BorderStyle.THIN);
		cellStyle.setBorderRight(BorderStyle.THIN);
		cellStyle.setBorderLeft(BorderStyle.THIN);


		Cell ticketNumber = row.createCell(startColumnIndex);
		if (null != headerText)
			ticketNumber.setCellValue(headerText);
		ticketNumber.setCellStyle(cellStyle);

		CellRangeAddress address = new CellRangeAddress(startRowIndex, endRowIndex, startColumnIndex, endColumnIndex);
		sheet.addMergedRegion(address);
	}
	public static void mergeCellWithoutColor(Sheet sheet, String headerText, int startRowIndex,
										  int endRowIndex, int startColumnIndex, int endColumnIndex, int rowCount) {

		Row row = sheet.getRow(rowCount);
		if (row == null){
			row = sheet.createRow(rowCount);
		}
		row.setHeight((short) 600);
		CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
		//cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		cellStyle.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
		cellStyle.setWrapText(true);
		Font font = sheet.getWorkbook().createFont();
		font.setBold(true);
		font.setFontHeightInPoints((short) 12);
		font.setFontName("Calibri");
		cellStyle.setFont(font);
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
//		cellStyle.setBorderBottom(BorderStyle.THIN);
//		cellStyle.setBorderTop(BorderStyle.THIN);
//		cellStyle.setBorderRight(BorderStyle.THIN);
//		cellStyle.setBorderLeft(BorderStyle.THIN);


		Cell ticketNumber = row.createCell(startColumnIndex);
		if (null != headerText)
			ticketNumber.setCellValue(headerText);
		ticketNumber.setCellStyle(cellStyle);

		CellRangeAddress address = new CellRangeAddress(startRowIndex, endRowIndex, startColumnIndex, endColumnIndex);
		sheet.addMergedRegion(address);
	}
	
	public static void createAndWriteRowIndex(Sheet sheet, ArrayList<String> rowData, int rowCount, CellStyle cellStyle,
	          boolean isHeader, SXSSFWorkbook workbook,Integer[] intIndex,Integer[] floatIndex, CellStyle numericCellStyle) {
			Row row = sheet.createRow(rowCount);
			row.setHeight((short) 400);
			if (isHeader) {
			cellStyle.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
			Font font = workbook.createFont();
			cellStyle.setFont(font);
			}
			cellStyle.setBorderBottom(BorderStyle.THIN);
			cellStyle.setBorderTop(BorderStyle.THIN);
			cellStyle.setBorderRight(BorderStyle.THIN);
			cellStyle.setBorderLeft(BorderStyle.THIN);
			
			
			for (int i = 0; i < rowData.size(); i++) {
			List<Integer> countIntegerList = new ArrayList<>(Arrays.asList(intIndex));
			List<Integer> countFloatList = new ArrayList<>(Arrays.asList(floatIndex));
			
			if(countIntegerList.contains(i)){
			numericCellStyle.setBorderBottom(BorderStyle.THIN);
			numericCellStyle.setBorderTop(BorderStyle.THIN);
			numericCellStyle.setBorderRight(BorderStyle.THIN);
			numericCellStyle.setBorderLeft(BorderStyle.THIN);
			
			createAndWriteNumberTypeCell(sheet, row, i, numericCellStyle,rowData.get(i),workbook);
			}
			else if(countFloatList.contains(i)){
			createAndWriteFloatTypeCell(sheet, row, i, cellStyle,rowData.get(i),workbook);
			}else{
			createAndWriteCell(sheet, row, i, cellStyle, rowData.get(i));
		}
	 }
	}
	
	public static void createAndWriteNumberTypeCell(Sheet sheet, Row row, int cellNumber, CellStyle cellStyle, String cellText,SXSSFWorkbook workbook) {
        Cell ticketNumber = row.createCell(cellNumber);
//        DataFormat format = workbook.createDataFormat();

        //CellStyle integerCellStyle = workbook.createCellStyle();
//        cellStyle.setBorderBottom(BorderStyle.THIN);
//        cellStyle.setBorderTop(BorderStyle.THIN);
//        cellStyle.setBorderRight(BorderStyle.THIN);
//        cellStyle.setBorderLeft(BorderStyle.THIN);

        ticketNumber.setCellStyle(cellStyle);

        if (null != cellText)
            ticketNumber.setCellValue(Integer.valueOf(cellText));
    }
  
  public static void createAndWriteFloatTypeCell(Sheet sheet, Row row, int cellNumber, CellStyle cellStyle, String cellText,SXSSFWorkbook workbook) {
        Cell ticketNumber = row.createCell(cellNumber);
        DataFormat format = workbook.createDataFormat();
        cellStyle.setDataFormat(format.getFormat("###0.00"));
        Number value = Float.parseFloat(cellText);

        ticketNumber.setCellStyle(cellStyle);
        if (null != value) {
            ticketNumber.setCellValue(value.doubleValue());
        }
    }
  
  public static void createAndWriteRowWithColorV2(Sheet sheet, ArrayList<String> rowData, int rowCount,
	         CellStyle cellStyle, boolean isHeader, SXSSFWorkbook workbook, short colorIndexFont,
	         short colorIndexBackGround) {
		 		Row row = sheet.createRow(rowCount);
				row.setHeight((short) 400);
				if (isHeader) {
				cellStyle.setFillForegroundColor(colorIndexBackGround);
				cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				cellStyle.setBorderBottom(BorderStyle.THIN);
				cellStyle.setBorderTop(BorderStyle.THIN);
				cellStyle.setBorderRight(BorderStyle.THIN);
				cellStyle.setBorderLeft(BorderStyle.THIN);
				Font font = workbook.createFont();
				font.setColor(colorIndexFont);
				font.setFontHeightInPoints((short) 11);
				font.setFontName("Calibri");
				font.setBold(true);
				cellStyle.setFont(font);
				}
					for (int i = 0; i < rowData.size(); i++) {
					createAndWriteCell(sheet, row, i, cellStyle, rowData.get(i));
				}
  }			

}
