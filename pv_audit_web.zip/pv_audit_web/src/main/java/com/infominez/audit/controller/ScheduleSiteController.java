package com.infominez.audit.controller;

import com.infominez.audit.base.BaseController;
import com.infominez.audit.entity.Users;
import com.infominez.audit.service.ScheduleSiteService;
import com.infominez.audit.wrapper.AuditReport;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.util.IOUtils;
import org.json.simple.JSONObject;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpHeaders;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.QueryParam;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/scheduleSite")
@AllArgsConstructor
@Slf4j
public class ScheduleSiteController extends BaseController{
	 private final ScheduleSiteService scheduleSiteService;
	    @GetMapping("/FindScheduleSiteByUserAuditSchedule")
	    public JSONObject FindScheduleSiteByUserAuditSchedule(@QueryParam("userAuditScheduleId")  Integer  userAuditScheduleId ,HttpServletRequest request, HttpServletResponse response) {
	        log.info(this.getClass().getName() + ":- FindScheduleSiteByUserAuditSchedule :{}",userAuditScheduleId);
	        return scheduleSiteService.FindScheduleSiteByUserAuditSchedule(userAuditScheduleId);
	    }

	@GetMapping("/getListOfSiteScheduledByUser")
	public JSONObject getListOfSiteScheduledByUser (@QueryParam("userId")  Integer  userId ,HttpServletRequest request, HttpServletResponse response) {
		log.info(this.getClass().getName() + ":- getListOfSiteScheduledByUser  userId:{}",userId);
		return scheduleSiteService.getListOfSiteScheduledByUser (userId);
	}
	
	@GetMapping("/getAuditSchedulingList")
	public JSONObject getAuditSchedulingList(@QueryParam("fromDate") String fromDate, @QueryParam("toDate") String toDate,
			                             @QueryParam("assignedDate") String assignedDate, @QueryParam("userId") Integer userId,
			                             @QueryParam("sitecode") String sitecode, HttpServletRequest request, HttpServletResponse response) {
		log.info(this.getClass().getName() + " :-getAuditSchedulingList() fromDate : {} toDate : {} assignedDate : {} userId : {} siteCode : {}", fromDate, toDate, assignedDate, userId, sitecode);
		 Users user = super.getUser(request);
		 JSONObject object = new JSONObject();
		 if(!user.getUserType().equalsIgnoreCase("ADMIN")) {
			 object.put("status", 302);
			 object.put("message", "Invaild user");
			 return object;
		 }
		return scheduleSiteService.getAuditSchedulingList(fromDate, toDate, assignedDate, userId, sitecode);
	}

	@PostMapping("/getAuditSchedulingReport")
	public void getAuditSchedulingReport(@QueryParam("fromDate") String fromDate, @QueryParam("toDate") String toDate,
										 @QueryParam("assignedDate") String assignedDate, @QueryParam("userId") Integer userId,
										 @QueryParam("sitecode") String sitecode, HttpServletRequest request, HttpServletResponse response) throws IOException {
		log.info("getAuditSchedulingReport()");
		 Users user = super.getUser(request);
		 JSONObject object = new JSONObject();
		 if(!user.getUserType().equalsIgnoreCase("ADMIN")) {
			 object.put("status", 302);
			 object.put("message", "Invaild user");
			 return;
		 }
		response.setContentType("application/octet-stream");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HH_mm_ss");
		String fileName = "Audit_Scheduling_Report-" + df.format(new Date());
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xlsx");
		response.setHeader(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
		ByteArrayInputStream stream = scheduleSiteService.getAuditSchedulingReport(fromDate, toDate, assignedDate, userId, sitecode);
		IOUtils.copy(stream, response.getOutputStream());
	}
	
	@PostMapping("/getSchedulerReportByDate")
	public void getSchedulerReportByDate(@QueryParam("fromDate") String fromDate, @QueryParam("toDate") String toDate,
										 HttpServletRequest request, HttpServletResponse response) throws IOException {
		log.info("getSchedulerReportByDate()");
		response.setContentType("application/octet-stream");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HH_mm_ss");
		String fileName = "Scheduling_Report-" + df.format(new Date());
		response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xlsx");
		response.setHeader(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
		ByteArrayInputStream stream = scheduleSiteService.getSchedulerReportByDate(fromDate, toDate);
		IOUtils.copy(stream, response.getOutputStream());
	}
}
