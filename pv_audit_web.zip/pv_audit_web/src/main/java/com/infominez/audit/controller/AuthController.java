package com.infominez.audit.controller;

import com.infominez.audit.entity.Users;
import com.infominez.audit.security.TokenProvider;
import com.infominez.audit.service.UsersService;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.ws.rs.Produces;

/**
 * @author AYUSH PARTANI
 */
@RestController
@CrossOrigin
public class AuthController {

    private final UsersService userService;

    private final TokenProvider tokenProvider;

    private final PasswordEncoder passwordEncoder;

    private final AuthenticationManager authenticationManager;

    public AuthController(PasswordEncoder passwordEncoder, UsersService userService,
                          TokenProvider tokenProvider, AuthenticationManager authenticationManager) {
        this.userService = userService;
        this.tokenProvider = tokenProvider;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
    }

    @GetMapping("/authenticate")
    @ResponseStatus(HttpStatus.OK)
    public boolean authenticate(HttpServletRequest request,
                                HttpServletResponse response) {
        String token = request.getHeader("Authorization").substring("Bearer".length()).trim();
        Authentication authentication = tokenProvider.getAuthentication(token);
        return authentication.isAuthenticated();
    }

    @PostMapping("/oauth/token")
    @Produces(MediaType.APPLICATION_JSON_VALUE)
    public String authorize(@Valid @RequestBody Users loginUser,
                            HttpServletResponse response) {
        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(loginUser.getUserName(), loginUser.getPassword());
        System.out.println(loginUser.getUserName() + "  " + loginUser.getPassword());

        try {
            this.authenticationManager.authenticate(authenticationToken);
            return this.tokenProvider.createToken(loginUser.getUserName());
        } catch (AuthenticationException e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return "{\n" +
                    "    \"error\": \"invalid_grant\",\n" +
                    "    \"error_description\": \"Bad credentials\"\n" +
                    "}";
        }
    }


    @PostMapping("/mobileLogin")
    @Produces(MediaType.APPLICATION_JSON_VALUE)
    public JSONObject mobileLogin(@RequestBody JSONObject body) {
        JSONObject result = new JSONObject();
        try {
            String ssoUsername = body.get("ssoUsername") != null ? String.valueOf(body.get("ssoUsername")) : null;
            if (ssoUsername != null) {
                Users user = userService.findUserBySsoUsername(ssoUsername);
                if (user != null) {
                	JSONObject response = new JSONObject();
					JSONParser parser = new JSONParser();
					JSONObject token = (JSONObject) parser.parse(this.tokenProvider.createToken(user.getUserName()));
					response.put("user", user);
					response.put("token", token);
					result.put("status", 200);
					result.put("response", response);
				}else{
					result.put("status", 401);
					result.put("response", "User Not Exist");
				}

            } else {
                result.put("status", 401);
                result.put("response", "username can not be empty");
            }
        } catch (Exception e) {
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }

    @PostMapping("/mobileLoginV2")
    @Produces(MediaType.APPLICATION_JSON_VALUE)
    public JSONObject mobileLoginV2(@RequestBody JSONObject body) {
        JSONObject result = new JSONObject();
        try {
            String username = body.get("username") != null ? String.valueOf(body.get("username")) : null;
            String password = body.get("password") != null ? String.valueOf(body.get("password")) : null;
            if (username != null) {
                Users user = userService.findUserByName(username);
                if (user != null) {
                    UsernamePasswordAuthenticationToken authenticationToken =
                            new UsernamePasswordAuthenticationToken(username, password);
                    System.out.println(username + "  " + password);
                    JSONParser parser = new JSONParser();
                    JSONObject response = new JSONObject();
                    try {
                        this.authenticationManager.authenticate(authenticationToken);
                        String temptoken =  this.tokenProvider.createToken(username);


                        JSONObject token = (JSONObject) parser.parse(temptoken);
                        response.put("user", user);
                        response.put("token", token);
                        result.put("status", 200);
                        result.put("response", response);
                    } catch (AuthenticationException e) {

                        result.put("status", 401);
                        result.put("response", "Invalid Username Or Password");
                    }

                }else{
                    result.put("status", 401);
                    result.put("response", "User Not Exist");
                }

            } else {
                result.put("status", 401);
                result.put("response", "username can not be empty");
            }
        } catch (Exception e) {
            result.put("status", 500);
            result.put("response", "Internal Server Error");
        }
        return result;
    }


}
