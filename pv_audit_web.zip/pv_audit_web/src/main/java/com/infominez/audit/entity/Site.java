package com.infominez.audit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.io.Serializable;

@Entity
@Table(name = "site")
@ToString
@Data
@EqualsAndHashCode
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = false)
@Proxy(lazy = false)
public class Site implements Serializable {

    private static final Long serialVersionUID = 1L;
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "site_id", columnDefinition = "INT UNSIGNED")
    @Basic(optional = false)
    private Integer siteId;

    @Basic(optional = false)
    @Column(name = "site_name")
    private String siteName;

    @Basic(optional = false)
    @Column(name = "site_code")
    private String siteCode;

    @Basic(optional = false)
    @Column(name = "state")
    private String state;

    @Basic(optional = false)
    @Column(name = "city")
    private String city;

    @Basic(optional = false)
    @Column(name = "site_address")
    private String siteAddress;

    @Column(name = "pincode")
    private String pincode;

    @Column(name = "assets")
    private String assets;

    @Column(name = "latitude")
    private Double latitude;
    
    @Column(name = "longitude")
    private Double longitude;
    
    @Transient
    @JsonIgnore
    public Site getClassObject(){
        return this;
    }


}
